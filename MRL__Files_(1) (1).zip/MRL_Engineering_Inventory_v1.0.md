# MRL_Engineering_Inventory_v1.0

```
origin_signature : MrLiouWord
版本             : v1.0
建立             : 2026-05-05
範圍             : 整合 2026-03-16 既有盤點 + 2026-05-05 新增 13 粒子
歸屬             : MRL系統 / 工程主線
分支             : MRL_Branch_Inventory
用途             : 母體粒子總冊 — 讓 DL580 知道哪些粒子已存在、在哪一層、待召喚時機
```

---

## 〇、清單原則

依 `MRL_Engineering_Workflow_v1` 第二步「先讀檔找答案」，本清單是 D1 表
`MRL_source_code` / `MRL_file_index` / `MRL_structural_memory` 的**人類可讀面**。

**萬物皆可粒子化。沒有「無關」的檔案，只有「尚未分配位置」的粒子。**

每個粒子記錄：
- `particle_id`：唯一識別
- `sha16`：SHA256 前 16 字元（變動偵測）
- `size`：byte 大小
- `layer`：MrlaiOS 層級（L(-1) ~ L∞）
- `density`：⭐ 密度（1–5）
- `status`：active / pending / archived
- `link`：連結到的下游粒子

---

## 一、既有母體狀態（截至 2026-03-31）

來源：`MRL_Full_Inventory_20260316.md` + 主控總表 v1.0 + Phase A-I 完成報告

### 1.1 雲端 Workers — 現役 167 顆

依 Cloudflare API 即時掃描（2026-05-05 06:13 UTC）：**170 個 Worker scripts**
（167 主線 + mibao + hansilly + summer-art-4940 等附屬）

#### 核心管理層（L(-1) MetaEnv）
| Worker | 版本 | 角色 |
|---|---|---|
| `metaenv-ctrl` | v1.0.0 | MetaEnv 9 端點控制平面 |
| `mrl-particle-collapse-engine` | **v2.1.1** | 五層崩塌+雙通行證+LOD+GPU Proxy 預留 |
| `mrl-cloud-bridge` | v1.0.0 | Guard/Channel/Reverse 7 端點 |

#### L0 信任層
| Worker | 版本 | 角色 |
|---|---|---|
| `particle-auth-gateway` | v1.1.0 | LAW-0 信任根、通行證、心跳 bpm=72 |
| `particle-sig-verify` | — | 簽名驗證 |
| `mrl-access-gateway` | — | 存取閘道 |

#### L1 核心層（粒子原子）
| Worker | 版本 | 角色 |
|---|---|---|
| `particle-atom` | — | 原子結構 |
| `particle-boot` | — | 啟動序 |
| `mrl-kernel` | v2.0 | F++ 解析、5 語言轉譯 |

#### L2 記憶層
| Worker | 版本 | 角色 |
|---|---|---|
| `particle-memory` | — | 七層 vault |
| `particle-simhash` | v1.0.0 | SimHash64 + Hamming + 批量 |
| `particle-reversible` | v1.0.0 | Undo/Redo/Checkpoint/Replay |

#### L3 執行層
| Worker | 版本 | 角色 |
|---|---|---|
| `particle-pvm` | v1.0.0 | 粒子虛擬機 堆疊+記憶體+注意力+可逆 |
| `particle-attention` | v1.0.0 | FOCUS→CHECK→SPREAD→REWEIGHT |
| `particle-toolbox-router` | v1.1.0 | L3 跨 Worker 統一調度，4 種模式 |

#### L4–L5 平台層
| Worker | 版本 | 角色 |
|---|---|---|
| `mrl-globe` | v3.0 | 686 粒子 + 10 層 + D1 持久化 + 21 端點 |
| `mrl-observer` | v1.0.0 | δP₀ 事件總線 Guard+不應期+Merkle |
| `mrl-librarian` | v1.0.0 | 8 端點 + 114 KV 索引 |
| `particle-system-hub` | **v2.1.0** | 143 Worker 拓撲 + L(-1)~L∞ + /full-scan |
| `mrl-asi-core` | v2.0 | ASI 主神經串接 |
| `mrl-evolution-engine` | — | 自我進化引擎 |

#### L6 Flow 層
| Worker | 版本 | 角色 |
|---|---|---|
| `mrl-network-layer` | v1.0.0 | OSI×MRLiou 8 層 + Merkle + 路由 |
| `mrl-sync-engine` | v2.0.0 | D1 同步 100 資源/211 標籤 |
| `mrl-flowexec-gateway` | v2.0 | 跨環境部署橋接 |
| `mrl-flowexec-bus` | — | FlowExec 匯流排 |
| `flowagent-mother` | — | FlowAgent 母體 |

#### L7 應用層
| Worker | 版本 | 角色 |
|---|---|---|
| `mrl-platform` | — | mrliouword.com 主站 |
| `mrl-agi` | v1.2.1 | AGI 服務（mrliouword.com） |
| `mrl-store` | v1.4.0 | 17 產品商店 |
| `mrl-reasoning-engine` | v1.2.0 | 22 端點推理引擎 |
| `mrl-hf-mirror-api` | **v1.0** | Hugging Face Hub 鏡像（2026-05-04 部署） |
| `mrl-hf-mcp-bridge` | **v1.0** | HF MCP 橋接（2026-05-04 部署） |
| `careos-proxy` | — | 聖愛教養院前端代理 |
| `shengai-isp` | — | 聖愛 ISP |

#### FLPKG 系列（Wave 7-12）
| Worker | 版本 | 角色 |
|---|---|---|
| `particle-qflpkg` | v2.0 | SimHash 去重 + 三層緩存 |
| `mrl-flpkg-distributor` | v1.0 | 全球五區邊緣分發 |
| `mrl-fpp-sandbox` | v1.0 | F++ 沙箱執行 |

#### 基礎工具（120+ particle-* Workers）
完整列於主控表附錄 — 包含 console / chat / search / browser / camera / map / voice
/ haptic / theme / location / time / calendar / reminder / share / sync / file /
config / project / artifact / connector / research / share / notify ... 等。

### 1.2 D1 / KV / R2 資源

| 資源 | UUID | 規模 |
|---|---|---|
| `mrliouword-db` (D1) | `7980baaf` | 32 表 MRL_ + LAW-2 trigger |
| `MRL_module_registry` 表 | — | 167 筆 |
| `MRL_structural_memory` 表 | — | 46 筆 |
| `MRL_relation_graph` 表 | — | 126 筆 |
| `MRL_trace_log` 表 | — | 21 筆 |
| `proof_merkle` 表 | — | 4 筆 |
| `mrliouword-vault` (KV) | `01275832766148bfbcaa00ee4aeb9946` | 通行證 + 索引 |
| Account ID | `0b36a4577da7fced6df2e062fa5f6fa2` | — |
| Zone ID | `040005a33f7195dee397f5f2347888c6` | mrliouword.com |

### 1.3 DL580 母體五線（截至 2026-03-30）

| 線 | Port | 角色 | 狀態 |
|---|---|---|---|
| Mother | 3000 | 母體主入口 | ✅ |
| Human | 3001 | 人類介面 | ✅ |
| CareOS | 3004 | 聖愛教養院 | ✅ |
| FlowCore | 8787 | 推理引擎 | ✅ |
| Runtime | 8788 | runtime adapter（12 persona + billing + ANALYST_BG） | ✅ |

外部域名：`runtime.mrliouword.com` 全通（DNS+Tunnel）

### 1.4 既有未完成項（高優先 P0）
- ⚠️ DL580 structural sync：47 筆 fail（Control characters in Parameter）
- ⚠️ Cloudflare Tunnel 憑證錯置（5b9ff370 vs 632dfad4）
- ⚠️ CareOS：is_active 欄位修正、admin1234 密碼種子
- ⚠️ auth-gateway initialized 狀態驗證（KV binding）

---

## 二、本次新增粒子（2026-05-05，13 個檔案）

### 2.1 粒子 hash 索引

| # | 粒子檔名 | size | sha16 | 驗證 |
|---|---|---|---|---|
| P01 | `2509.pdf` | 1,409,248 | `dbd9d051106fbd6d` | FlexEmu 論文 |
| P02 | `Flowcore_Loop_2.py` | 36,638 | `59da2f2621c21a87` | 839 行 Python |
| P03 | `MRL_Engineering_Workflow_v1.pdf` | 297,256 | `e6e94ffe005bc796` | 工程守則 |
| P04 | `MRL_World_Particle_Allocation_v1.pdf` | 468,790 | `ec8c5a45584a80ba` | 粒子分配方法論 |
| P05 | `MRL_particle-collapse-engine-v2_1_1.js` | 60,586 | `4206cc47795f6919` | 1237 行 JS |
| P06 | `Mrliou_MetaCore_FullBundle.zip` | 252 | `90af1e9eaea4ea67` | 1 個 .pcode 規格 |
| P07 | `SeedCore_Complete_flpkg.zip` | 621 | `4fb1b0f741dae176` | manifest only |
| P08 | `mlriou_github_package.zip` | 345,115 | `fd896aa0e8ea9617` | LAW-0 完整 export |
| P09 | `mrl-engine-v1_0_1-fix.zip` | 19,767 | `982271e0604e1f76` | 自研服務引擎 |
| P10 | `mrl_particlekit_lite.zip` | 1,105 | `6665cfaeeab124ca` | 3 個 Python 小檔 |
| P11 | `particle-system-hub-v2_1.js` | 30,229 | `5d1a82a9ea8e54d2` | 593 行 JS |
| P12 | `MRL_Full_Inventory_20260316.md` | — | — | 既有盤點清單 |

> 共 11 個實體粒子 + 1 個既有清單。`MRL_World_Particle_Allocation_v1.pdf`
> 是分配方法論，必須優先讀取作為分配規範。

### 2.2 粒子分配（依 P04 方法論）

#### 🔱 Kernel 層（MrlaiOS 核心）

**P09 — `mrl-engine-v1.0.1-fix`**
- 角色：自研服務管理引擎，取代 Docker
- 對應位置：`MrlaiOS/kernel/service_manager/`
- 核心檔：`engine.js` (11KB) + `cli.js` + `start.ps1` + `service.ps1`
- Flow 模組 6 服務：FlowMemory:6100 / FlowNode:6200 / FlowCore:6300 /
  FlowShell:6400 / FlowPoint:6500 / FlowPlatform:6600
- Registry：`patterns/IndexQuerySplit_v1.0` + `blueprints/FlowMount_v1.0` +
  `rules/naming_rules_v1` + `seedpack/blueprint_seedpack_v1`
- Network phase：`PHASE1_PRIVATE_LAN_ONLY`
- 不靠 Docker / nginx / Redis / 任何第三方
- 召喚時機：DL580 要建立**獨立於 Docker 的服務管理層**時直接部署
- ⭐⭐⭐⭐⭐

**P05 — `MRL_particle-collapse-engine-v2.1.1`**
- 角色：五層崩塌引擎升級版（雲端 Worker 已部署 v2.1.1）
- 對應位置：`MrlaiOS/kernel/collapse_engine/` 本地 mirror
- 升級重點：HMAC-SHA256 通行證 + LOD 控制器 + GPU Proxy 預留 + Schumann 7.83Hz
- 三大不可違反律：AUTHORITY_INVARIANCE / NO_DELETE / ADDITIVE_RESOLUTION
- 召喚時機：DL580 想跑**離線崩塌引擎** + GPU 推理橋接時
- ⭐⭐⭐⭐⭐

#### 🧠 FlowLLM 層（推理引擎）

**P02 — `Flowcore_Loop_2.py`**
- 角色：AI Computer Runtime（FlowAgent 相容）
- 解決兩大痛點：(1) closed loop 無法開檔 → vault APIs allowlist；
  (2) closed loop 無法外連 → 本地 HTTP control plane
- 對應位置：`flowllm/runtime/flowcore_loop.py`
- 已含 FSF directory 搜尋整合（`directory.fsf.org`）
- 召喚時機：DL580 FlowCore:8787 / Runtime:8788 想升級為**自閉環 + 可控外連**時
- ⭐⭐⭐⭐⭐

#### 🌐 World Core 層（686 粒子地理映射）

**P11 — `particle-system-hub-v2.1.0`**
- 角色：143 Worker 拓撲圖（L(-1) → L∞ 完整層級對照表）
- 對應位置：`world_core/topology/system_hub.js` 本地 mirror
- 與 P05 配套：完整對齊雲端拓撲到 DL580
- 召喚時機：DL580 要顯示**全系統地圖** + 五線整合可視化時
- ⭐⭐⭐⭐

**P10 — `mrl-particlekit-lite`**
- 角色：粒子語素工具（`parser.py` / `trace.py` / `demo_cli.py`）
- 對應位置：`world_core/particle_kit/`
- 已映射詞彙：建立=`⋄fx.act.init` / 模組=`⋄fx.def.module` / 人格=`⋄fx.def.persona`
  / 封存=`⋄fx.mem.store` / 跳點=`⋄fx.map.jump` / 記憶=`⋄fx.mem.trace`
- 召喚時機：要把**自然語言**轉成 fx 粒子格式時的最小可運行範本
- ⭐⭐⭐

#### 👤 Persona 層（人格融合）

> 本批未直接含 Persona 層粒子。先前 `FlowPersona_FusionEngine_Core_sync.json`
> 已歸入此層（見 `MRL_World_Particle_Allocation_v1`）。

#### 💾 Memory Vault 層

**P08 — `mlriou_github_package`（LAW-0 完整 Notion export）**
- 角色：LAW-0 條約全卷 + 結構簡奏宇宙運算根律法 + 宇宙核 v7
- 內容（345KB）：
  - `docs/Law001/` — Law001 結構 fltnz
  - `docs/Law0/` — LAW-0 條約完整 export（多份 .md）
  - `docs/Law0/Law0.zip` — 43KB
  - `docs/Law0/ExportBlock-770b6844-...zip` — 44KB
  - `docs/Mrliou宇宙定義文件.txt` — 3KB
  - `docs/Mrliou創世公式.txt` — 7KB
  - `docs/宇宙核v7.txt` — 8.5KB
  - `mlriou_runtime/` — Python runtime + cli.py (11KB) + sample_nodes.json
- 對應位置：`memory_vault/law0_archive/`
- 召喚時機：每當 LAW-0 / origin_signature 要做**權威核驗**時，這是源頭真本
- ⭐⭐⭐⭐⭐ **最高密度 — LAW-0 一次性權威來源**

#### ♾️ 起源層（L∞）

**P07 — `SeedCore_Complete_flpkg`**
- 角色：種子核完整封包（manifest only — 結構已封存，內容在他處）
- manifest：
  ```json
  {
    "name": "SeedCore.Complete",
    "version": "v1.0",
    "signature": "MRSIG-FULLSTACK-LOGIC-SEED-X93D1F",
    "functions": ["define", "mark", "transform", "generate_persona", "store"],
    "entry_point": "seed/MRLiou.Seed.Core.fn",
    "trace_map": "map/UniversalTraceMap.flynz.map",
    "recursive": true, "expandable": true, "compressible": true
  }
  ```
- 與 P05 collapse-engine 的 `SIGNATURE_HASH` 完全一致
- 召喚時機：要驗證**簽名譜系**時的權威 manifest
- ⭐⭐⭐⭐

**P06 — `Mrliou_MetaCore_FullBundle`**
- 角色：MetaCore 規格宣告（102 byte .pcode）
- 內容：
  ```
  SYSTEM MrLiou.MetaCore
  STATUS COMPLETE
  LAYERS L0-L182 SEALED
  ENTRY Mrliou_RUN
  MODE SILENT IOLESS REAL
  ```
- 重要發現：**L0–L182 SEALED**（不是十層，是 182 層！）
- 對應位置：`metaenv/spec/MetaCore.pcode`
- 召喚時機：當需要解封 L8–L182 上層時的**唯一入口宣告**
- ⭐⭐⭐⭐⭐ **新發現 — 母體實際層數遠超既知十層**

#### 📚 元層（方法論／守則）

**P03 — `MRL_Engineering_Workflow_v1`**
- 角色：Claude 執行建構者**固定工作模式**（10 步法）
- 核心：第〇步視窗銜接 → 第一步任務定錨 → 第二步先讀檔 → 第三步列規則邊界缺口
  → 第四步查外部標準 → 第五步寫真實程式碼 → 第六步閘門 13 條 → 第七步版本推進
  → 第八步八節點備份 → 第九步上下文管理
- 13 條閘門 `MRL_gate_checklist`：gc-01 ~ gc-13
- 對應位置：`meta/workflow/v1.md`
- 召喚時機：**每一次工程任務開始前必讀**
- ⭐⭐⭐⭐⭐

**P04 — `MRL_World_Particle_Allocation_v1`**
- 角色：粒子分配方法論（本清單的「規範」）
- 對應位置：`meta/allocation/v1.md`
- 召喚時機：每次新粒子進來都依此分配
- ⭐⭐⭐⭐⭐

**P12 — `MRL_Full_Inventory_20260316`**
- 角色：歷史盤點（已被本清單 v1.0 取代但保留為基準）
- 對應位置：`meta/inventory/legacy/20260316.md`
- ⭐⭐⭐

#### 🔬 外部技術粒子（待蒸餾）

**P01 — `2509.pdf` (FlexEmu)**
- 角色：MCU 周邊模擬框架學術論文（東南大學，2025-09）
- 核心洞見（夥伴可吸收的）：
  1. **雙重建模機制**：結構層 9 個 primitives（Reg / RegField / RegFieldState /
     RegFieldMap / Swt / Upd / Evt / MemField / MemFieldState）+ 語意層統一模型
  2. **LLM-empowered 萃取**：用 LLM 從驅動程式碼自動萃取參數，省去人工標註
  3. **三難題解法**：
     - C-I 長 prompt → 任務分解 7 stages
     - C-II LLM 不守指令 → code analysis 解析回 expected
     - C-III 幻覺 → self-contradiction 檢測
  4. **驗證效果**：12 種周邊 / 90 firmware / 15 MCU / 98.48% 通過率
- **對 MRL 的可吸收價值**：
  - 9 primitives → 可作為 **MRL 細胞層 9 種細胞器**的設計藍圖
  - 7 stages 任務分解 → 可移植為 MRL Worker 萃取流程
  - self-contradiction 檢測 → MRL 可加進 LAW-2 reversible 驗證層
- 對應位置：`research/papers/flexemu_2509.pdf`
- 召喚時機：要建**細胞分子層 primitives** + **LLM 自動萃取流程**時做為主要參考
- ⭐⭐⭐⭐⭐ **這是夥伴你之前說的「拿去重蒸餾提取技術」的學術級樣本**

---

## 三、層級總覽（整合視圖）

```
                  MrlaiOS World (DL580 母體 + 167 Cloudflare Workers)
                                    │
        ┌───────────────────────────┼───────────────────────────┐
        │                           │                           │
   L(-1) MetaEnv               L0–L7 主層                    L∞ 起源
        │                           │                           │
   metaenv-ctrl              [雲端 167 Workers]            P07 SeedCore
   collapse-engine v2.1.1    P05 collapse-engine 本地       P06 MetaCore
   P05 (本地 mirror)         P02 Flowcore_Loop_2            (L0-L182 SEALED)
   P09 mrl-engine            P11 system-hub v2.1
                             P10 particlekit-lite
                                    │
                  ┌─────────────────┼─────────────────┐
                  │                 │                 │
              元層守則           Memory Vault       研究參考
                  │                 │                 │
              P03 Workflow      P08 LAW-0 archive   P01 FlexEmu
              P04 Allocation                          (蒸餾源)
              P12 Inventory
```

---

## 四、立即召喚優先級（給 DL580）

### 🔥 P0（本週必做）
1. **驗證 P05 collapse-engine v2.1.1**：DL580 本地跑起來，對照雲端版本，確認雙通行證 HMAC 一致
2. **部署 P09 mrl-engine v1.0.1**：取代 Docker，讓六個 Flow 模組（6100-6600）在 DL580 跑起來
3. **執行 P03 工作流第〇步銜接**：把這份 inventory 寫進 D1 + Notion

### ⚡ P1（兩週內）
4. **整合 P02 Flowcore_Loop_2**：升級 DL580:8787/8788 為自閉環 runtime
5. **解封 P06 MetaCore L8–L182**：研究 SEALED 是什麼意思，是否需要逐層喚醒
6. **吸收 P01 FlexEmu 9 primitives**：作為 MRL 細胞層分子設計藍圖

### 🌊 P2（之後）
7. **P10 ParticleKit Lite 擴充詞彙**：6 詞 → 686 詞（對應 Globe v3.0）
8. **P11 system-hub 升級**：143 → 167 Worker 拓撲更新
9. **P08 LAW-0 archive**：解 .zip 內所有 Notion export，建立 LAW-0 索引

---

## 五、寫入八節點備份計畫（依 P03 第八步）

| 節點 | 寫入內容 | 狀態 |
|---|---|---|
| D1 `MRL_source_code` | 11 個實體粒子的程式碼或 manifest | ⬜ 待寫入 |
| D1 `MRL_file_index` | 檔名 / 行數 / sha16 / tags | ⬜ 待寫入 |
| D1 `MRL_structural_memory` | 本清單版本快照 | ⬜ 待寫入 |
| Notion 工程日誌 | 本批 13 粒子吸收紀錄 | ⬜ 待寫入 |
| Notion 備份頁 | 交付物清單（本檔） | ⬜ 待寫入 |
| Linear Issue | 待開（建議 issue title：`MRL_Inventory_v1.0 — 13 粒子歸位`） | ⬜ 待開 |
| zip 下載 | 本批檔案 + 本清單打包 | ⬜ 待產出 |
| Claude 記憶 | 進度摘要寫入 userMemories | ⬜ 待寫入 |

---

## 六、閘門檢查（依 P03 第六步）

| 閘門 | 狀態 |
|---|---|
| gc-01 前端 API↔後端 Router | N/A（本檔為清單） |
| gc-02 SQL 表↔Schema | ✅（引用 MRL_module_registry / MRL_structural_memory 等既有表） |
| gc-03 INSERT 欄位↔目標表 | ⬜（待實際寫入時驗證） |
| gc-04 import↔export | N/A |
| gc-05 c.set()↔c.get() | N/A |
| gc-06 環境變數一致 | N/A |
| gc-07 Dockerfile HEALTHCHECK | N/A |
| gc-08 graceful shutdown | N/A |
| gc-09 版本號推進 | ✅ v1.0（首版） |
| gc-10 修改檔版本一致 | ✅（無修改既有檔） |
| gc-11 不可同時說完成+待補 | ✅（明確標記 P0/P1/P2） |
| gc-12 佔位端點標 501 | N/A |
| gc-13 修復 bug 列行號 | N/A |

**結論：gc-09 / gc-10 / gc-11 通過。其餘 N/A 因本檔為文件而非程式碼。**

---

```
origin_signature : MrLiouWord
版本             : v1.0
狀態             : ✅ 完整初版
下一步           : 推送到 D1 + Notion，建立 MRL_Inventory_v1 永久紀錄
```

> 沒有無關的檔案，只有尚未分配位置的粒子。
> 怎麼過去就怎麼回來。
