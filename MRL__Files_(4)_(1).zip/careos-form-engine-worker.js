/**
 * CareOS Custom Form Engine — Worker API v1.0
 * origin_signature: MrLiouWord
 *
 * Endpoints:
 *  POST   /api/forms              建立表單
 *  GET    /api/forms              列出所有表單
 *  GET    /api/forms/:id          取得單一表單（含 schema）
 *  PUT    /api/forms/:id          更新表單
 *  DELETE /api/forms/:id          刪除表單
 *  POST   /api/forms/:id/publish  發佈/取消發佈
 *  POST   /api/forms/:id/submit   提交填寫結果
 *  GET    /api/forms/:id/responses 查詢填寫結果
 *  GET    /api/responses/:rid     取得單筆填寫結果
 *  GET    /api/forms/:id/export   匯出CSV
 */

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type,Authorization',
};

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...CORS, 'Content-Type': 'application/json' },
  });
}

function err(msg, status = 400) {
  return json({ ok: false, error: msg }, status);
}

// ─── D1 初始化 ───────────────────────────────────────────────
async function initDB(db) {
  await db.exec(`
    CREATE TABLE IF NOT EXISTS care_forms (
      id          TEXT PRIMARY KEY,
      title       TEXT NOT NULL,
      description TEXT DEFAULT '',
      category    TEXT DEFAULT 'general',
      schema_json TEXT NOT NULL,
      settings_json TEXT DEFAULT '{}',
      is_published INTEGER DEFAULT 0,
      created_by  TEXT DEFAULT 'system',
      created_at  TEXT NOT NULL,
      updated_at  TEXT NOT NULL,
      version     INTEGER DEFAULT 1
    );

    CREATE TABLE IF NOT EXISTS care_form_responses (
      id          TEXT PRIMARY KEY,
      form_id     TEXT NOT NULL,
      form_version INTEGER DEFAULT 1,
      respondent_id   TEXT DEFAULT '',
      respondent_name TEXT DEFAULT '匿名',
      respondent_role TEXT DEFAULT '',
      data_json   TEXT NOT NULL,
      status      TEXT DEFAULT 'submitted',
      submitted_at TEXT NOT NULL,
      ip_hash     TEXT DEFAULT '',
      FOREIGN KEY (form_id) REFERENCES care_forms(id)
    );

    CREATE INDEX IF NOT EXISTS idx_responses_form_id ON care_form_responses(form_id);
    CREATE INDEX IF NOT EXISTS idx_forms_category ON care_forms(category);
    CREATE INDEX IF NOT EXISTS idx_forms_published ON care_forms(is_published);
  `);
}

// ─── ID 生成 ─────────────────────────────────────────────────
function uid(prefix = 'f') {
  return prefix + '_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

function now() {
  return new Date().toISOString();
}

// ─── 表單 Schema 驗證 ────────────────────────────────────────
function validateSchema(schema) {
  if (!Array.isArray(schema)) return '欄位必須是陣列';
  for (const field of schema) {
    if (!field.id)   return `欄位缺少 id`;
    if (!field.type) return `欄位 ${field.id} 缺少 type`;
    if (!field.label) return `欄位 ${field.id} 缺少 label`;
    const validTypes = [
      'text','textarea','number','email','tel','date','time','datetime',
      'select','multi-select','radio','checkbox','rating','signature',
      'file','section-header','divider','info-text','staff-picker',
      'resident-picker','vital-signs','pain-scale'
    ];
    if (!validTypes.includes(field.type)) return `不支援的欄位類型: ${field.type}`;
  }
  return null;
}

// ─── 路由 ────────────────────────────────────────────────────
export default {
  async fetch(request, env) {
    if (request.method === 'OPTIONS') {
      return new Response(null, { status: 204, headers: CORS });
    }

    const db = env.DB;
    await initDB(db);

    const url  = new URL(request.url);
    const path = url.pathname;
    const method = request.method;

    try {
      // ── POST /api/forms ──────────────────────────────────
      if (method === 'POST' && path === '/api/forms') {
        const body = await request.json();
        const { title, description = '', category = 'general', schema = [], settings = {} } = body;
        if (!title) return err('title 必填');
        const schemaErr = validateSchema(schema);
        if (schemaErr) return err(schemaErr);

        const id = uid('form');
        const ts = now();
        await db.prepare(`
          INSERT INTO care_forms (id,title,description,category,schema_json,settings_json,created_at,updated_at)
          VALUES (?,?,?,?,?,?,?,?)
        `).bind(id, title, description, category, JSON.stringify(schema), JSON.stringify(settings), ts, ts).run();

        const form = await db.prepare('SELECT * FROM care_forms WHERE id=?').bind(id).first();
        return json({ ok: true, form: parseForm(form) }, 201);
      }

      // ── GET /api/forms ───────────────────────────────────
      if (method === 'GET' && path === '/api/forms') {
        const category  = url.searchParams.get('category') || '';
        const published = url.searchParams.get('published') || '';
        const search    = url.searchParams.get('q') || '';
        let q = 'SELECT * FROM care_forms WHERE 1=1';
        const params = [];
        if (category)  { q += ' AND category=?';     params.push(category); }
        if (published !== '') { q += ' AND is_published=?'; params.push(published === '1' ? 1 : 0); }
        if (search)    { q += ' AND title LIKE ?';   params.push(`%${search}%`); }
        q += ' ORDER BY updated_at DESC';
        const rows = await db.prepare(q).bind(...params).all();
        return json({ ok: true, forms: rows.results.map(parseFormSummary) });
      }

      // ── GET /api/forms/:id ───────────────────────────────
      const matchForm = path.match(/^\/api\/forms\/([^/]+)$/);
      if (matchForm) {
        const fid = matchForm[1];

        if (method === 'GET') {
          const form = await db.prepare('SELECT * FROM care_forms WHERE id=?').bind(fid).first();
          if (!form) return err('找不到表單', 404);
          return json({ ok: true, form: parseForm(form) });
        }

        if (method === 'PUT') {
          const form = await db.prepare('SELECT * FROM care_forms WHERE id=?').bind(fid).first();
          if (!form) return err('找不到表單', 404);
          const body = await request.json();
          const title       = body.title       ?? form.title;
          const description = body.description ?? form.description;
          const category    = body.category    ?? form.category;
          const schema      = body.schema      ?? JSON.parse(form.schema_json);
          const settings    = body.settings    ?? JSON.parse(form.settings_json);
          const schemaErr   = validateSchema(schema);
          if (schemaErr) return err(schemaErr);
          const ts = now();
          await db.prepare(`
            UPDATE care_forms SET title=?,description=?,category=?,schema_json=?,settings_json=?,updated_at=?,version=version+1 WHERE id=?
          `).bind(title, description, category, JSON.stringify(schema), JSON.stringify(settings), ts, fid).run();
          const updated = await db.prepare('SELECT * FROM care_forms WHERE id=?').bind(fid).first();
          return json({ ok: true, form: parseForm(updated) });
        }

        if (method === 'DELETE') {
          const form = await db.prepare('SELECT * FROM care_forms WHERE id=?').bind(fid).first();
          if (!form) return err('找不到表單', 404);
          await db.prepare('DELETE FROM care_form_responses WHERE form_id=?').bind(fid).run();
          await db.prepare('DELETE FROM care_forms WHERE id=?').bind(fid).run();
          return json({ ok: true, deleted: fid });
        }
      }

      // ── POST /api/forms/:id/publish ──────────────────────
      const matchPublish = path.match(/^\/api\/forms\/([^/]+)\/publish$/);
      if (matchPublish && method === 'POST') {
        const fid = matchPublish[1];
        const form = await db.prepare('SELECT * FROM care_forms WHERE id=?').bind(fid).first();
        if (!form) return err('找不到表單', 404);
        const newState = form.is_published ? 0 : 1;
        await db.prepare('UPDATE care_forms SET is_published=?,updated_at=? WHERE id=?')
          .bind(newState, now(), fid).run();
        return json({ ok: true, is_published: !!newState });
      }

      // ── POST /api/forms/:id/submit ───────────────────────
      const matchSubmit = path.match(/^\/api\/forms\/([^/]+)\/submit$/);
      if (matchSubmit && method === 'POST') {
        const fid = matchSubmit[1];
        const form = await db.prepare('SELECT * FROM care_forms WHERE id=?').bind(fid).first();
        if (!form) return err('找不到表單', 404);
        if (!form.is_published) return err('表單尚未發佈，不接受提交');
        const body = await request.json();
        const { data = {}, respondent_id = '', respondent_name = '匿名', respondent_role = '' } = body;
        // 必填驗證
        const schema = JSON.parse(form.schema_json);
        for (const field of schema) {
          if (field.required && !data[field.id] && data[field.id] !== 0) {
            return err(`欄位「${field.label}」為必填`);
          }
        }
        const rid = uid('resp');
        const ts  = now();
        await db.prepare(`
          INSERT INTO care_form_responses (id,form_id,form_version,respondent_id,respondent_name,respondent_role,data_json,submitted_at)
          VALUES (?,?,?,?,?,?,?,?)
        `).bind(rid, fid, form.version, respondent_id, respondent_name, respondent_role, JSON.stringify(data), ts).run();
        return json({ ok: true, response_id: rid, submitted_at: ts }, 201);
      }

      // ── GET /api/forms/:id/responses ─────────────────────
      const matchResponses = path.match(/^\/api\/forms\/([^/]+)\/responses$/);
      if (matchResponses && method === 'GET') {
        const fid  = matchResponses[1];
        const page = parseInt(url.searchParams.get('page') || '1', 10);
        const size = Math.min(parseInt(url.searchParams.get('size') || '20', 10), 100);
        const offset = (page - 1) * size;
        const total  = await db.prepare('SELECT COUNT(*) as c FROM care_form_responses WHERE form_id=?').bind(fid).first();
        const rows   = await db.prepare(
          'SELECT * FROM care_form_responses WHERE form_id=? ORDER BY submitted_at DESC LIMIT ? OFFSET ?'
        ).bind(fid, size, offset).all();
        return json({ ok: true, total: total.c, page, size, responses: rows.results.map(parseResponse) });
      }

      // ── GET /api/responses/:rid ──────────────────────────
      const matchResp = path.match(/^\/api\/responses\/([^/]+)$/);
      if (matchResp && method === 'GET') {
        const rid  = matchResp[1];
        const resp = await db.prepare('SELECT * FROM care_form_responses WHERE id=?').bind(rid).first();
        if (!resp) return err('找不到填寫紀錄', 404);
        return json({ ok: true, response: parseResponse(resp) });
      }

      // ── GET /api/forms/:id/export ────────────────────────
      const matchExport = path.match(/^\/api\/forms\/([^/]+)\/export$/);
      if (matchExport && method === 'GET') {
        const fid  = matchExport[1];
        const form = await db.prepare('SELECT * FROM care_forms WHERE id=?').bind(fid).first();
        if (!form) return err('找不到表單', 404);
        const schema = JSON.parse(form.schema_json);
        const dataFields = schema.filter(f => !['section-header','divider','info-text'].includes(f.type));
        const rows = await db.prepare(
          'SELECT * FROM care_form_responses WHERE form_id=? ORDER BY submitted_at DESC'
        ).bind(fid).all();

        const headers = ['填寫ID','填寫者','身份','時間', ...dataFields.map(f => f.label)];
        const csvRows = rows.results.map(r => {
          const data = JSON.parse(r.data_json);
          return [r.id, r.respondent_name, r.respondent_role, r.submitted_at,
            ...dataFields.map(f => {
              const v = data[f.id];
              if (Array.isArray(v)) return v.join('|');
              return v ?? '';
            })
          ].map(v => `"${String(v).replace(/"/g,'""')}"`).join(',');
        });

        const csv = [headers.map(h => `"${h}"`).join(','), ...csvRows].join('\n');
        return new Response('\uFEFF' + csv, {  // BOM for Excel
          headers: {
            ...CORS,
            'Content-Type': 'text/csv; charset=utf-8',
            'Content-Disposition': `attachment; filename="form_${fid}_export.csv"`,
          }
        });
      }

      return err('找不到路由', 404);

    } catch (e) {
      console.error(e);
      return err('伺服器錯誤: ' + e.message, 500);
    }
  }
};

// ─── 格式化 ──────────────────────────────────────────────────
function parseForm(row) {
  return {
    id:           row.id,
    title:        row.title,
    description:  row.description,
    category:     row.category,
    schema:       JSON.parse(row.schema_json),
    settings:     JSON.parse(row.settings_json || '{}'),
    is_published: !!row.is_published,
    created_by:   row.created_by,
    created_at:   row.created_at,
    updated_at:   row.updated_at,
    version:      row.version,
  };
}
function parseFormSummary(row) {
  const schema = JSON.parse(row.schema_json || '[]');
  return {
    id:           row.id,
    title:        row.title,
    description:  row.description,
    category:     row.category,
    field_count:  schema.filter(f => !['section-header','divider','info-text'].includes(f.type)).length,
    is_published: !!row.is_published,
    created_at:   row.created_at,
    updated_at:   row.updated_at,
    version:      row.version,
  };
}
function parseResponse(row) {
  return {
    id:              row.id,
    form_id:         row.form_id,
    form_version:    row.form_version,
    respondent_id:   row.respondent_id,
    respondent_name: row.respondent_name,
    respondent_role: row.respondent_role,
    data:            JSON.parse(row.data_json),
    status:          row.status,
    submitted_at:    row.submitted_at,
  };
}
