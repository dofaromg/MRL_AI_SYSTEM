#!/usr/bin/env bash
set -euo pipefail
# Placeholder runner: OpenMVS command names differ by installation.
# Expected final mesh path for this product package:
#   adapters/openmvs/mesh.obj OR mesh.ply OR mesh.glb
if ! command -v InterfaceCOLMAP >/dev/null 2>&1; then
  echo "OpenMVS tools not found. Place mesh.obj/mesh.ply/mesh.glb under adapters/openmvs manually." >&2
  exit 2
fi
echo "Add your OpenMVS project-specific commands here. Output mesh to adapters/openmvs/."
