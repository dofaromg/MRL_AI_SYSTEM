#!/usr/bin/env bash
set -euo pipefail
PYTHONPATH=src python -m mrl3d.main --config config/config.example.yaml
PYTHONPATH=src pytest -q
