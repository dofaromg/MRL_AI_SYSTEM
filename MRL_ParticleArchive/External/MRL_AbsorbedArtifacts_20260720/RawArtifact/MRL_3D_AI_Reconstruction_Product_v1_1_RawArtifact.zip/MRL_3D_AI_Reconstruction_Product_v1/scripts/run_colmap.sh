#!/usr/bin/env bash
set -euo pipefail
DATASET_DIR=${1:-data/images}
WORK_DIR=${2:-adapters/colmap_work}
OUT_DIR=${3:-adapters/colmap}
mkdir -p "$WORK_DIR" "$OUT_DIR"
if ! command -v colmap >/dev/null 2>&1; then
  echo "COLMAP not found. Install COLMAP first, or use simulate:true." >&2
  exit 2
fi
colmap feature_extractor --database_path "$WORK_DIR/database.db" --image_path "$DATASET_DIR"
colmap exhaustive_matcher --database_path "$WORK_DIR/database.db"
mkdir -p "$WORK_DIR/sparse"
colmap mapper --database_path "$WORK_DIR/database.db" --image_path "$DATASET_DIR" --output_path "$WORK_DIR/sparse"
MODEL_DIR=$(find "$WORK_DIR/sparse" -maxdepth 1 -mindepth 1 -type d | sort | head -n 1)
colmap model_converter --input_path "$MODEL_DIR" --output_path "$OUT_DIR" --output_type TXT
echo "COLMAP text model written to $OUT_DIR"
