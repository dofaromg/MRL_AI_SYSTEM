from pathlib import Path
import json
import textwrap
from mrl3d.main import run, validate


def test_simulation_pipeline_runs():
    root = Path(__file__).resolve().parents[1]
    manifest = run(str(root / "config/config.example.yaml"))
    assert manifest["camera_count"] >= 3
    assert manifest["track_count"] > 0
    assert manifest["heatmap_count"] == manifest["camera_count"]
    assert manifest["suggestion_count"] > 0
    assert manifest["quality_status"] in {"pass", "warn", "fail"}
    out = Path(manifest["out_dir"])
    assert (out / "metrics.json").exists()
    assert (out / "suggestions.json").exists()
    assert (out / "quality_gate.json").exists()
    assert (out / "report.html").exists()
    assert any(p.name.endswith(".png") for p in out.glob("heatmap_*.png"))
    suggestions = json.loads((out / "suggestions.json").read_text(encoding="utf-8"))
    assert suggestions["per_image"]
    assert "reshoot_pose_hint" in suggestions["per_image"][0]["top_tiles"][0]


def test_colmap_text_loader_fixture(tmp_path):
    project = tmp_path / "proj"
    (project / "config").mkdir(parents=True)
    (project / "adapters" / "colmap").mkdir(parents=True)
    (project / "data" / "outputs").mkdir(parents=True)
    cfg = project / "config" / "config.example.yaml"
    cfg.write_text(textwrap.dedent('''
    simulate: false
    seed: 1
    images_dir: data/images
    colmap_dir: adapters/colmap
    mvs_dir: adapters/openmvs
    out_dir: data/outputs
    attention: {backend: simple}
    error: {robust: huber, huber_delta_px: 3.0, normalize_heatmap: true}
    context: {link_topk: 2, min_complementarity: 0.0}
    gap_fill: {tiles: [2, 2], topk_per_image: 1, global_topk: 3, high_risk_threshold: 1.0}
    quality_gate: {min_tracks: 1, max_raw_p90_px: 10.0}
    export: {heatmap_png: true}
    '''), encoding="utf-8")
    cdir = project / "adapters" / "colmap"
    cdir.joinpath("cameras.txt").write_text("1 PINHOLE 100 80 80 80 50 40\n", encoding="utf-8")
    cdir.joinpath("images.txt").write_text("1 1 0 0 0 0 0 0 1 img001.png\n50 40 1 55 40 2\n", encoding="utf-8")
    cdir.joinpath("points3D.txt").write_text("1 0 0 5 255 255 255 0\n2 0.3 0 5 255 255 255 0\n", encoding="utf-8")
    v = validate(str(cfg))
    assert v["source"] == "colmap_text"
    assert v["camera_count"] == 1
    assert v["track_count"] == 2
    manifest = run(str(cfg))
    assert manifest["source"] == "colmap_text"
    assert manifest["suggestion_count"] == 1
