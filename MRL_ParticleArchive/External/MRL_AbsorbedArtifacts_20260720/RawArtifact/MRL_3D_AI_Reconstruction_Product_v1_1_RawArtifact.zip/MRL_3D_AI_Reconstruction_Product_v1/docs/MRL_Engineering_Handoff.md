# MRL_Branch_3D_AI_Reconstruction_Attention_Context_v1｜工程交付 v1.1.0

## 分支名稱
MRL_Branch_3D_AI_Reconstruction_Attention_Context_v1

## 分支目標
建立可運行的產品級 3D 立體成像輔助管線：以 AI 注意力加權重投影誤差，透過上下文圖自動連結視角，輸出 heatmap、品質驗收、補拍/補算建議與 HTML 報告。

## 分支交付物
- `src/mrl3d/main.py`
- `src/mrl3d/api.py`
- `src/mrl3d/pipeline/sfm.py`
- `src/mrl3d/pipeline/attention.py`
- `src/mrl3d/pipeline/error_map.py`
- `src/mrl3d/pipeline/context_graph.py`
- `src/mrl3d/pipeline/gap_fill.py`
- `src/mrl3d/pipeline/quality.py`
- `src/mrl3d/pipeline/export.py`
- `config/config.example.yaml`
- `schemas/suggestions.schema.json`
- `schemas/quality.schema.json`
- `tests/test_pipeline.py`
- `Dockerfile`
- `docker-compose.yml`
- `README.md`

## v1.1 已完成
1. `simulate: true` 無資料完整跑通。
2. COLMAP text loader 可讀 `cameras.txt / images.txt / points3D.txt`。
3. loader 可依 `images.txt` 的 IMAGE_NAME 載入 `data/images/` 原圖。
4. 自動偵測 OpenMVS mesh 路徑。
5. 注意力加權重投影誤差輸出 heatmap。
6. ContextGraph 建立互補視角連結。
7. GapFiller 輸出 tile 級補拍建議與 pose hint。
8. QualityGate 輸出 pass / warn / fail。
9. Exporter 輸出 `report.html` 與 heatmap PNG。
10. API 新增 `/validate`。
11. 測試新增 COLMAP fixture。

## 本輪驗收結果
- Demo pipeline：PASS
- pytest：2 passed
- simulation 輸出：6 heatmaps、36 suggestions、quality=pass
- 產出檔：`metrics.json / suggestions.json / links.json / quality_gate.json / cameras.json / report.html / heatmap_*.png / heatmap_*.txt / run_manifest.json`

## 待驗證
- 大型真實 COLMAP 專案輸入。
- OpenMVS 自動執行，不只是讀取產物。
- DINO / ViT 真模型注意力替換。
- NeRF / Gaussian Splatting 補洞。
- ARKit / ARCore 手機端採集與補拍指引 UI。

## 不回填
- 不宣稱已完整取代 Polycam / Luma / RealityCapture。
- 不宣稱已完成手機端 App。
- 不宣稱已完成真模型 DINO attention；目前為本地 deterministic attention，可替換。

## 回主線條件
回填到：
- `MRL_工程日誌.md`
- `MRL_世界模組工程書_v1.md`
- `MRL_母體定義檔_v1.md` 的產品分支索引／3D AI 成像分支紀錄

### 分支收口紀錄
- 分支名稱：MRL_Branch_3D_AI_Reconstruction_Attention_Context_v1
- 狀態：v1.1 產品級可運行包完成，待真資料驗收
- 已完成：CLI / API / COLMAP text loader / attention heatmap / ContextGraph / GapFiller / QualityGate / report.html / tests
- 待驗證：真資料、大模型注意力、OpenMVS 自動化、NeRF/GS、手機端
- 不回填：完整商用品替代宣稱
- 回填主文件：MRL_工程日誌.md、MRL_世界模組工程書_v1.md、MRL_母體定義檔_v1.md
- 下一步：接一組真實 COLMAP 輸出做 P1 驗收
