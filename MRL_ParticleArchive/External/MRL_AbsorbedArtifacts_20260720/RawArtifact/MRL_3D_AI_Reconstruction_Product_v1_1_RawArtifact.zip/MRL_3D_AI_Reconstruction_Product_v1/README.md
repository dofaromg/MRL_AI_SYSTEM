# MRL_3D_AI_Reconstruction_Product_v1.1

正式名稱：`MRL_3D_AI_Reconstruction_Product_v1`  
版本：`v1.1.0`  
歸屬：MrLiou / MRL 系統  
分支：`MRL_Branch_3D_AI_Reconstruction_Attention_Context_v1`

產品級 3D 立體成像輔助管線：

`COLMAP/SfM 輸入 → AI 注意力加權重投影誤差 → ContextGraph 視角連結 → NBV/補拍姿態提示 → Quality Gate → HTML 報告 + heatmap + JSON 報表`

## v1.1 補強內容

- 新增 `QualityGate`：輸出 `quality_gate.json`，給 pass / warn / fail。
- 新增 `report.html`：產品級可視化檢視頁，可直接打開看 heatmap 與建議。
- 新增 heatmap PNG 輸出：除 `.txt` 數值圖外，也輸出 `.png`。
- 補強 COLMAP loader：讀取 `images.txt` 影像名稱，若 `data/images/` 有原圖會載入原圖；沒有則用空白圖。
- 新增 mesh 偵測：自動尋找 `adapters/openmvs/mesh.glb / mesh.obj / mesh.ply`。
- 補強補拍建議：每個高風險 tile 都有 `reshoot_pose_hint`，包含 current camera center、target ray、suggested side-step center。
- 新增 API `/validate`。
- 新增 COLMAP fixture 測試。

## 快速啟動

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
PYTHONPATH=src python -m mrl3d.main --config config/config.example.yaml
PYTHONPATH=src pytest -q
```

輸出在 `data/outputs/`：

- `metrics.json`：每張相機影像的 p50 / p90 / raw reprojection error
- `suggestions.json`：補拍 / 補算建議與 tile pose hints
- `links.json`：視角上下文連結
- `quality_gate.json`：產品驗收狀態
- `report.html`：可打開的視覺化報告
- `heatmap_*.png`：影像 heatmap 圖
- `heatmap_*.txt`：heatmap 數值圖
- `run_manifest.json`：本次執行摘要與 hash

## 驗證模式

```bash
PYTHONPATH=src python -m mrl3d.main --config config/config.example.yaml --validate
```

## 接真實 COLMAP

把 COLMAP text model 放入：

```text
adapters/colmap/cameras.txt
adapters/colmap/images.txt
adapters/colmap/points3D.txt
```

可選：把原始影像放入：

```text
data/images/<COLMAP images.txt 裡的 IMAGE_NAME>
```

設定：

```yaml
simulate: false
```

再執行：

```bash
PYTHONPATH=src python -m mrl3d.main --config config/config.example.yaml
```

## REST API

```bash
PYTHONPATH=src uvicorn mrl3d.api:app --host 0.0.0.0 --port 8080
```

端點：

- `GET /health`
- `POST /validate` body: `{ "config_path": "config/config.example.yaml" }`
- `POST /run` body: `{ "config_path": "config/config.example.yaml" }`

## Docker

```bash
docker compose up --build
```

## 目前邊界

已可跑產品管線；但仍不是完整 Polycam 替代品。已完成的是：AI 注意力誤差分析、上下文補缺、補拍提示、報告輸出、COLMAP text 接口。下一階段才是完整 OpenMVS 自動呼叫、NeRF / Gaussian Splatting 補洞、ARKit / ARCore 手機端採集。
