from __future__ import annotations
import numpy as np
from .types import Scene
from .utils import project, huber, normalize01

class ErrorMapper:
    def __init__(self, cfg: dict):
        self.cfg = cfg
        self.ecfg = cfg.get("error", {})

    def make(self, scene: Scene, attn_maps: dict[str, np.ndarray]) -> tuple[dict[str, np.ndarray], dict]:
        heatmaps = {cid: np.zeros((cam.height, cam.width), dtype=np.float32) for cid, cam in scene.cameras.items()}
        counts = {cid: np.zeros((cam.height, cam.width), dtype=np.int32) for cid, cam in scene.cameras.items()}
        weighted_errors = {cid: [] for cid in scene.cameras}
        raw_errors = {cid: [] for cid in scene.cameras}
        delta = float(self.ecfg.get("huber_delta_px", 3.0))
        for tr in scene.tracks:
            cam = scene.cameras[tr.camera_id]
            X = scene.points.get(tr.point_id)
            if X is None: continue
            uv_hat = project(cam.K, cam.R, cam.t, X)
            if uv_hat is None: continue
            u, v = tr.uv
            e = float(np.linalg.norm(np.array([u, v]) - uv_hat))
            ee = huber(e, delta) if self.ecfg.get("robust", "huber") == "huber" else e
            ui, vi = int(round(u)), int(round(v))
            if 0 <= ui < cam.width and 0 <= vi < cam.height:
                a = float(attn_maps[tr.camera_id][vi, ui])
                val = a * ee
                heatmaps[tr.camera_id][vi, ui] += val
                counts[tr.camera_id][vi, ui] += 1
                weighted_errors[tr.camera_id].append(val)
                raw_errors[tr.camera_id].append(e)
        metrics = {"per_camera": {}, "global": {}}
        all_weighted = []
        for cid, hm in heatmaps.items():
            cnt = counts[cid].copy(); cnt[cnt == 0] = 1
            hm = hm / cnt
            if self.ecfg.get("normalize_heatmap", True):
                hm = normalize01(hm)
            heatmaps[cid] = hm.astype(np.float32)
            vals = np.array(weighted_errors[cid], dtype=float)
            raws = np.array(raw_errors[cid], dtype=float)
            all_weighted.extend(vals.tolist())
            metrics["per_camera"][cid] = {
                "track_count": int(len(vals)),
                "weighted_error_mean": float(vals.mean()) if vals.size else 0.0,
                "weighted_error_p50": float(np.percentile(vals, 50)) if vals.size else 0.0,
                "weighted_error_p90": float(np.percentile(vals, 90)) if vals.size else 0.0,
                "raw_reprojection_px_mean": float(raws.mean()) if raws.size else 0.0,
                "raw_reprojection_px_p90": float(np.percentile(raws, 90)) if raws.size else 0.0,
            }
        av = np.array(all_weighted, dtype=float)
        metrics["global"] = {
            "track_count": int(len(av)),
            "weighted_error_mean": float(av.mean()) if av.size else 0.0,
            "weighted_error_p90": float(np.percentile(av, 90)) if av.size else 0.0,
        }
        return heatmaps, metrics
