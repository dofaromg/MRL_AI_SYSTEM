from __future__ import annotations
import hashlib
import json
from typing import Any
import numpy as np


def project(K: np.ndarray, R: np.ndarray, t: np.ndarray, X: np.ndarray) -> np.ndarray | None:
    x = R @ X.reshape(3) + t.reshape(3)
    if x[2] <= 1e-8:
        return None
    u = K @ x
    return np.array([u[0] / u[2], u[1] / u[2]], dtype=float)


def camera_center(R: np.ndarray, t: np.ndarray) -> np.ndarray:
    return -R.T @ t.reshape(3)


def pixel_ray_world(K: np.ndarray, R: np.ndarray, u: float, v: float) -> np.ndarray:
    invK = np.linalg.inv(K)
    d_cam = invK @ np.array([u, v, 1.0], dtype=float)
    d_world = R.T @ d_cam
    n = np.linalg.norm(d_world)
    return d_world / (n + 1e-12)


def huber(e: float, delta: float) -> float:
    a = abs(float(e))
    return 0.5 * a * a if a <= delta else delta * (a - 0.5 * delta)


def normalize01(a: np.ndarray) -> np.ndarray:
    a = a.astype(np.float32)
    mn = float(np.nanmin(a)) if a.size else 0.0
    mx = float(np.nanmax(a)) if a.size else 0.0
    if mx - mn < 1e-9:
        return np.zeros_like(a, dtype=np.float32)
    return (a - mn) / (mx - mn)


def stable_hash(obj: Any) -> str:
    s = json.dumps(obj, ensure_ascii=False, sort_keys=True, default=str)
    return hashlib.sha256(s.encode("utf-8")).hexdigest()


def tile_scores(heatmap: np.ndarray, rows: int, cols: int):
    h, w = heatmap.shape
    out = []
    for r in range(rows):
        y0, y1 = int(r*h/rows), int((r+1)*h/rows)
        for c in range(cols):
            x0, x1 = int(c*w/cols), int((c+1)*w/cols)
            patch = heatmap[y0:y1, x0:x1]
            score = float(np.percentile(patch, 90)) if patch.size else 0.0
            mean = float(patch.mean()) if patch.size else 0.0
            out.append({"tile_rc": [r, c], "bbox_xyxy": [x0, y0, x1, y1], "score": score, "mean": mean})
    return out
