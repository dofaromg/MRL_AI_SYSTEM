from __future__ import annotations
import numpy as np
from .types import Scene
from .utils import tile_scores, camera_center, pixel_ray_world

class GapFiller:
    def __init__(self, cfg: dict):
        self.cfg = cfg
        self.gcfg = cfg.get("gap_fill", {})

    def propose(self, scene: Scene, heatmaps: dict, links: list[dict], metrics: dict) -> dict:
        rows, cols = self.gcfg.get("tiles", [6, 8])
        topk = int(self.gcfg.get("topk_per_image", 6))
        threshold = float(self.gcfg.get("high_risk_threshold", 1.25))
        per_image = []
        global_candidates = []
        link_map = {}
        for e in links:
            link_map.setdefault(e["from"], []).append(e)
        for cid, hm in heatmaps.items():
            cam = scene.cameras[cid]
            tiles = tile_scores(hm, int(rows), int(cols))
            tiles.sort(key=lambda t: t["score"], reverse=True)
            mean = metrics["per_camera"].get(cid, {}).get("weighted_error_mean", 0.0)
            p90 = metrics["per_camera"].get(cid, {}).get("weighted_error_p90", 0.0)
            selected = []
            for t in tiles[:topk]:
                t = dict(t)
                t["reshoot_pose_hint"] = self._pose_hint(cam, t["bbox_xyxy"])
                selected.append(t)
            action = "reshoot_or_add_view" if p90 > threshold*max(mean, 1e-6) else "recompute_dense_or_texture"
            hints = [
                "move sideways relative to current camera, not only closer",
                "keep 60-70 percent overlap with linked views",
                "increase parallax around highlighted tile",
                "avoid reflection, motion blur, and pure-white or pure-black exposure",
            ]
            quality_state = "needs_extra_view" if action == "reshoot_or_add_view" else "can_recompute_first"
            rec = {
                "image_id": cid,
                "image_name": cam.name,
                "quality_state": quality_state,
                "action": action,
                "top_tiles": selected,
                "linked_views": link_map.get(cid, []),
                "hints": hints,
            }
            per_image.append(rec)
            for t in selected:
                global_candidates.append({"image_id": cid, "image_name": cam.name, **t})
        global_candidates.sort(key=lambda x: x["score"], reverse=True)
        return {
            "version": "1.1.0",
            "strategy": "attention_weighted_reprojection_context_gap_fill_with_pose_hints",
            "per_image": per_image,
            "global_top": global_candidates[:int(self.gcfg.get("global_topk", 20))],
        }

    def _pose_hint(self, cam, bbox):
        x0, y0, x1, y1 = bbox
        u = (x0 + x1) / 2.0
        v = (y0 + y1) / 2.0
        center = camera_center(cam.R, cam.t)
        ray = pixel_ray_world(cam.K, cam.R, u, v)
        side = np.cross(ray, np.array([0.0, 0.0, 1.0]))
        side = side / (np.linalg.norm(side) + 1e-12)
        distance = float(self.gcfg.get("suggested_side_step_m", 0.35))
        suggested_center = center + side * distance
        return {
            "current_camera_center_xyz": [float(x) for x in center],
            "target_ray_world_xyz": [float(x) for x in ray],
            "suggested_camera_center_xyz": [float(x) for x in suggested_center],
            "side_step_m": distance,
            "tile_center_uv": [float(u), float(v)],
            "note": "side-step around this ray and keep target tile visible",
        }
