from __future__ import annotations
import pathlib
from typing import Dict
import numpy as np
from PIL import Image

from .types import Camera, Scene, Track
from .utils import project

class SfMBackend:
    def __init__(self, cfg: dict):
        self.cfg = cfg
        self.root = pathlib.Path(cfg["_root"])
        self.rng = np.random.default_rng(int(cfg.get("seed", 42)))

    def load(self) -> Scene:
        if bool(self.cfg.get("simulate", True)):
            return self._simulate()
        return self._load_colmap_text()

    def _simulate(self) -> Scene:
        sim = self.cfg.get("simulation", {})
        ncam = int(sim.get("cameras", 6))
        npts = int(sim.get("points", 800))
        W = int(sim.get("image_width", 640)); H = int(sim.get("image_height", 480))
        track_p = float(sim.get("track_probability", 0.62))
        noise = float(sim.get("pixel_noise", 1.1))
        f = 0.9 * W
        K = np.array([[f, 0, W/2], [0, f, H/2], [0, 0, 1]], dtype=float)

        cameras: Dict[str, Camera] = {}
        images: Dict[str, np.ndarray] = {}
        for i in range(ncam):
            theta = 2*np.pi*i/ncam
            center = np.array([4*np.cos(theta), 4*np.sin(theta), 1.2 + 0.2*np.sin(theta)])
            target = np.array([0,0,0.6])
            z = (target-center); z = z/np.linalg.norm(z)
            up = np.array([0,0,1.0])
            x = np.cross(z, up); x = x/(np.linalg.norm(x)+1e-9)
            y = np.cross(x, z)
            Rcw = np.stack([x, y, z], axis=0)
            t = -Rcw @ center
            cid = f"cam_{i:03d}"
            cameras[cid] = Camera(cid, W, H, K.copy(), Rcw, t, name=f"sim_{i:03d}.png")
            yy, xx = np.mgrid[0:H, 0:W]
            img = np.zeros((H,W,3), dtype=np.uint8)
            img[...,0] = ((xx/W)*255).astype(np.uint8)
            img[...,1] = ((yy/H)*255).astype(np.uint8)
            img[...,2] = self.rng.integers(0, 45, size=(H,W), dtype=np.uint8)
            images[cid] = img

        points: Dict[str, np.ndarray] = {}
        for j in range(npts):
            X = self.rng.normal(size=3)
            X[:2] *= 0.9
            X[2] = self.rng.uniform(-0.1, 1.4)
            points[f"pt_{j:05d}"] = X.astype(float)

        tracks: list[Track] = []
        for pid, X in points.items():
            for cid, cam in cameras.items():
                if self.rng.random() > track_p:
                    continue
                uv = project(cam.K, cam.R, cam.t, X)
                if uv is None: continue
                uv = uv + self.rng.normal(0, noise, size=2)
                if 0 <= uv[0] < cam.width and 0 <= uv[1] < cam.height:
                    tracks.append(Track(cid, pid, (float(uv[0]), float(uv[1]))))
        return Scene(cameras, points, tracks, images, "simulation", mesh_path=None, meta={"mode":"simulate"})

    def _load_colmap_text(self) -> Scene:
        colmap = self.root / self.cfg.get("colmap_dir", "adapters/colmap")
        cams_path = colmap / "cameras.txt"
        imgs_path = colmap / "images.txt"
        pts_path = colmap / "points3D.txt"
        missing = [str(p) for p in [cams_path, imgs_path, pts_path] if not p.exists()]
        if missing:
            raise FileNotFoundError("COLMAP text files missing: " + ", ".join(missing))
        camera_models = self._parse_cameras(cams_path)
        images_raw = self._parse_images(imgs_path)
        points_raw = self._parse_points(pts_path)

        cameras: Dict[str, Camera] = {}
        tracks: list[Track] = []
        points: Dict[str, np.ndarray] = {str(pid): xyz for pid, xyz in points_raw.items()}
        rendered_images: Dict[str, np.ndarray] = {}
        for img_id, rec in images_raw.items():
            cam_def = camera_models[rec["camera_id"]]
            K = cam_def["K"]
            R = self._qvec_to_rotmat(rec["qvec"])
            t = rec["tvec"]
            cid = str(img_id)
            cameras[cid] = Camera(cid, cam_def["width"], cam_def["height"], K, R, t, name=rec.get("name", cid))
            rendered_images[cid] = self._load_image_or_blank(rec.get("name", ""), cam_def["width"], cam_def["height"])
            for x, y, point3d_id in rec["xys"]:
                if point3d_id != -1 and str(point3d_id) in points:
                    tracks.append(Track(cid, str(point3d_id), (x, y)))
        mesh = self._find_mesh_path()
        return Scene(cameras, points, tracks, rendered_images, "colmap_text", mesh_path=mesh, meta={"colmap_dir": str(colmap)})

    def _load_image_or_blank(self, name: str, width: int, height: int) -> np.ndarray:
        images_dir = self.root / self.cfg.get("images_dir", "data/images")
        candidates = [images_dir / name, self.root / name]
        for p in candidates:
            if p.exists() and p.is_file():
                try:
                    img = Image.open(p).convert("RGB").resize((width, height))
                    return np.asarray(img, dtype=np.uint8)
                except Exception:
                    pass
        return np.zeros((height, width, 3), dtype=np.uint8)

    def _find_mesh_path(self) -> str | None:
        mvs = self.root / self.cfg.get("mvs_dir", "adapters/openmvs")
        for name in ["mesh.glb", "mesh.obj", "mesh.ply", "scene_dense_mesh.ply"]:
            p = mvs / name
            if p.exists(): return str(p)
        return None

    def _parse_cameras(self, path: pathlib.Path) -> dict:
        out = {}
        for line in path.read_text(encoding="utf-8", errors="ignore").splitlines():
            line = line.strip()
            if not line or line.startswith("#"): continue
            parts = line.split()
            cid = int(parts[0]); model = parts[1]; width = int(parts[2]); height = int(parts[3]); params = list(map(float, parts[4:]))
            if model in {"SIMPLE_PINHOLE", "SIMPLE_RADIAL", "RADIAL"}:
                f, cx, cy = params[0], params[1], params[2]
                K = np.array([[f,0,cx],[0,f,cy],[0,0,1]], dtype=float)
            else:
                fx, fy, cx, cy = params[0], params[1], params[2], params[3]
                K = np.array([[fx,0,cx],[0,fy,cy],[0,0,1]], dtype=float)
            out[cid] = {"model": model, "width": width, "height": height, "K": K}
        return out

    def _parse_images(self, path: pathlib.Path) -> dict:
        lines = [l.strip() for l in path.read_text(encoding="utf-8", errors="ignore").splitlines() if l.strip() and not l.strip().startswith("#")]
        out = {}; i = 0
        while i < len(lines):
            parts = lines[i].split()
            if len(parts) < 10:
                i += 1; continue
            img_id = int(parts[0]); qvec = np.array(list(map(float, parts[1:5]))); tvec = np.array(list(map(float, parts[5:8]))); camera_id = int(parts[8])
            name = " ".join(parts[9:]) if len(parts) > 9 else str(img_id)
            xys = []
            if i + 1 < len(lines):
                xy_parts = lines[i+1].split()
                for k in range(0, len(xy_parts)-2, 3):
                    xys.append((float(xy_parts[k]), float(xy_parts[k+1]), int(float(xy_parts[k+2]))))
            out[img_id] = {"qvec": qvec, "tvec": tvec, "camera_id": camera_id, "xys": xys, "name": name}
            i += 2
        return out

    def _parse_points(self, path: pathlib.Path) -> dict:
        out = {}
        for line in path.read_text(encoding="utf-8", errors="ignore").splitlines():
            line = line.strip()
            if not line or line.startswith("#"): continue
            parts = line.split()
            if len(parts) < 4: continue
            out[int(parts[0])] = np.array([float(parts[1]), float(parts[2]), float(parts[3])], dtype=float)
        return out

    def _qvec_to_rotmat(self, qvec: np.ndarray) -> np.ndarray:
        qw, qx, qy, qz = qvec / (np.linalg.norm(qvec) + 1e-12)
        return np.array([
            [1 - 2*qy*qy - 2*qz*qz, 2*qx*qy - 2*qz*qw, 2*qx*qz + 2*qy*qw],
            [2*qx*qy + 2*qz*qw, 1 - 2*qx*qx - 2*qz*qz, 2*qy*qz - 2*qx*qw],
            [2*qx*qz - 2*qy*qw, 2*qy*qz + 2*qx*qw, 1 - 2*qx*qx - 2*qy*qy]
        ], dtype=float)
