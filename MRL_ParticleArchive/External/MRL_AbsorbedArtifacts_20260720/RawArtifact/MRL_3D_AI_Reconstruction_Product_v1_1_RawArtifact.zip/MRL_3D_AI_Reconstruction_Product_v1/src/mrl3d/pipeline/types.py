from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, List, Tuple, Optional
import numpy as np

@dataclass
class Camera:
    id: str
    width: int
    height: int
    K: np.ndarray
    R: np.ndarray
    t: np.ndarray
    name: str = ""

@dataclass
class Track:
    camera_id: str
    point_id: str
    uv: Tuple[float, float]

@dataclass
class Scene:
    cameras: Dict[str, Camera]
    points: Dict[str, np.ndarray]
    tracks: List[Track]
    images: Dict[str, np.ndarray]
    source: str
    mesh_path: Optional[str] = None
    meta: dict = field(default_factory=dict)
