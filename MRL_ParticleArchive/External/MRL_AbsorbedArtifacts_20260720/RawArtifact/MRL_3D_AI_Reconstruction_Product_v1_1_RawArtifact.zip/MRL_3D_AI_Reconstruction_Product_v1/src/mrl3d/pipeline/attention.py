from __future__ import annotations
import numpy as np
from .utils import normalize01

class AttentionBackend:
    """Content-aware attention maps.

    Product mode uses deterministic no-network attention so the system can run locally.
    It can later be replaced with DINO/ViT while keeping the same output contract.
    """
    def __init__(self, cfg: dict):
        self.cfg = cfg
        self.acfg = cfg.get("attention", {})

    def compute(self, images: dict[str, np.ndarray]) -> dict[str, np.ndarray]:
        maps = {}
        for cid, img in images.items():
            maps[cid] = self._simple_attention(img)
        return maps

    def _simple_attention(self, img: np.ndarray) -> np.ndarray:
        h, w = img.shape[:2]
        gray = img.astype(np.float32).mean(axis=2) if img.ndim == 3 else img.astype(np.float32)
        yy, xx = np.mgrid[0:h, 0:w]
        center = 1.0 - np.sqrt(((xx - w/2)/(w/2 + 1e-6))**2 + ((yy - h/2)/(h/2 + 1e-6))**2)
        center = np.clip(center, 0, 1)
        gx = np.zeros_like(gray); gy = np.zeros_like(gray)
        gx[:,1:-1] = np.abs(gray[:,2:] - gray[:,:-2])
        gy[1:-1,:] = np.abs(gray[2:,:] - gray[:-2,:])
        edge = normalize01(gx + gy)
        # Local texture confidence: high variance gives reliable matching; too low gets down-weighted.
        texture = normalize01(np.abs(gray - gray.mean()))
        cw = float(self.acfg.get("center_weight", 0.45))
        ew = float(self.acfg.get("edge_weight", 0.35))
        tw = float(self.acfg.get("texture_weight", 0.20))
        low_penalty = float(self.acfg.get("low_texture_penalty", 0.35))
        attn = cw*center + ew*edge + tw*texture
        attn = normalize01(attn)
        attn = np.where(texture < np.percentile(texture, 20), attn*low_penalty, attn)
        return normalize01(attn).astype(np.float32)
