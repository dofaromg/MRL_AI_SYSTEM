from __future__ import annotations
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from .main import run, validate

app = FastAPI(title="MRL 3D AI Reconstruction API", version="1.1.0")

class RunRequest(BaseModel):
    config_path: str = "config/config.example.yaml"

@app.get("/health")
def health():
    return {"ok": True, "service": "MRL_3D_AI_Reconstruction_Product_v1", "version": "1.1.0"}

@app.post("/validate")
def validate_pipeline(req: RunRequest):
    try:
        return validate(req.config_path)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/run")
def run_pipeline(req: RunRequest):
    try:
        return run(req.config_path)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
