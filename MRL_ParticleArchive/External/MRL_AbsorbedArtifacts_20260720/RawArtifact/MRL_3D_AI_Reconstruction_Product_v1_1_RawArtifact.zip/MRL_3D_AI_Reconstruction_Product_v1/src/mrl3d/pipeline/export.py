from __future__ import annotations
import json
import pathlib
import time
import numpy as np
from PIL import Image
from .types import Scene
from .utils import stable_hash

class Exporter:
    def __init__(self, cfg: dict):
        self.cfg = cfg
        self.root = pathlib.Path(cfg["_root"])
        self.out = self.root / cfg.get("out_dir", "data/outputs")
        self.out.mkdir(parents=True, exist_ok=True)
        self.ecfg = cfg.get("export", {})

    def dump(self, scene: Scene, heatmaps: dict[str, np.ndarray], metrics: dict, links: list, suggestions: dict, quality: dict) -> dict:
        self._json("metrics.json", metrics)
        self._json("links.json", links)
        self._json("suggestions.json", suggestions)
        self._json("quality_gate.json", quality)
        cams = {cid: {"name": cam.name, "width": cam.width, "height": cam.height, "K": cam.K.tolist(), "R": cam.R.tolist(), "t": cam.t.tolist()} for cid, cam in scene.cameras.items()}
        self._json("cameras.json", cams)
        heatmap_files = []
        for cid, hm in heatmaps.items():
            txt = f"heatmap_{cid}.txt"
            np.savetxt(self.out / txt, hm, fmt="%.6f")
            heatmap_files.append(txt)
            if self.ecfg.get("heatmap_png", True):
                png = f"heatmap_{cid}.png"
                self._write_png(self.out / png, hm)
                heatmap_files.append(png)
        self._write_html_report(scene, metrics, suggestions, quality, heatmap_files)
        manifest = {
            "product": "MRL_3D_AI_Reconstruction_Product_v1",
            "version": "1.1.0",
            "source": scene.source,
            "mesh_path": scene.mesh_path,
            "camera_count": len(scene.cameras),
            "point_count": len(scene.points),
            "track_count": len(scene.tracks),
            "heatmap_count": len(heatmaps),
            "suggestion_count": sum(len(x.get("top_tiles", [])) for x in suggestions.get("per_image", [])),
            "quality_status": quality.get("status"),
            "out_dir": str(self.out),
            "created_at_unix": int(time.time()),
            "files": ["metrics.json", "links.json", "suggestions.json", "quality_gate.json", "cameras.json", "report.html", *heatmap_files],
        }
        manifest["run_hash"] = stable_hash({"metrics": metrics, "links": links, "suggestions": suggestions, "quality": quality})
        self._json("run_manifest.json", manifest)
        return manifest

    def _write_png(self, path: pathlib.Path, hm: np.ndarray) -> None:
        arr = np.clip(hm, 0, 1)
        img = (arr * 255).astype(np.uint8)
        Image.fromarray(img, mode="L").save(path)

    def _write_html_report(self, scene: Scene, metrics: dict, suggestions: dict, quality: dict, heatmap_files: list[str]) -> None:
        rows = []
        for rec in suggestions.get("per_image", []):
            cid = rec["image_id"]
            m = metrics.get("per_camera", {}).get(cid, {})
            top = rec.get("top_tiles", [{}])[0]
            rows.append(f"<tr><td>{cid}</td><td>{rec.get('image_name','')}</td><td>{rec.get('quality_state')}</td><td>{rec.get('action')}</td><td>{m.get('raw_reprojection_px_p90',0):.3f}</td><td>{top.get('score',0):.3f}</td></tr>")
        imgs = []
        for f in heatmap_files:
            if f.endswith('.png'):
                imgs.append(f"<div class='card'><h3>{f}</h3><img src='{f}' /></div>")
        html = f"""<!doctype html><html lang='zh-Hant'><head><meta charset='utf-8'/><title>MRL 3D AI Reconstruction Report</title>
<style>body{{font-family:Arial,'Noto Sans TC',sans-serif;background:#101114;color:#eee;margin:24px}}table{{border-collapse:collapse;width:100%;margin:16px 0}}td,th{{border:1px solid #444;padding:8px}}.pass{{color:#7CFC9B}}.warn{{color:#FFD166}}.fail{{color:#FF6B6B}}.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:16px}}.card{{background:#1b1d24;border:1px solid #333;border-radius:12px;padding:12px}}img{{width:100%;image-rendering:pixelated;border-radius:8px}}</style></head>
<body><h1>MRL_3D_AI_Reconstruction_Product_v1｜Report v1.1.0</h1>
<p>source={scene.source} camera_count={len(scene.cameras)} point_count={len(scene.points)} track_count={len(scene.tracks)}</p>
<h2>Quality Gate: <span class='{quality.get('status')}'>{quality.get('status')}</span></h2><pre>{json.dumps(quality, ensure_ascii=False, indent=2)}</pre>
<h2>Suggestions</h2><table><thead><tr><th>image_id</th><th>name</th><th>state</th><th>action</th><th>raw p90 px</th><th>top tile score</th></tr></thead><tbody>{''.join(rows)}</tbody></table>
<h2>Heatmaps</h2><div class='grid'>{''.join(imgs)}</div></body></html>"""
        (self.out / "report.html").write_text(html, encoding="utf-8")

    def _json(self, name: str, data) -> None:
        (self.out / name).write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
