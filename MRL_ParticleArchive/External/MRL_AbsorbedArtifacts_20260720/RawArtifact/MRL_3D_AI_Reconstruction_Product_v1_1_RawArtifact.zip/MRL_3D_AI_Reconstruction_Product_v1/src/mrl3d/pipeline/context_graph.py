from __future__ import annotations
import numpy as np
from .types import Scene
from .utils import normalize01

class ContextGraph:
    def __init__(self, cfg: dict):
        self.cfg = cfg
        self.ccfg = cfg.get("context", {})

    def build(self, scene: Scene, heatmaps: dict[str, np.ndarray]) -> list[dict]:
        ids = list(scene.cameras.keys())
        sig = {cid: self._signature(heatmaps[cid]) for cid in ids}
        edges = []
        for i, a in enumerate(ids):
            scored = []
            for b in ids:
                if a == b: continue
                score = self._complementarity(sig[a], sig[b])
                if score >= float(self.ccfg.get("min_complementarity", 0.08)):
                    scored.append((b, score))
            scored.sort(key=lambda x: x[1], reverse=True)
            for b, score in scored[:int(self.ccfg.get("link_topk", 3))]:
                edges.append({"from": a, "to": b, "complementarity": float(score), "reason": "heatmap coverage complement"})
        return edges

    def _signature(self, hm: np.ndarray) -> np.ndarray:
        rows, cols = 4, 4
        h, w = hm.shape
        vals = []
        for r in range(rows):
            for c in range(cols):
                vals.append(float(hm[int(r*h/rows):int((r+1)*h/rows), int(c*w/cols):int((c+1)*w/cols)].mean()))
        return normalize01(np.array(vals, dtype=np.float32))

    def _complementarity(self, a: np.ndarray, b: np.ndarray) -> float:
        # high when b is strong where a is weak; useful for view pairing.
        return float(np.mean((1.0 - a) * b))
