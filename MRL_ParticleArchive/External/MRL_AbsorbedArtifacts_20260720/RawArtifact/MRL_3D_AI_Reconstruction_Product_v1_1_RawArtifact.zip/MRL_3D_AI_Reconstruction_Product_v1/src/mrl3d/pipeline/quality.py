from __future__ import annotations

class QualityGate:
    def __init__(self, cfg: dict):
        self.cfg = cfg
        self.qcfg = cfg.get("quality_gate", {})

    def evaluate(self, metrics: dict, suggestions: dict, scene) -> dict:
        max_p90 = float(self.qcfg.get("max_raw_p90_px", 5.0))
        min_tracks = int(self.qcfg.get("min_tracks", 50))
        track_count = int(metrics.get("global", {}).get("track_count", 0))
        worst = max((v.get("raw_reprojection_px_p90", 0.0) for v in metrics.get("per_camera", {}).values()), default=0.0)
        high_tiles = [x for x in suggestions.get("global_top", []) if float(x.get("score", 0.0)) >= float(self.qcfg.get("high_tile_score", 0.65))]
        failures = []
        warnings = []
        if track_count < min_tracks:
            failures.append(f"track_count below minimum: {track_count} < {min_tracks}")
        if worst > max_p90:
            warnings.append(f"worst raw p90 reprojection error high: {worst:.3f}px > {max_p90:.3f}px")
        if len(high_tiles) > int(self.qcfg.get("max_high_tiles", 24)):
            warnings.append(f"too many high-risk tiles: {len(high_tiles)}")
        status = "fail" if failures else ("warn" if warnings else "pass")
        return {
            "version": "1.1.0",
            "status": status,
            "failures": failures,
            "warnings": warnings,
            "thresholds": {"max_raw_p90_px": max_p90, "min_tracks": min_tracks},
            "observed": {"track_count": track_count, "worst_raw_p90_px": worst, "high_risk_tile_count": len(high_tiles), "camera_count": len(scene.cameras)},
        }
