from __future__ import annotations
import argparse
import pathlib
import yaml

from .pipeline.sfm import SfMBackend
from .pipeline.attention import AttentionBackend
from .pipeline.error_map import ErrorMapper
from .pipeline.context_graph import ContextGraph
from .pipeline.gap_fill import GapFiller
from .pipeline.quality import QualityGate
from .pipeline.export import Exporter


def _load_cfg(config_path: str) -> dict:
    cfg = yaml.safe_load(open(config_path, "r", encoding="utf-8"))
    root = pathlib.Path(config_path).resolve().parents[1]
    cfg["_root"] = str(root)
    pathlib.Path(root / cfg["out_dir"]).mkdir(parents=True, exist_ok=True)
    return cfg


def run(config_path: str) -> dict:
    cfg = _load_cfg(config_path)
    sfm = SfMBackend(cfg)
    scene = sfm.load()
    attention = AttentionBackend(cfg).compute(scene.images)
    heatmaps, metrics = ErrorMapper(cfg).make(scene, attention)
    links = ContextGraph(cfg).build(scene, heatmaps)
    suggestions = GapFiller(cfg).propose(scene, heatmaps, links, metrics)
    quality = QualityGate(cfg).evaluate(metrics, suggestions, scene)
    manifest = Exporter(cfg).dump(scene, heatmaps, metrics, links, suggestions, quality)
    return manifest


def validate(config_path: str) -> dict:
    cfg = _load_cfg(config_path)
    scene = SfMBackend(cfg).load()
    return {
        "ok": True,
        "source": scene.source,
        "camera_count": len(scene.cameras),
        "point_count": len(scene.points),
        "track_count": len(scene.tracks),
        "has_mesh": bool(scene.mesh_path),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="MRL 3D AI Reconstruction Product Pipeline")
    parser.add_argument("--config", required=True, help="Path to YAML config")
    parser.add_argument("--validate", action="store_true", help="Only validate input and exit")
    args = parser.parse_args()
    if args.validate:
        result = validate(args.config)
        print(result)
        return
    manifest = run(args.config)
    print(f"MRL_3D_AI_Reconstruction complete: {manifest['out_dir']}")
    print(f"quality={manifest['quality_status']} suggestions={manifest['suggestion_count']} heatmaps={manifest['heatmap_count']}")


if __name__ == "__main__":
    main()
