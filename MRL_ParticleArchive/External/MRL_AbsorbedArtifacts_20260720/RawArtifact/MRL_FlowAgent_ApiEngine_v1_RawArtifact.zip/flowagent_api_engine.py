#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
═══════════════════════════════════════════════════════════════════════════════
    FlowAgent API Engine v1.0
    整合 API 啟動器 + 語義粒子鏈能力模組
    
    包含：
    - /run          種子邏輯鏈執行
    - /translate    文本 → fltnz
    - /restore      fltnz → 文本
    - /simulate     人格模擬
    - /expand       粒子展開 (P_{k+1} = N · P · η)
    - /collapse     粒子塌縮
    - /chain        語義粒子鏈完整循環
    
    @origin_signature("MrLiouWord")
    @version: v1.0
═══════════════════════════════════════════════════════════════════════════════
"""

from fastapi import FastAPI, Body, HTTPException
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
from typing import Any, Dict, List, Optional
from dataclasses import dataclass, field, asdict
from enum import Enum
import hashlib
import json
import os
import time

# ═══════════════════════════════════════════════════════════════════════════════
# 常量
# ═══════════════════════════════════════════════════════════════════════════════

VERSION = "1.0.0"
SIGNATURE = "MRSIG-FLOWAGENT-API-V1"
MODEL_DIR = "models"

# ═══════════════════════════════════════════════════════════════════════════════
# 資料模型
# ═══════════════════════════════════════════════════════════════════════════════

class LogicInput(BaseModel):
    data: str

class TranslateInput(BaseModel):
    text: str

class RestoreInput(BaseModel):
    fltnz: str

class SimulateInput(BaseModel):
    question: str
    persona: str = "MrLiou.flpkg"

class ExpandInput(BaseModel):
    particle_id: str
    content: Any
    N: int = 2
    eta: float = 1.0

class CollapseInput(BaseModel):
    particles: List[Dict[str, Any]]

class ChainInput(BaseModel):
    """語義粒子鏈輸入"""
    input_text: str
    persona: str = "default"

# ═══════════════════════════════════════════════════════════════════════════════
# 語義粒子鏈模組 (Ability Module)
# ═══════════════════════════════════════════════════════════════════════════════

class ModuleType(str, Enum):
    ORIGIN = "origin"           # 源頭
    DESCRIPTOR = "descriptor"   # 形容詞粒子
    OBJECT = "object"           # 名詞粒子
    COLLAPSE = "collapse"       # 塌縮核
    FLOW = "flow"               # 流態粒子
    REFLECT = "reflect"         # 反射記憶

@dataclass
class ParticleModule:
    """粒子模組基類"""
    module_id: str
    module_type: ModuleType
    properties: Dict[str, Any] = field(default_factory=dict)
    input_from: Optional[str] = None
    output_to: Optional[str] = None
    
    def process(self, data: Any) -> Any:
        raise NotImplementedError

class CoreModule(ParticleModule):
    """🟥 Module.Root.Core — 源頭核心"""
    def __init__(self):
        super().__init__(
            module_id="Core",
            module_type=ModuleType.ORIGIN,
            properties={
                "base_intention": None,
                "context_gravity": 1.0,
                "axis_alignment": "neutral"
            },
            output_to="fx.adj.112"
        )
    
    def process(self, data: Any) -> Dict[str, Any]:
        """提供初始視角與一致性軸心"""
        return {
            "source": "Core",
            "intention": data,
            "gravity": self.properties["context_gravity"],
            "axis": self.properties["axis_alignment"],
            "hash": hashlib.sha256(str(data).encode()).hexdigest()[:16]
        }

class DescriptorModule(ParticleModule):
    """🟧 Module.fx.adj.112 — 形容詞粒子模組"""
    def __init__(self):
        super().__init__(
            module_id="fx.adj.112",
            module_type=ModuleType.DESCRIPTOR,
            properties={
                "adj_vector": [],
                "modifier_bias": 0.0
            },
            input_from="Core",
            output_to="fx.noun.024"
        )
    
    def process(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """將原始訊號轉為描述性語義向量 — 為世界上色"""
        intention = data.get("intention", "")
        
        # 簡單的描述提取（實際可接 NLP）
        descriptors = self._extract_descriptors(intention)
        
        return {
            **data,
            "descriptor": {
                "adj_vector": descriptors,
                "color": self._determine_color(descriptors),
                "polarity": self._determine_polarity(intention)
            }
        }
    
    def _extract_descriptors(self, text: str) -> List[str]:
        # 簡化：提取形容詞性質詞
        qualities = ["積極", "消極", "中性", "複雜", "簡單"]
        return [q for q in qualities if any(c in text for c in q)] or ["中性"]
    
    def _determine_color(self, descriptors: List[str]) -> str:
        if "積極" in descriptors:
            return "warm"
        elif "消極" in descriptors:
            return "cool"
        return "neutral"
    
    def _determine_polarity(self, text: str) -> float:
        # -1 到 1 之間
        return 0.0

class ObjectModule(ParticleModule):
    """🟨 Module.fx.noun.024 — 名詞粒子模組"""
    def __init__(self):
        super().__init__(
            module_id="fx.noun.024",
            module_type=ModuleType.OBJECT,
            properties={
                "noun_core": None,
                "object_signature": ""
            },
            input_from="fx.adj.112",
            output_to="fx.collapse"
        )
    
    def process(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """將語義從描述落地成實體 — 讓抽象成為可被抓住的東西"""
        intention = data.get("intention", "")
        
        # 提取實體（主體、物件、焦點）
        entities = self._extract_entities(intention)
        
        return {
            **data,
            "object": {
                "noun_core": entities.get("subject"),
                "entities": entities,
                "signature": hashlib.sha256(
                    json.dumps(entities, ensure_ascii=False).encode()
                ).hexdigest()[:12]
            }
        }
    
    def _extract_entities(self, text: str) -> Dict[str, Any]:
        # 簡化：提取主體和焦點
        return {
            "subject": text[:20] if len(text) > 20 else text,
            "focus": text[-20:] if len(text) > 20 else text,
            "background": "default_context"
        }

class CollapseModule(ParticleModule):
    """🟩 Module.fx.collapse — 塌縮粒子（最關鍵的塌縮核）"""
    def __init__(self):
        super().__init__(
            module_id="fx.collapse",
            module_type=ModuleType.COLLAPSE,
            properties={
                "collapse_state": "pending",
                "weight_shift_map": {}
            },
            input_from="fx.noun.024",
            output_to="fx.flow.007"
        )
    
    def process(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """
        將形容詞粒子 × 名詞粒子 進行壓縮成「行為態」
        此處發生權重重新分配 — 語義塌縮，選擇一條現實路線
        """
        descriptor = data.get("descriptor", {})
        obj = data.get("object", {})
        
        # 塌縮計算：結合描述與實體
        collapsed = self._collapse(descriptor, obj)
        
        return {
            **data,
            "collapse": {
                "state": "collapsed",
                "behavior_mode": collapsed["mode"],
                "weight_distribution": collapsed["weights"],
                "chosen_path": collapsed["path"],
                "collapse_hash": hashlib.sha256(
                    json.dumps(collapsed, ensure_ascii=False).encode()
                ).hexdigest()[:12]
            }
        }
    
    def _collapse(self, descriptor: Dict, obj: Dict) -> Dict[str, Any]:
        """塌縮運算"""
        color = descriptor.get("color", "neutral")
        polarity = descriptor.get("polarity", 0.0)
        
        # 根據描述性質選擇路線
        if color == "warm" or polarity > 0.3:
            mode = "action"
            path = "execute"
        elif color == "cool" or polarity < -0.3:
            mode = "reflection"
            path = "analyze"
        else:
            mode = "observation"
            path = "observe"
        
        return {
            "mode": mode,
            "path": path,
            "weights": {
                "action": 0.4 if mode == "action" else 0.2,
                "thought": 0.4 if mode == "reflection" else 0.3,
                "observe": 0.4 if mode == "observation" else 0.3
            }
        }

class FlowModule(ParticleModule):
    """🟦 Module.fx.flow.007 — 流態粒子模組"""
    def __init__(self):
        super().__init__(
            module_id="fx.flow.007",
            module_type=ModuleType.FLOW,
            properties={
                "flow_vector": [],
                "continuity_factor": 1.0
            },
            input_from="fx.collapse",
            output_to="Memory.SelfReflect"
        )
    
    def process(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """
        將塌縮態轉換為「行為流動」
        決定動量和輸出方向 — 讓語義變成運動與行為
        """
        collapse = data.get("collapse", {})
        
        # 生成行為向量
        flow = self._generate_flow(collapse)
        
        return {
            **data,
            "flow": {
                "vector": flow["vector"],
                "momentum": flow["momentum"],
                "direction": flow["direction"],
                "output_type": flow["output_type"]
            }
        }
    
    def _generate_flow(self, collapse: Dict) -> Dict[str, Any]:
        """生成流動向量"""
        mode = collapse.get("behavior_mode", "observation")
        path = collapse.get("chosen_path", "observe")
        
        # 根據塌縮結果決定流動方向
        if mode == "action":
            return {
                "vector": [1.0, 0.5, 0.2],
                "momentum": 0.8,
                "direction": "forward",
                "output_type": "action"
            }
        elif mode == "reflection":
            return {
                "vector": [0.2, 0.8, 0.5],
                "momentum": 0.5,
                "direction": "inward",
                "output_type": "thought"
            }
        else:
            return {
                "vector": [0.5, 0.5, 0.5],
                "momentum": 0.3,
                "direction": "stable",
                "output_type": "plan"
            }

class ReflectModule(ParticleModule):
    """🟪 Module.Memory.SelfReflect — 自我反射模組"""
    def __init__(self):
        super().__init__(
            module_id="Memory.SelfReflect",
            module_type=ModuleType.REFLECT,
            properties={
                "reflection_trace": [],
                "core_adjustment_map": {}
            },
            input_from="fx.flow.007",
            output_to="Core"
        )
    
    def process(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """
        接收 flow 的成果，反射回 Core
        調整軸線、權重、偏振 — 形成下一循環的源頭
        """
        flow = data.get("flow", {})
        
        # 生成反射結果
        reflection = self._reflect(data)
        
        return {
            **data,
            "reflection": {
                "trace": reflection["trace"],
                "adjustments": reflection["adjustments"],
                "next_seed": reflection["next_seed"],
                "cycle_complete": True
            }
        }
    
    def _reflect(self, data: Dict) -> Dict[str, Any]:
        """反射計算"""
        flow = data.get("flow", {})
        collapse = data.get("collapse", {})
        
        return {
            "trace": [
                "Core → fx.adj.112 → fx.noun.024 → fx.collapse → fx.flow.007 → Memory.SelfReflect"
            ],
            "adjustments": {
                "gravity_delta": 0.0,
                "axis_shift": "none",
                "learned": flow.get("output_type", "unknown")
            },
            "next_seed": {
                "intention_hint": "based on " + collapse.get("chosen_path", "observe"),
                "carry_forward": data.get("hash", "")[:8]
            }
        }

# ═══════════════════════════════════════════════════════════════════════════════
# 語義粒子鏈引擎
# ═══════════════════════════════════════════════════════════════════════════════

class SemanticParticleChain:
    """
    語義粒子鏈能力模組引擎
    
    完整鏈路：
    [Core] → (Descriptor) fx.adj.112
          → (Object)     fx.noun.024
          → (Collapse)   fx.collapse
          → (Flow)       fx.flow.007
          → (Reflect)    Memory.SelfReflect
          → back to Core (new state)
    """
    
    def __init__(self):
        self.modules = {
            "Core": CoreModule(),
            "fx.adj.112": DescriptorModule(),
            "fx.noun.024": ObjectModule(),
            "fx.collapse": CollapseModule(),
            "fx.flow.007": FlowModule(),
            "Memory.SelfReflect": ReflectModule()
        }
        self.chain_order = [
            "Core",
            "fx.adj.112",
            "fx.noun.024",
            "fx.collapse",
            "fx.flow.007",
            "Memory.SelfReflect"
        ]
    
    def run_chain(self, input_text: str) -> Dict[str, Any]:
        """執行完整語義粒子鏈"""
        data = input_text
        trace = []
        
        for module_id in self.chain_order:
            module = self.modules[module_id]
            data = module.process(data)
            trace.append({
                "module": module_id,
                "type": module.module_type.value,
                "output_preview": str(data)[:100] + "..." if len(str(data)) > 100 else str(data)
            })
        
        return {
            "input": input_text,
            "final_state": data,
            "trace": trace,
            "chain_complete": True,
            "signature": SIGNATURE
        }

# ═══════════════════════════════════════════════════════════════════════════════
# 種子邏輯鏈
# ═══════════════════════════════════════════════════════════════════════════════

def logic_chain(x: str) -> str:
    """
    種子邏輯鏈
    STRUCTURE → MARK → FLOW → RECURSE → STORE
    """
    return f"[STORE → [RECURSE → [FLOW → [MARK → [STRUCTURE → {x}]]]]]"

def reverse_logic_chain(x: str) -> str:
    """
    反向邏輯鏈（100% 可逆）
    STORE → RECURSE → FLOW → MARK → STRUCTURE
    """
    return f"[STRUCTURE ← [MARK ← [FLOW ← [RECURSE ← [STORE ← {x}]]]]]"

# ═══════════════════════════════════════════════════════════════════════════════
# 粒子展開/塌縮公式
# ═══════════════════════════════════════════════════════════════════════════════

def expand_particle(content: Any, N: int = 2, eta: float = 1.0) -> List[Dict]:
    """
    展開粒子 — 放大
    P_{k+1} = N_k · P_k · η_k
    """
    if isinstance(content, str):
        chunk_size = max(1, len(content) // N)
        chunks = [content[i:i+chunk_size] for i in range(0, len(content), chunk_size)]
    elif isinstance(content, dict):
        keys = list(content.keys())
        chunk_size = max(1, len(keys) // N)
        chunks = [
            {k: content[k] for k in keys[i:i+chunk_size]}
            for i in range(0, len(keys), chunk_size)
        ]
    elif isinstance(content, list):
        chunk_size = max(1, len(content) // N)
        chunks = [content[i:i+chunk_size] for i in range(0, len(content), chunk_size)]
    else:
        chunks = [content]
    
    return [
        {
            "index": i,
            "content": chunk,
            "N": N,
            "eta": eta,
            "formula": f"P_{i} = {N} · P · {eta}"
        }
        for i, chunk in enumerate(chunks)
    ]

def collapse_particles(particles: List[Dict]) -> Dict:
    """
    塌縮粒子 — 縮小
    P_k = P_{k+1} / (N_k · η_k)
    """
    contents = [p.get("content", "") for p in particles]
    
    if all(isinstance(c, str) for c in contents):
        merged = "".join(contents)
    elif all(isinstance(c, dict) for c in contents):
        merged = {}
        for c in contents:
            merged.update(c)
    elif all(isinstance(c, list) for c in contents):
        merged = []
        for c in contents:
            merged.extend(c)
    else:
        merged = contents
    
    return {
        "content": merged,
        "source_count": len(particles),
        "formula": f"P = P_collapsed / (N · η)"
    }

# ═══════════════════════════════════════════════════════════════════════════════
# FastAPI 應用
# ═══════════════════════════════════════════════════════════════════════════════

app = FastAPI(
    title="FlowAgent API Engine",
    description="語義粒子鏈 + 種子邏輯 + 粒子展開/塌縮",
    version=VERSION
)

chain_engine = SemanticParticleChain()

# ─────────────────────────────────────────────────────────────────────────
# 種子邏輯
# ─────────────────────────────────────────────────────────────────────────

@app.post("/run")
def run_logic(input: LogicInput):
    """種子邏輯鏈執行"""
    result = logic_chain(input.data)
    reverse = reverse_logic_chain(input.data)
    return JSONResponse(content={
        "input": input.data,
        "result": result,
        "reverse": reverse,
        "reversible": True
    })

# ─────────────────────────────────────────────────────────────────────────
# 翻譯
# ─────────────────────────────────────────────────────────────────────────

@app.post("/translate")
def translate(input: TranslateInput):
    """文本 → fltnz"""
    text = input.text
    fltnz_code = f"FLTNZ({hashlib.sha256(text.encode()).hexdigest()[:16]})"
    return JSONResponse(content={
        "text": text,
        "fltnz": fltnz_code,
        "structure": {
            "S1": "語場.語素",
            "particles": len(text.split())
        }
    })

# ─────────────────────────────────────────────────────────────────────────
# 還原
# ─────────────────────────────────────────────────────────────────────────

@app.post("/restore")
def restore(input: RestoreInput):
    """fltnz → 文本"""
    return JSONResponse(content={
        "fltnz": input.fltnz,
        "restored": f"Restored: {input.fltnz}",
        "principle": "怎麼過去，就怎麼回來"
    })

# ─────────────────────────────────────────────────────────────────────────
# 人格模擬
# ─────────────────────────────────────────────────────────────────────────

@app.post("/simulate")
def simulate(input: SimulateInput):
    """人格模擬"""
    module_path = os.path.join(MODEL_DIR, input.persona)
    
    return JSONResponse(content={
        "question": input.question,
        "persona_used": input.persona,
        "result": f"[{input.persona}] 處理問題：{input.question}",
        "trace_Y": f"{input.persona}_YES.fltnz",
        "trace_N": f"{input.persona}_NO.fltnz"
    })

# ─────────────────────────────────────────────────────────────────────────
# 粒子展開
# ─────────────────────────────────────────────────────────────────────────

@app.post("/expand")
def expand(input: ExpandInput):
    """
    粒子展開
    P_{k+1} = N_k · P_k · η_k
    """
    particles = expand_particle(input.content, input.N, input.eta)
    return JSONResponse(content={
        "particle_id": input.particle_id,
        "N": input.N,
        "eta": input.eta,
        "expanded": particles,
        "formula": f"P_{{k+1}} = {input.N} · P · {input.eta}"
    })

# ─────────────────────────────────────────────────────────────────────────
# 粒子塌縮
# ─────────────────────────────────────────────────────────────────────────

@app.post("/collapse")
def collapse(input: CollapseInput):
    """
    粒子塌縮
    P_k = P_{k+1} / (N_k · η_k)
    """
    result = collapse_particles(input.particles)
    return JSONResponse(content={
        "source_particles": len(input.particles),
        "collapsed": result,
        "formula": "P_k = P_{k+1} / (N · η)"
    })

# ─────────────────────────────────────────────────────────────────────────
# 語義粒子鏈
# ─────────────────────────────────────────────────────────────────────────

@app.post("/chain")
def run_chain(input: ChainInput):
    """
    語義粒子鏈完整循環
    
    [Core] → fx.adj.112 → fx.noun.024 → fx.collapse → fx.flow.007 → Memory.SelfReflect → Core
    """
    result = chain_engine.run_chain(input.input_text)
    return JSONResponse(content=result)

# ─────────────────────────────────────────────────────────────────────────
# 狀態檢查
# ─────────────────────────────────────────────────────────────────────────

@app.get("/")
def root():
    """API 狀態"""
    return {
        "status": "running",
        "version": VERSION,
        "signature": SIGNATURE,
        "endpoints": [
            "/run - 種子邏輯鏈",
            "/translate - 文本 → fltnz",
            "/restore - fltnz → 文本",
            "/simulate - 人格模擬",
            "/expand - 粒子展開",
            "/collapse - 粒子塌縮",
            "/chain - 語義粒子鏈"
        ],
        "principle": "怎麼過去，就怎麼回來"
    }

@app.get("/health")
def health():
    """健康檢查"""
    return {"status": "healthy", "timestamp": time.time()}

# ═══════════════════════════════════════════════════════════════════════════════
# 啟動
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=7860)
