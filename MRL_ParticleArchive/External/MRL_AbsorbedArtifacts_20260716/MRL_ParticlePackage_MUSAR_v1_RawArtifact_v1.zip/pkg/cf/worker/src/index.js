/**
 * MRL Particle Gateway — Cloudflare Worker
 * origin_signature: MrLiouWord
 * 「怎麼過去，就怎麼回來」— LAW-0 貫穿所有回應
 *
 * GET  /health
 * GET  /manifest
 * GET  /particles?fx=fx04&layer=L2&kind=behavior&pkg=storage&q=retry&limit=50
 * GET  /particle/:pid
 * GET  /distilled                 蒸餾粒子（59 顆，可直接組裝）
 * GET  /distilled/retry           retry 政策表
 * GET  /distilled/failures        失敗類別
 * POST /compose                   組合粒子 → 回傳組裝後的 runtime 設定
 */

const ORIGIN = "MrLiouWord";

async function law0(payload) {
  const body = JSON.stringify(payload, Object.keys(payload).sort());
  const buf = await crypto.subtle.digest(
    "SHA-256", new TextEncoder().encode(ORIGIN + body));
  const hash = [...new Uint8Array(buf)]
    .map(b => b.toString(16).padStart(2, "0")).join("").slice(0, 16);
  return { ...payload, origin_signature: ORIGIN, law0_hash: hash,
           signed_at: Math.floor(Date.now() / 1000) };
}

const J = async (obj, status = 200) =>
  new Response(JSON.stringify(await law0(obj), null, 2), {
    status,
    headers: { "content-type": "application/json; charset=utf-8",
               "access-control-allow-origin": "*",
               "x-origin-signature": ORIGIN },
  });

export default {
  async fetch(req, env) {
    const url = new URL(req.url);
    const p = url.pathname.replace(/\/$/, "") || "/";

    try {
      if (p === "/health") {
        const r = await env.PARTICLES.prepare(
          "SELECT COUNT(*) n FROM particles").first();
        return J({ ok: true, particles: r?.n ?? 0, runtime: "MUSAR v1" });
      }

      if (p === "/manifest") {
        const c = await env.PARTICLE_CACHE.get("index:manifest");
        if (c) return new Response(c, {
          headers: { "content-type": "application/json",
                     "x-origin-signature": ORIGIN } });
        const rows = await env.PARTICLES.prepare(
          "SELECT layer, fx, kind, COUNT(*) n FROM particles GROUP BY layer, fx, kind"
        ).all();
        return J({ breakdown: rows.results });
      }

      if (p === "/particles") {
        const q = url.searchParams;
        const w = [], b = [];
        for (const k of ["fx", "layer", "kind", "pkg", "strategy"]) {
          if (q.get(k)) { w.push(`${k} = ?`); b.push(q.get(k)); }
        }
        if (q.get("q")) { w.push("name LIKE ?"); b.push(`%${q.get("q")}%`); }
        const lim = Math.min(parseInt(q.get("limit") || "50"), 500);
        const off = parseInt(q.get("offset") || "0");
        const sql = `SELECT pid,kind,layer,fx,name,source,pkg,provenance
                     FROM particles ${w.length ? "WHERE " + w.join(" AND ") : ""}
                     ORDER BY provenance DESC LIMIT ? OFFSET ?`;
        const r = await env.PARTICLES.prepare(sql).bind(...b, lim, off).all();
        return J({ count: r.results.length, offset: off, particles: r.results });
      }

      if (p.startsWith("/particle/")) {
        const pid = decodeURIComponent(p.slice(10));
        const r = await env.PARTICLES.prepare(
          "SELECT * FROM particles WHERE pid = ?").bind(pid).first();
        if (!r) return J({ error: "not_found", pid }, 404);
        r.payload = JSON.parse(r.payload || "{}");
        return J({ particle: r });
      }

      if (p === "/distilled") {
        const r = await env.PARTICLES.prepare(
          "SELECT pid,layer,fx,kind,name,uses,body FROM distilled ORDER BY uses DESC"
        ).all();
        return J({ count: r.results.length,
                   particles: r.results.map(x => ({ ...x, body: JSON.parse(x.body) })) });
      }

      if (p === "/distilled/retry") {
        const r = await env.PARTICLES.prepare(
          "SELECT pid,name,uses,body FROM distilled WHERE fx='fx04' ORDER BY uses DESC"
        ).all();
        return J({ policies: r.results.map(x => {
          const b = JSON.parse(x.body);
          return { pid: x.pid, ...b.policy, observed_uses: b.observed_uses,
                   packages: b.packages_sample };
        })});
      }

      if (p === "/distilled/failures") {
        const r = await env.PARTICLES.prepare(
          "SELECT pid,name,uses,body FROM distilled WHERE fx='fx17' ORDER BY uses DESC"
        ).all();
        return J({ failure_classes: r.results.map(x => {
          const b = JSON.parse(x.body);
          return { pid: x.pid, name: b.name, incidents: b.incident_count,
                   history: b.history?.slice(0, 5) };
        })});
      }

      // 組合粒子 → 產出 runtime 設定
      if (p === "/compose" && req.method === "POST") {
        const spec = await req.json();          // { retry: "MRL.FX04.Retry.00", ... }
        const out = {};
        for (const [slot, pid] of Object.entries(spec)) {
          const r = await env.PARTICLES.prepare(
            "SELECT body FROM distilled WHERE pid = ?").bind(pid).first();
          out[slot] = r ? JSON.parse(r.body) : { error: "not_found", pid };
        }
        return J({ composed: out, note: "LAW-0 signed composition" });
      }

      return J({
        runtime: "MRL Particle Gateway (MUSAR v1)",
        endpoints: ["/health", "/manifest", "/particles", "/particle/:pid",
                    "/distilled", "/distilled/retry", "/distilled/failures",
                    "POST /compose"],
      });
    } catch (e) {
      return J({ error: String(e) }, 500);
    }
  },
};
