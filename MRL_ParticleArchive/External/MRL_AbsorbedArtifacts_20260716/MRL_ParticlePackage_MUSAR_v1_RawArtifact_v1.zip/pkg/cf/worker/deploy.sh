#!/usr/bin/env bash
# MRL Particle Gateway 部署 | origin_signature: MrLiouWord
set -e
cd "$(dirname "$0")"

echo "[1/5] 建 D1"
wrangler d1 create mrl-particle-store || echo "  (已存在)"
echo "  → 把上面的 database_id 貼進 wrangler.toml，然後按 Enter"
read -r

echo "[2/5] 建 KV"
wrangler kv namespace create PARTICLE_CACHE || echo "  (已存在)"
echo "  → 把上面的 id 貼進 wrangler.toml，然後按 Enter"
read -r

echo "[3/5] 建表"
wrangler d1 execute mrl-particle-store --remote --file=../d1_schema.sql

echo "[4/5] 灌粒子 (11 批 + 蒸餾)"
wrangler d1 execute mrl-particle-store --remote --file=../seed_distilled.sql
for f in ../seed_particles_*.sql; do
  echo "  → $f"
  wrangler d1 execute mrl-particle-store --remote --file="$f"
done

echo "[5/5] 部署 Worker"
wrangler deploy
echo "完成 → https://mrl-particle-gateway.<你的帳號>.workers.dev/health"
