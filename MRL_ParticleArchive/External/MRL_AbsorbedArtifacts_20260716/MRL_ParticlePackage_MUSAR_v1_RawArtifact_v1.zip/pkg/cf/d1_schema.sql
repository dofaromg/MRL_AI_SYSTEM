-- MRL Particle Store — Cloudflare D1
-- origin_signature: MrLiouWord
CREATE TABLE IF NOT EXISTS particles (
  pid         TEXT PRIMARY KEY,
  fingerprint TEXT NOT NULL,
  kind        TEXT NOT NULL,
  layer       TEXT NOT NULL,
  fx          TEXT NOT NULL,
  name        TEXT NOT NULL,
  source      TEXT NOT NULL,
  pkg         TEXT NOT NULL,
  aspect      TEXT,
  strategy    TEXT,
  payload     TEXT,
  provenance  INTEGER DEFAULT 1,
  origin_signature TEXT NOT NULL DEFAULT 'MrLiouWord',
  law0_hash   TEXT NOT NULL,
  signed_at   INTEGER
);
CREATE INDEX IF NOT EXISTS idx_fx    ON particles(fx);
CREATE INDEX IF NOT EXISTS idx_layer ON particles(layer);
CREATE INDEX IF NOT EXISTS idx_kind  ON particles(kind);
CREATE INDEX IF NOT EXISTS idx_pkg   ON particles(pkg);
CREATE INDEX IF NOT EXISTS idx_name  ON particles(name);
CREATE INDEX IF NOT EXISTS idx_fp    ON particles(fingerprint);

CREATE TABLE IF NOT EXISTS distilled (
  pid       TEXT PRIMARY KEY,
  layer     TEXT, fx TEXT, kind TEXT, name TEXT,
  body      TEXT,
  uses      INTEGER,
  law0_hash TEXT,
  origin_signature TEXT DEFAULT 'MrLiouWord'
);
