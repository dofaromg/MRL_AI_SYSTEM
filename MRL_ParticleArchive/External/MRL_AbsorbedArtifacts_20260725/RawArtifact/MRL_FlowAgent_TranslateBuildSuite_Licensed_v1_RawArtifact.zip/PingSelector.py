
import json
import argparse
from pathlib import Path

def select_persona(ping_text, fxmap_path, model_dir):
    keywords = ping_text.lower().split()
    fxmap = json.loads(Path(fxmap_path).read_text(encoding="utf-8"))
    candidates = []

    for fname in Path(model_dir).glob("*.flpkg.json"):
        data = json.loads(fname.read_text(encoding="utf-8"))
        matched = any(fx in data.get("fx_path", []) for fx in fxmap.values())
        if matched:
            candidates.append(fname.name)

    print(f"[✔] Ping: '{ping_text}'")
    print("Matched personas:", candidates or "None")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--ping", required=True, help="Input question")
    parser.add_argument("--fxmap", required=True, help="Path to fxmap.json")
    parser.add_argument("--models", required=True, help="Directory with .flpkg.json files")
    args = parser.parse_args()

    select_persona(args.ping, args.fxmap, args.models)
