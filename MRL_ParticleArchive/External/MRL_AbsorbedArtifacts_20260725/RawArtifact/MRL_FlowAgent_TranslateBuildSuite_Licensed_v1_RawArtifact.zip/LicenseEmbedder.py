
import argparse
import json
from pathlib import Path
from datetime import datetime

def embed_license(file_path):
    path = Path(file_path)
    if path.suffix not in [".json", ".fltnz", ".fltrace"]:
        print(f"[!] Unsupported file type: {path.name}")
        return

    now = datetime.utcnow().isoformat()
    try:
        content = json.loads(path.read_text(encoding="utf-8"))
        content["creator"] = "Mr.liou"
        content["license"] = "All rights reserved. No redistribution without explicit permission."
        content["origin"] = "FlowAgent Particulate Language System"
        content["version"] = "v1.0"
        content["timestamp"] = now
        path.write_text(json.dumps(content, indent=2, ensure_ascii=False), encoding="utf-8")
        print(f"[✔] License info embedded into: {path.name}")
    except Exception as e:
        print(f"[✘] Failed to embed: {e}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--file", required=True, help="Target file (.json/.fltnz/.fltrace)")
    args = parser.parse_args()
    embed_license(args.file)
