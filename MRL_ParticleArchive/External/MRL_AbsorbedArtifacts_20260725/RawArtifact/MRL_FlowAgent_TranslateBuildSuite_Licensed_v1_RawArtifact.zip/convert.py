
import argparse
import json
import csv
import os
from pathlib import Path

def txt_to_fltnz(text):
    tokens = text.strip().split()
    return " ".join(f"{tok}⧉/fx.{i}/" for i, tok in enumerate(tokens))

def json_to_fxmap(json_obj):
    return {f"fx.{k}": f"jump-{i}" for i, k in enumerate(json_obj.keys())}

def md_to_fltrace(md_text):
    return {"fltrace": [line.strip() for line in md_text.splitlines() if line.strip()]}

def csv_to_syncmap(csv_text):
    lines = csv_text.strip().splitlines()
    reader = csv.reader(lines)
    headers = next(reader)
    return {
        "sync": [
            {headers[i]: cell for i, cell in enumerate(row)}
            for row in reader
        ]
    }

def route_conversion(input_path, target_format):
    suffix = input_path.suffix.lower()
    content = input_path.read_text(encoding="utf-8")

    if suffix == ".txt" and target_format == "fltnz":
        return txt_to_fltnz(content)
    elif suffix == ".json" and target_format == "fxmap":
        return json_to_fxmap(json.loads(content))
    elif suffix == ".md" and target_format == "fltrace":
        return md_to_fltrace(content)
    elif suffix == ".csv" and target_format == "sync.json":
        return csv_to_syncmap(content)
    else:
        raise ValueError("Unsupported conversion pair.")

def main():
    parser = argparse.ArgumentParser(description="FlowAgent ConvertStation v2")
    parser.add_argument("--input", required=True, help="Input file path")
    parser.add_argument("--to", required=True, help="Target format (e.g. fltnz, fxmap, sync.json)")

    args = parser.parse_args()
    input_path = Path(args.input)
    output_path = input_path.with_suffix("." + args.to.replace(".json", ""))

    result = route_conversion(input_path, args.to)

    with open(output_path, "w", encoding="utf-8") as out:
        if isinstance(result, str):
            out.write(result)
        else:
            json.dump(result, out, indent=2, ensure_ascii=False)

    print(f"[✔] Converted to {output_path.name}")

if __name__ == "__main__":
    main()
