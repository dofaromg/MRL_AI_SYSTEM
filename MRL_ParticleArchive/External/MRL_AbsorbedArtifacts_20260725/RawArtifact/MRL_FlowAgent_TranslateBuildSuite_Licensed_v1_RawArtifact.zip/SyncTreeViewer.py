
import json
import argparse
from pathlib import Path

def sync_to_tree(sync_path):
    data = json.loads(Path(sync_path).read_text(encoding="utf-8"))
    output = ["graph TD"]
    for pair in data.get("sync", []):
        source = pair.get("from", "v0")
        target = pair.get("to", "v1")
        rel = pair.get("type", "Δshift")
        output.append(f'  "{source}" -->|{rel}| "{target}"')

    output_path = Path(sync_path).with_suffix(".mermaid")
    Path(output_path).write_text("\n".join(output), encoding="utf-8")
    print(f"[✔] Generated SyncTree → {output_path.name}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True, help="Path to sync.json")
    args = parser.parse_args()
    sync_to_tree(args.input)
