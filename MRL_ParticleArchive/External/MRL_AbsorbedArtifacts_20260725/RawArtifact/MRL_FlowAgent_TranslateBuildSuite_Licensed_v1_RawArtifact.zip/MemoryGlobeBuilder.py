
import json
import argparse
from pathlib import Path
import random

def fltrace_to_node3d(fltrace_path):
    trace = json.loads(Path(fltrace_path).read_text(encoding="utf-8"))
    points = []
    for i, label in enumerate(trace.get("fltrace", [])):
        points.append({
            "id": f"node{i}",
            "label": label,
            "x": round(random.uniform(-1, 1), 2),
            "y": round(random.uniform(-1, 1), 2),
            "z": round(random.uniform(-1, 1), 2)
        })

    out_path = Path(fltrace_path).with_suffix(".node3d.json")
    json.dump({"nodes": points}, open(out_path, "w", encoding="utf-8"), indent=2)
    print(f"[✔] 3D node map → {out_path.name}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True, help="Path to .fltrace")
    args = parser.parse_args()
    fltrace_to_node3d(args.input)
