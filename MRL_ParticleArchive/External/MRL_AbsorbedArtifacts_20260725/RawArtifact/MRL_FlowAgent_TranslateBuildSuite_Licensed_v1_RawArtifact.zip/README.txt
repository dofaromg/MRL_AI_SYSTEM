
# FlowAgent ConvertStation v2

支援格式：
- .txt → .fltnz
- .json → .fxmap
- .md → .fltrace
- .csv → .sync.json

## 使用方式：

python convert.py --input ./demo.txt --to fltnz
python convert.py --input ./config.json --to fxmap
python convert.py --input ./record.md --to fltrace
python convert.py --input ./table.csv --to sync.json
