
from flask import Flask, request, jsonify
import os

app = Flask(__name__)

MODEL_DIR = "models"

def load_persona_module(name):
    return f"模擬使用模組：{name}"

@app.route('/translate', methods=['POST'])
def translate():
    data = request.json
    text = data.get("text", "")
    return jsonify({
        "fltnz": f"FLTNZ({text})",
        "structure": {"S1": "語場.語素"}
    })

@app.route('/restore', methods=['POST'])
def restore():
    data = request.json
    fltnz = data.get("fltnz", "")
    return jsonify({
        "restored": f"Restored: {fltnz}"
    })

@app.route('/simulate', methods=['POST'])
def simulate():
    data = request.json
    question = data.get("question", "")
    persona = data.get("persona", "MrLiou.flpkg")

    module_path = os.path.join(MODEL_DIR, persona)
    if not os.path.exists(module_path):
        return jsonify({"error": "Persona module not found"}), 404

    module_logic = load_persona_module(persona)
    return jsonify({
        "question": question,
        "persona_used": persona,
        "result": f"{module_logic} → 問題：{question}",
        "trace_Y": f"{persona}_YES.fltnz",
        "trace_N": f"{persona}_NO.fltnz"
    })

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=7860)
