
import hashlib
import argparse
from pathlib import Path

def generate_fingerprint(file_path):
    path = Path(file_path)
    content = path.read_bytes()
    sha = hashlib.sha256(content).hexdigest()
    sig_path = path.with_suffix(".license.sig")
    sig_path.write_text(sha, encoding="utf-8")
    print(f"[✔] Fingerprint (SHA256) saved → {sig_path.name}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--file", required=True, help="File to hash and sign")
    args = parser.parse_args()
    generate_fingerprint(args.file)
