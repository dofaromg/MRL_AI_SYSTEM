
import json
import argparse
from pathlib import Path

def compile_fltnz_to_flpkg(fltnz_path):
    text = Path(fltnz_path).read_text(encoding="utf-8")
    tokens = text.strip().split()
    persona = {
        "name": Path(fltnz_path).stem,
        "source": fltnz_path,
        "tokens": [],
        "fx_path": [],
        "metadata": {
            "compiled_by": "FLTNZtoFLPKG.Compiler.v1"
        }
    }

    for i, token in enumerate(tokens):
        if "⧉/fx." in token:
            word, fx = token.split("⧉")
            fx_label = fx.strip("/")
            persona["tokens"].append({"word": word, "fx": fx_label})
            persona["fx_path"].append(fx_label)

    output_path = Path(fltnz_path).with_suffix(".flpkg.json")
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(persona, f, indent=2, ensure_ascii=False)
    print(f"[✔] Compiled to {output_path.name}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True, help="Path to .fltnz file")
    args = parser.parse_args()
    compile_fltnz_to_flpkg(args.input)
