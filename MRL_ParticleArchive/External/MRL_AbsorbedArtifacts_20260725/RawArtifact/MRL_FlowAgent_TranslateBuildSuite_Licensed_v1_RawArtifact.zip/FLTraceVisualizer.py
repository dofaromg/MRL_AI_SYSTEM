
import json
import argparse
from pathlib import Path

def fltrace_to_mermaid(fltrace_path):
    trace = json.loads(Path(fltrace_path).read_text(encoding="utf-8"))
    nodes = trace.get("fltrace", [])
    output = ["graph TD"]

    for i in range(len(nodes) - 1):
        output.append(f'  step{i}["{nodes[i]}"] --> step{i+1}["{nodes[i+1]}"]')

    output_path = Path(fltrace_path).with_suffix(".mermaid")
    Path(output_path).write_text("\n".join(output), encoding="utf-8")
    print(f"[✔] Visualized to {output_path.name}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True, help="Path to .fltrace file")
    args = parser.parse_args()
    fltrace_to_mermaid(args.input)
