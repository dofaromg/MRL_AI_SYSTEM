import os, subprocess, shlex
from typing import Dict, Any

def _run(cmd: str) -> Dict[str, Any]:
    argv = shlex.split(cmd)
    p = subprocess.run(argv, capture_output=True, text=True)
    return {"cmd": cmd, "returncode": p.returncode, "stdout": (p.stdout or "")[-4000:], "stderr": (p.stderr or "")[-4000:]}

def run(data_root: str, cmd: str) -> Dict[str, Any]:
    # cmd is a full command line string
    out = _run(cmd)
    if out["returncode"] != 0:
        raise RuntimeError(f"mother_cmd_failed rc={out['returncode']}")
    return out
