import os
from typing import Dict, Any

def run(data_root: str) -> Dict[str, Any]:
    try:
        from flowagent.core.snapshot import create_snapshot
        meta = create_snapshot(data_root)
        return {"snapshot": meta}
    except Exception:
        os.makedirs(os.path.join(data_root, "snapshots"), exist_ok=True)
        return {"snapshot": "created_dir_only"}
