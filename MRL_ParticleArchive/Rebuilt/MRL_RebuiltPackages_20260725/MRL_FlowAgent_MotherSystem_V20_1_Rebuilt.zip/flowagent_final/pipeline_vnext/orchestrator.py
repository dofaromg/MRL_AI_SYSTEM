import json, os, subprocess, shlex
from typing import Dict, Any, Callable

from .gate.gate import Gate

def load_graph(path: str) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def _run_command(cmd: str, cwd: str | None = None) -> Dict[str, Any]:
    # run shell-like command (no shell injection; split)
    argv = shlex.split(cmd)
    p = subprocess.run(argv, cwd=cwd, capture_output=True, text=True)
    return {
        "cmd": cmd,
        "returncode": p.returncode,
        "stdout": (p.stdout or "")[-4000:],
        "stderr": (p.stderr or "")[-4000:],
    }

def run_graph(data_root: str, graph_path: str, persona_id: str = "ANALYST_BG") -> Dict[str, Any]:
    g = load_graph(graph_path)
    gate = Gate(data_root=data_root, persona_id=persona_id)
    results: Dict[str, Any] = {"graph_id": g.get("graph_id"), "rid": gate.rid, "runs": []}

    policy = g.get("policy") or {}
    on_fail = policy.get("on_fail", "redirect")  # redirect|continue|abort
    runner_map = policy.get("runner_map") or {}
    default_redirect = policy.get("default_redirect_runner", "repair")

    for node in g.get("nodes", []):
        node_id = node.get("id") or ""
        kind = node.get("kind") or node.get("runner")  # backward compatible

        redirect_to = runner_map.get(node_id) or default_redirect

        if kind in ("stage", "python_stage"):
            action = node.get("action", "noop")
            stage_impl = node.get("impl", "")
            if stage_impl:
                # dynamic import stage module that has run(data_root, **kwargs)
                mod_name = stage_impl.replace("/", ".").replace(".py","")
                kwargs = node.get("kwargs") or {}
                def fn():
                    mod = __import__(mod_name, fromlist=["run"])
                    return mod.run(data_root, **kwargs)
            else:
                from .stages.stage_noop import run as stage_fn
                def fn():
                    return stage_fn(data_root)
            r = gate.run_stage(node_id, action, fn, redirect_runner=redirect_to)

        elif kind in ("cmd", "command"):
            cmd = node.get("cmd", "")
            action = node.get("action", "cmd")
            cwd = node.get("cwd") or None
            def fn():
                out = _run_command(cmd, cwd=cwd)
                if out["returncode"] != 0:
                    raise RuntimeError(f"command_failed rc={out['returncode']}")
                return out
            r = gate.run_stage(node_id, action, fn, redirect_runner=redirect_to)

        elif kind in ("runner",):
            name = node.get("name") or ""
            kwargs = node.get("kwargs") or {}
            if name == "audit":
                from .runners.audit import run as rfn
                fn = lambda: rfn(data_root)
            elif name == "rebuild":
                from .runners.rebuild import run as rfn
                fn = lambda: rfn(data_root)
            elif name == "deploy":
                from .runners.deploy import run as rfn
                fn = lambda: rfn(data_root, **kwargs)
            elif name == "evolve":
                from .runners.evolve import run as rfn
                fn = lambda: rfn(data_root, **kwargs)
            elif name == "apply_patch":
                from .runners.apply_patch import run as rfn
                fn = lambda: rfn(data_root, **kwargs)
            elif name == "apply_txn":
                from .runners.apply_txn import run as rfn
                fn = lambda: rfn(data_root, **kwargs)
            elif name == "repair":
                from .runners.repair import run as rfn
                fn = lambda: rfn(data_root, **kwargs)
            else:
                from .runners.repair import run as rfn
                fn = lambda: rfn(data_root, reason=f"unknown_runner:{name}")
            r = gate.run_stage(node_id, f"runner:{name}", fn, redirect_runner=redirect_to)

        else:
            from .stages.stage_noop import run as stage_fn
            r = gate.run_stage(node_id, "noop", lambda: stage_fn(data_root), redirect_runner=redirect_to)

        results["runs"].append({
            "node": node_id,
            "kind": kind,
            "ok": r.ok,
            "event_id": r.event_id,
            "proof_id": r.proof_id,
            "redirected_to": r.redirected_to,
            "reason": r.reason
        })

        if (not r.ok):
            if on_fail == "continue":
                continue
            if on_fail == "abort":
                results["aborted"] = True
                break
            # redirect (default)
            if r.redirected_to:
                results["redirected"] = True
                results["redirect_runner"] = r.redirected_to
                break


    # persist run receipt for telemetry/evolution
    try:
        import os, json
        os.makedirs(os.path.join(data_root, "runs"), exist_ok=True)
        rp = os.path.join(data_root, "runs", f"{results.get('rid','unknown')}.json")
        with open(rp, "w", encoding="utf-8") as f:
            json.dump(results, f, ensure_ascii=False, indent=2)
        results["run_receipt"] = rp
    except Exception:
        pass

    return results
