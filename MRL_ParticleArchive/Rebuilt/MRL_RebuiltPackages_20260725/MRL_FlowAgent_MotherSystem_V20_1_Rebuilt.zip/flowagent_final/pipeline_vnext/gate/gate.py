from dataclasses import dataclass
from typing import Callable, Dict, Any, Optional
import os, json

from .util import new_event_id, new_rid, utc_now_iso, sha256_text
from .trace import write_trace, make_trace
from .proof import write_proof

try:
    from flowagent.core.law_exec import LawEngine
except Exception:
    LawEngine = None

@dataclass
class GateResult:
    ok: bool
    event_id: str
    proof_id: str
    redirected_to: str = ""
    reason: str = ""
    outputs: Optional[Dict[str, Any]] = None

class Gate:
    def __init__(self, data_root: str, persona_id: str = "ANALYST_BG"):
        self.data_root = data_root
        self.persona_id = persona_id
        self.rid = new_rid()
        self.tick = 0
        self.law = LawEngine() if LawEngine else None
        os.makedirs(os.path.join(self.data_root, "proof"), exist_ok=True)
        os.makedirs(os.path.join(self.data_root, "trace"), exist_ok=True)

    def _state_hash(self) -> str:
        idx = os.path.join(self.data_root, "index", "conversations.json")
        if os.path.exists(idx):
            b = open(idx, "rb").read()
            return sha256_text(b.decode("utf-8", errors="ignore"))
        return sha256_text("no_index")

    def run_stage(self, stage_id: str, action: str, fn: Callable[[], Dict[str, Any]],
                  source: str = "internal", target_layer: str = "memory",
                  redirect_runner: Optional[str] = None) -> GateResult:
        self.tick += 1
        event_id = new_event_id()
        before = self._state_hash()

        if self.law:
            dec = self.law.arbitrate({
                "source": source,
                "target_layer": target_layer,
                "action": action,
                "trace_id": event_id
            })
            if not dec.allow:
                tr = make_trace(self.data_root, event_id, self.rid, self.tick, self.persona_id,
                                {"stage": stage_id, "action": action, "denied": True, "reason": dec.reason})
                write_trace(self.data_root, tr)
                pid = write_proof(self.data_root, {
                    "subject": {"layer": "GATE", "object_id": stage_id, "event": "law_deny"},
                    "before_hash": before,
                    "after_hash": before,
                    "law_applied": [dec.reason],
                    "coherence_score": 0.0,
                    "entropy_delta": 0.0,
                    "signature": {"author": "MrLiou", "x_signature": "local", "timestamp": utc_now_iso()}
                })
                return GateResult(False, event_id, pid, redirected_to=redirect_runner or "", reason=dec.reason)

        try:
            out = fn()
            ok = True
            reason = "ok"
        except Exception as e:
            out = {"error": str(e)}
            ok = False
            reason = f"exception:{e}"

        after = self._state_hash()

        tr = make_trace(self.data_root, event_id, self.rid, self.tick, self.persona_id,
                        {"stage": stage_id, "action": action, "ok": ok, "reason": reason})
        write_trace(self.data_root, tr)

        pid = write_proof(self.data_root, {
            "subject": {"layer": "PIPELINE_VNEXT", "object_id": stage_id, "event": action},
            "before_hash": before,
            "after_hash": after,
            "law_applied": ["ok"],
            "coherence_score": 0.95 if ok else 0.4,
            "entropy_delta": 0.0,
            "signature": {"author": "MrLiou", "x_signature": "local", "timestamp": utc_now_iso()}
        })

        if (not ok) and redirect_runner:
            return GateResult(False, event_id, pid, redirected_to=redirect_runner, reason=reason, outputs=out)

        return GateResult(ok, event_id, pid, reason=reason, outputs=out)
