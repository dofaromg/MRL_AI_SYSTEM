import os, json
from typing import Dict, Any
from .util import append_jsonl, sha256_text, utc_now_iso

def write_proof(data_root: str, record: Dict[str, Any]) -> str:
    path = os.path.join(data_root, "proof", "chain.jsonl")
    proof_id = record.get("proof_id") or sha256_text(json.dumps(record, ensure_ascii=False) + utc_now_iso())[:32]
    record["proof_id"] = proof_id
    record.setdefault("timestamp", utc_now_iso())
    append_jsonl(path, record)
    return proof_id
