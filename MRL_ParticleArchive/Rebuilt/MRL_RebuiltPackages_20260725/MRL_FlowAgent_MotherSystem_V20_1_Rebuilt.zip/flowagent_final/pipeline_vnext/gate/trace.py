import os
from typing import Dict, Any
from .util import append_jsonl, utc_now_iso
from .merkle import merkle_root_dir

def write_trace(data_root: str, record: Dict[str, Any]) -> str:
    path = os.path.join(data_root, "trace", "trace.jsonl")
    record.setdefault("timestamp", utc_now_iso())
    append_jsonl(path, record)
    return path

def make_trace(data_root: str, event_id: str, rid: str, tick: int, persona_id: str, subject: Dict[str, Any]) -> Dict[str, Any]:
    mr = merkle_root_dir(os.path.join(data_root, "memory"))
    return {
        "event_id": event_id,
        "rid": rid,
        "tick": tick,
        "persona_id": persona_id,
        "merkle_root": mr,
        "subject": subject,
        "timestamp": utc_now_iso()
    }
