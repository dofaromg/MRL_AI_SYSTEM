import os
from .util import sha256_text

def merkle_root_dir(root: str) -> str:
    items = []
    if not os.path.exists(root):
        return sha256_text("missing:" + root)
    for dp, _, fns in os.walk(root):
        for fn in sorted(fns):
            p = os.path.join(dp, fn)
            rel = os.path.relpath(p, root)
            try:
                b = open(p, "rb").read()
            except OSError:
                b = b""
            # content hash per file; stable and cheap
            items.append(rel + ":" + sha256_text(b.decode("utf-8", errors="ignore")))
    return sha256_text("\n".join(items))
