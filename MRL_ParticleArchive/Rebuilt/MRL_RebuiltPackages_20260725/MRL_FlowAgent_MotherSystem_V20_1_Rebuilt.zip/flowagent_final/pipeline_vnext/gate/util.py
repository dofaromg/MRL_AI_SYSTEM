import os, json, hashlib, uuid
from datetime import datetime, timezone

def utc_now_iso():
    return datetime.now(timezone.utc).isoformat()

def sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()

def sha256_text(s: str) -> str:
    return sha256_bytes(s.encode("utf-8"))

def ensure_dir(p: str):
    os.makedirs(p, exist_ok=True)

def atomic_write(path: str, data: str):
    ensure_dir(os.path.dirname(path))
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(data)
    os.replace(tmp, path)

def append_jsonl(path: str, obj: dict):
    ensure_dir(os.path.dirname(path))
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(obj, ensure_ascii=False) + "\n")

def new_event_id() -> str:
    return str(uuid.uuid4())

def new_rid() -> str:
    return sha256_text(new_event_id() + utc_now_iso())[:16]
