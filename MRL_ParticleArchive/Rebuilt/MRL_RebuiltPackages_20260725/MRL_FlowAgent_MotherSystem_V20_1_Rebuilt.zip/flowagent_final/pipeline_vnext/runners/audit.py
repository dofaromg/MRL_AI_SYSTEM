import os, json
from typing import Dict, Any

def run(data_root: str) -> Dict[str, Any]:
    proof = os.path.join(data_root, "proof", "chain.jsonl")
    trace = os.path.join(data_root, "trace", "trace.jsonl")
    out = {
        "proof_exists": os.path.exists(proof),
        "trace_exists": os.path.exists(trace),
        "proof_lines": 0,
        "trace_lines": 0
    }
    if os.path.exists(proof):
        out["proof_lines"] = sum(1 for _ in open(proof, "r", encoding="utf-8"))
    if os.path.exists(trace):
        out["trace_lines"] = sum(1 for _ in open(trace, "r", encoding="utf-8"))
    os.makedirs(os.path.join(data_root, "audit"), exist_ok=True)
    with open(os.path.join(data_root, "audit", "latest.json"), "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)
    return out
