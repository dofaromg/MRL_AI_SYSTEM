from typing import Dict, Any

def run(data_root: str) -> Dict[str, Any]:
    try:
        from flowagent.memory.index import index_state_hash
        h = index_state_hash(data_root)
        return {"index_state_hash": h}
    except Exception:
        return {"rebuild": "noop"}
