from typing import Dict, Any
import subprocess, shlex

def run(data_root: str, candidate: str, dry_run: bool = True) -> Dict[str, Any]:
    cmd = f"python evolution/apply_candidate.py --data-root {data_root} --candidate {candidate}"
    if dry_run:
        cmd += " --dry-run"
    p = subprocess.run(shlex.split(cmd), capture_output=True, text=True)
    out = {"cmd": cmd, "returncode": p.returncode, "stdout": (p.stdout or "")[-4000:], "stderr": (p.stderr or "")[-4000:]}
    if p.returncode != 0:
        raise RuntimeError("apply_patch_failed")
    return out
