import os, json
from typing import Dict, Any
from datetime import datetime, timezone

def run(data_root: str, reason: str = "unspecified") -> Dict[str, Any]:
    os.makedirs(os.path.join(data_root, "repair"), exist_ok=True)
    ticket = {
        "reason": reason,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "action": "manual_review_required"
    }
    with open(os.path.join(data_root, "repair", "ticket_latest.json"), "w", encoding="utf-8") as f:
        json.dump(ticket, f, ensure_ascii=False, indent=2)
    return ticket
