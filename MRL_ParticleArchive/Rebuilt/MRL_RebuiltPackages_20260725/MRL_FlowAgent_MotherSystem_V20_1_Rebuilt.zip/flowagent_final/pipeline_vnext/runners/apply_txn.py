from typing import Dict, Any
import subprocess, shlex, json

def run(data_root: str, candidate: str, commit: bool = False, verify_cmd: list | None = None) -> Dict[str, Any]:
    cmd = f"python evolution/transaction.py --data-root {data_root} --candidate {candidate}"
    if commit:
        cmd += " --commit"
    # verify_cmd support (optional); kept minimal in v3
    p = subprocess.run(shlex.split(cmd), capture_output=True, text=True)
    out = {"cmd": cmd, "returncode": p.returncode, "stdout": (p.stdout or "")[-4000:], "stderr": (p.stderr or "")[-4000:]}
    if p.returncode != 0:
        raise RuntimeError("apply_txn_failed")
    try:
        jr = json.loads((p.stdout or "").strip().splitlines()[-1])
    except Exception:
        jr = None
    if jr and isinstance(jr, dict):
        try:
            from pipeline_vnext.gate.proof import write_proof
            from pipeline_vnext.gate.util import utc_now_iso
            write_proof(data_root, {
                "subject": {"layer": "EVOLUTION", "object_id": jr.get("txn_id",""), "event": f"txn_{jr.get('final','')}" },
                "before_hash": "n/a",
                "after_hash": "n/a",
                "law_applied": ["evolution_transaction"],
                "coherence_score": 0.9 if jr.get("final")=="committed" else 0.6,
                "entropy_delta": 0.0,
                "signature": {"author": "MrLiou", "x_signature": "local", "timestamp": utc_now_iso()}
            })
        except Exception:
            pass
    return out
