import os, json, hashlib
from datetime import datetime, timezone
from typing import Dict, Any

def utc():
    return datetime.now(timezone.utc).isoformat()

def _sha(s: str) -> str:
    return hashlib.sha256(s.encode("utf-8")).hexdigest()

def run(data_root: str, budget: int = 5) -> Dict[str, Any]:
    eval_path=os.path.join(data_root,"evaluation","latest.json")
    agg_path=os.path.join(data_root,"telemetry","aggregates.json")
    os.makedirs(os.path.join(data_root,"evolution","candidates"), exist_ok=True)
    evaluation=json.loads(open(eval_path,"r",encoding="utf-8").read()) if os.path.exists(eval_path) else {}
    aggregates=json.loads(open(agg_path,"r",encoding="utf-8").read()) if os.path.exists(agg_path) else {}

    candidate={"kind":"candidate_patch","budget":budget,"timestamp":utc(),"inputs":{"evaluation":evaluation,"aggregates":aggregates},"suggestions":[]}

    if evaluation.get("pass") is False:
        candidate["suggestions"].append({"target":"pipeline_vnext/graphs/pipeline_query_check.json","patch":{"policy":{"on_fail":"abort"}}})
        candidate["suggestions"].append({"target":"pipeline_vnext/graphs/pipeline_default.json","patch":{"policy":{"on_fail":"redirect","default_redirect_runner":"repair"}}})
    else:
        candidate["suggestions"].append({"target":"pipeline_vnext/graphs/pipeline_default.json","patch":{"policy":{"on_fail":"redirect"}}})

    cid=_sha(json.dumps(candidate,ensure_ascii=False)+utc())[:16]
    out_path=os.path.join(data_root,"evolution","candidates",f"{cid}.json")
    with open(out_path,"w",encoding="utf-8") as f:
        json.dump(candidate,f,ensure_ascii=False,indent=2)
    return {"candidate_id":cid,"path":out_path,"suggestions":candidate["suggestions"]}
