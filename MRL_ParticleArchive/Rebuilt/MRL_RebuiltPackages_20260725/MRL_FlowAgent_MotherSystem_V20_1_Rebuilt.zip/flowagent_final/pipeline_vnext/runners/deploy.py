from typing import Dict, Any
import os

def run(data_root: str, mode: str = "k8s") -> Dict[str, Any]:
    os.makedirs(os.path.join(data_root, "deploy_intent"), exist_ok=True)
    path = os.path.join(data_root, "deploy_intent", "latest.txt")
    with open(path, "w", encoding="utf-8") as f:
        f.write(f"mode={mode}\n")
    return {"deploy_intent": path, "mode": mode}
