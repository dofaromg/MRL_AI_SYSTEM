#!/usr/bin/env python3
import argparse, json, os

from pipeline_vnext.orchestrator import run_graph

def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)

    p_run = sub.add_parser("run")
    p_run.add_argument("--data-root", default="data")
    p_run.add_argument("--graph", required=True)
    p_run.add_argument("--persona-id", default="ANALYST_BG")

    p_runner = sub.add_parser("runner")
    p_runner.add_argument("name", choices=["audit","repair","rebuild","deploy"])
    p_runner.add_argument("--data-root", default="data")
    p_runner.add_argument("--reason", default="unspecified")
    p_runner.add_argument("--mode", default="k8s")

    args = ap.parse_args()

    if args.cmd == "run":
        res = run_graph(args.data_root, args.graph, persona_id=args.persona_id)
        print(json.dumps(res, ensure_ascii=False, indent=2))
        return

    # Direct runner = build temp graph to keep Gate path consistent
    os.makedirs("pipeline_vnext/graphs/_tmp", exist_ok=True)
    tmp_path = "pipeline_vnext/graphs/_tmp/direct.json"
    graph = {
        "graph_id": f"direct_{args.name}",
        "nodes": [{"id": f"runner_{args.name}", "kind": "runner", "name": args.name, "kwargs": {}}],
        "policy": {"on_fail": "abort", "default_redirect_runner": "repair"}
    }
    if args.name == "repair":
        graph["nodes"][0]["kwargs"] = {"reason": args.reason}
    if args.name == "deploy":
        graph["nodes"][0]["kwargs"] = {"mode": args.mode}

    with open(tmp_path, "w", encoding="utf-8") as f:
        json.dump(graph, f, ensure_ascii=False, indent=2)

    res = run_graph(args.data_root, tmp_path, persona_id="ANALYST_BG")
    print(json.dumps(res, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()
