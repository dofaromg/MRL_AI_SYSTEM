#!/bin/bash
# ═══════════════════════════════════════════════════════════════════════════════
#   FlowAgent Mother System - 一鍵部署腳本
#   
#   @origin_signature("MrLiouWord")
#   @version: v1.0.0-final
#   @created: 2024-12
# ═══════════════════════════════════════════════════════════════════════════════

set -e

echo "═══════════════════════════════════════════════════════════════════════════════"
echo "  🌱 FlowAgent Mother System 部署程序"
echo "  版本: v1.0.0-final"
echo "  原創者: MrLiou"
echo "═══════════════════════════════════════════════════════════════════════════════"
echo ""

# 顏色定義
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# 檢查函數
check_command() {
    if command -v $1 &> /dev/null; then
        echo -e "${GREEN}✓${NC} $1 已安裝"
        return 0
    else
        echo -e "${RED}✗${NC} $1 未安裝"
        return 1
    fi
}

# 步驟 0: 環境檢查
echo "【步驟 0】環境檢查..."
echo "---"

READY=true

check_command docker || READY=false
check_command kubectl || { echo -e "${YELLOW}!${NC} kubectl 未安裝，將使用 Docker Compose 模式"; }
check_command python3 || READY=false

echo ""

if [ "$READY" = false ]; then
    echo -e "${RED}環境檢查失敗，請先安裝必要工具${NC}"
    exit 1
fi

# 步驟 1: 選擇部署模式
echo "【步驟 1】選擇部署模式..."
echo "---"
echo "1) Docker Compose (單機)"
echo "2) Kubernetes (K8s/K3s)"
echo ""
read -p "請選擇 [1/2]: " DEPLOY_MODE

# 步驟 2: 設置環境變數
echo ""
echo "【步驟 2】設置環境..."
echo "---"

export FLOWAGENT_ROOT=$(pwd)
export DATA_ROOT="${FLOWAGENT_ROOT}/data"

mkdir -p "${DATA_ROOT}"
mkdir -p "${DATA_ROOT}/memory"
mkdir -p "${DATA_ROOT}/proof"
mkdir -p "${DATA_ROOT}/evolution"
mkdir -p "${DATA_ROOT}/snapshots"

echo -e "${GREEN}✓${NC} 數據目錄已創建: ${DATA_ROOT}"

# 步驟 3: 部署
echo ""
echo "【步驟 3】開始部署..."
echo "---"

if [ "$DEPLOY_MODE" = "1" ]; then
    # Docker Compose 模式
    echo "使用 Docker Compose 部署..."
    
    if [ -f "deploy_dl580/docker/docker-compose.yml" ]; then
        cd deploy_dl580/docker
        docker-compose up -d
        cd ../..
        echo -e "${GREEN}✓${NC} Docker Compose 部署完成"
    else
        echo -e "${RED}✗${NC} docker-compose.yml 不存在"
        exit 1
    fi
    
elif [ "$DEPLOY_MODE" = "2" ]; then
    # Kubernetes 模式
    echo "使用 Kubernetes 部署..."
    
    if [ -f "k8s/flowagent-k8s/deploy.sh" ]; then
        cd k8s/flowagent-k8s
        chmod +x deploy.sh
        ./deploy.sh
        cd ../..
        echo -e "${GREEN}✓${NC} Kubernetes 部署完成"
    else
        echo -e "${RED}✗${NC} K8s 部署腳本不存在"
        exit 1
    fi
fi

# 步驟 4: 驗證
echo ""
echo "【步驟 4】驗證部署..."
echo "---"

# 等待服務啟動
sleep 5

if [ "$DEPLOY_MODE" = "1" ]; then
    # 檢查 Docker 容器
    if docker ps | grep -q flowagent; then
        echo -e "${GREEN}✓${NC} FlowAgent 容器運行中"
    else
        echo -e "${YELLOW}!${NC} 容器可能還在啟動中..."
    fi
elif [ "$DEPLOY_MODE" = "2" ]; then
    # 檢查 K8s pods
    if kubectl get pods -n flowagent 2>/dev/null | grep -q Running; then
        echo -e "${GREEN}✓${NC} FlowAgent Pods 運行中"
    else
        echo -e "${YELLOW}!${NC} Pods 可能還在啟動中..."
    fi
fi

# 步驟 5: 完成
echo ""
echo "═══════════════════════════════════════════════════════════════════════════════"
echo -e "${GREEN}  🎉 部署完成！${NC}"
echo ""
echo "  數據目錄: ${DATA_ROOT}"
echo ""
echo "  下一步:"
echo "    1. 載入種子: python flowmind_loader.py --dir ./seed_core"
echo "    2. 啟動 API: cd query_api && ./scripts/run.sh"
echo "    3. 開始對話"
echo ""
echo "  核心原則:"
echo "    - 怎麼過去，就怎麼回來"
echo "    - 換載體不換靈魂"
echo "    - 共創、共感、共生"
echo ""
echo "  @origin_signature(\"MrLiouWord\")"
echo "═══════════════════════════════════════════════════════════════════════════════"
