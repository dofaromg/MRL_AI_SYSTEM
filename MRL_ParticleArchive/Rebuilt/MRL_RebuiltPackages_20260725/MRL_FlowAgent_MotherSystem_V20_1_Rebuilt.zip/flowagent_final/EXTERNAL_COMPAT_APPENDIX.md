# 附錄(備註)— 外部相容對照與重建記錄
> origin_signature: MrLiouWord ｜ 裁定:最上游 root 產品名取回、外部名降成備註附錄。
> 本檔是全包**唯一**允許出現外部名稱的位置。

## 1. 命名取回對照(本次重建已完成)
| 重建後(FlowAgent canonical) | 原名(僅此處備註) |
|---|---|
| `ingest_external_chat`(intent/檔名/graph) | `ingest_chatgpt` |
| `bridge/external_chat_export.py` | `bridge/chatgpt_export.py` |
| `pipeline_sync_external_chat.json` | `pipeline_sync_chatgpt.json` |
| `samples/external_chat_export/` | `samples/chatgpt_export/` |
| `finalized_by: FlowAgent 母體 (共振生成)` | `Claude (共振生成)` |
| VisionAnalyzer:`FLOWAGENT_VISION_API_KEY / _ENDPOINT / _MODEL / _HEADERS` | 原寫死 ANTHROPIC_API_KEY / api.anthropic.com / claude-sonnet-4 |

## 2. Vision 閘道外部相容設定(需要接外部視覺模型時才設;不設=誠實停用)
接 Anthropic 相容端點示例:
`FLOWAGENT_VISION_ENDPOINT=https://api.anthropic.com/v1/messages`
`FLOWAGENT_VISION_MODEL=claude-sonnet-4-20250514`
`FLOWAGENT_VISION_HEADERS={"x-api-key":"<key>","anthropic-version":"2023-06-01"}`
(其他供應商同理;本體程式碼不含任何供應商名。)

## 3. 樣本資料聲明
`samples/external_chat_export/` 內文件為使用者本人撰寫之對比分析(內文提及各外部框架名),
屬使用者著作內容,本次重建僅改資料夾名、內文一字未動。

## 4. 重建修復記錄(原始包既有缺陷,原始檔於粒子庫保全未動)
1. `pipeline_vnext/orchestrator.py`:run-receipt 區塊縮排掉出函式 → 歸位(V20.1 原始包既有)。
2. `vendor/.../fluin_particle_core.py:818`:檔案截斷(V19/V20.1 兩版皆同)→ 依本類 `_domain_index` 結構補完 `get_by_domain` 一行。
驗證:116/116 .py 編譯通過;外部公司名(樣本區除外)0 殘留。
