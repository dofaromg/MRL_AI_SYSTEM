#!/usr/bin/env python3
import argparse, os, json
from datetime import datetime, timezone

def utc():
    return datetime.now(timezone.utc).isoformat()

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--data-root", default="data")
    ap.add_argument("--rules", default="evaluator/rules.json")
    args=ap.parse_args()

    rules=json.loads(open(args.rules,"r",encoding="utf-8").read())
    dr=args.data_root
    agg_path=os.path.join(dr,"telemetry","aggregates.json")
    if not os.path.exists(agg_path):
        print(json.dumps({"ok":False,"error":"missing_aggregates_run_telemetry_collect_first"}, ensure_ascii=False, indent=2))
        return

    agg=json.loads(open(agg_path,"r",encoding="utf-8").read())
    th=rules.get("thresholds") or {}
    fail_rate_max=float(th.get("fail_rate_max",0.2))
    mean_coh_min=float(th.get("mean_coherence_min",0.7))

    verdict={"ok":True,"pass":True,"fail_rate":agg.get("fail_rate"),"mean_coherence":agg.get("mean_coherence"),"reasons":[],"timestamp":utc()}

    if verdict["fail_rate"] is not None and verdict["fail_rate"]>fail_rate_max:
        verdict["pass"]=False
        verdict["reasons"].append(f"fail_rate>{fail_rate_max}")
    mc=verdict["mean_coherence"]
    if mc is not None and mc<mean_coh_min:
        verdict["pass"]=False
        verdict["reasons"].append(f"mean_coherence<{mean_coh_min}")

    os.makedirs(os.path.join(dr,"evaluation"), exist_ok=True)
    with open(os.path.join(dr,"evaluation","latest.json"),"w",encoding="utf-8") as f:
        json.dump(verdict,f,ensure_ascii=False,indent=2)

    print(json.dumps(verdict, ensure_ascii=False, indent=2))

if __name__=="__main__":
    main()
