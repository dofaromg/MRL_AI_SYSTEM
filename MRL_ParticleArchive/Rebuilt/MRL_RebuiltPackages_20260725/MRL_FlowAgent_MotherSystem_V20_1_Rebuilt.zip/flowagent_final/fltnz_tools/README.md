# FlowAgent FLTNZ Tools v1

這是一個「不兜圈、直接可用」的工具包：
- 驗證 `.fltnz` 封包完整性（manifest / proof.chain / signature）
- 解包 `.fltnz` → 還原 payload（memory.pack 裡的 zip）

## Commands

```bash
python tools/fltnz_verify.py --file flowagent_mother_system_v1.fltnz
python tools/fltnz_unpack.py --file flowagent_mother_system_v1.fltnz --out ./unpacked_fltnz
```
