#!/usr/bin/env python3
import argparse, zipfile, os, json, sys, io

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--file", required=True, help="*.fltnz")
    ap.add_argument("--out", required=True, help="output dir")
    args = ap.parse_args()

    os.makedirs(args.out, exist_ok=True)

    try:
        z = zipfile.ZipFile(args.file, "r")
    except Exception as e:
        print(json.dumps({"ok": False, "error": f"open_failed:{e}"}, ensure_ascii=False, indent=2))
        sys.exit(2)

    # Extract envelope files
    for name in ["manifest.json","seed.bin","law.pack","proof.chain","signature.sig"]:
        z.extract(name, path=args.out)

    # Unpack memory.pack which is a zip payload
    mem = z.read("memory.pack")
    payload_dir = os.path.join(args.out, "payload")
    os.makedirs(payload_dir, exist_ok=True)
    try:
        with zipfile.ZipFile(io.BytesIO(mem), "r") as pz:
            pz.extractall(payload_dir)
    except Exception as e:
        print(json.dumps({"ok": False, "error": f"payload_unpack_failed:{e}"}, ensure_ascii=False, indent=2))
        sys.exit(3)

    print(json.dumps({"ok": True, "out": os.path.abspath(args.out)}, ensure_ascii=False, indent=2))
    sys.exit(0)

if __name__ == "__main__":
    main()
