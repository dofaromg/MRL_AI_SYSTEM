#!/usr/bin/env python3
import argparse, zipfile, json, hashlib, sys

REQUIRED = ["manifest.json","seed.bin","law.pack","memory.pack","proof.chain","signature.sig"]

def sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--file", required=True, help="*.fltnz (zip container)")
    args = ap.parse_args()

    try:
        z = zipfile.ZipFile(args.file, "r")
    except Exception as e:
        print(json.dumps({"ok": False, "error": f"open_failed:{e}"}, ensure_ascii=False, indent=2))
        sys.exit(2)

    names = set(z.namelist())
    missing = [x for x in REQUIRED if x not in names]
    if missing:
        print(json.dumps({"ok": False, "error": "missing_required", "missing": missing}, ensure_ascii=False, indent=2))
        sys.exit(3)

    manifest = json.loads(z.read("manifest.json").decode("utf-8"))
    memory_pack = z.read("memory.pack")
    sig = z.read("signature.sig").decode("utf-8", errors="ignore").strip()

    memory_hash = sha256_bytes(memory_pack)
    expect_sig_prefix = memory_hash

    ok_sig = sig.startswith(expect_sig_prefix)
    result = {
        "ok": bool(ok_sig),
        "package_id": manifest.get("package_id"),
        "version": manifest.get("version"),
        "origin": manifest.get("origin"),
        "memory_sha256": memory_hash,
        "signature_ok": bool(ok_sig)
    }

    # proof.chain minimal check
    proof_lines = z.read("proof.chain").decode("utf-8", errors="ignore").splitlines()
    proof_ok = any(line.strip().startswith("{") for line in proof_lines)
    result["proof_ok"] = bool(proof_ok)
    result["ok"] = bool(ok_sig and proof_ok)

    print(json.dumps(result, ensure_ascii=False, indent=2))
    sys.exit(0 if result["ok"] else 4)

if __name__ == "__main__":
    main()
