# K8s Integration (Mother v2)

此目錄為 `flowagent-k8s-deployment.zip` 併入母體 v2 的整合結果。

## 使用方式（最簡）

1) 先準備 image（兩種路徑擇一）
- A. 直接用你自己的 registry image（建議）
- B. 用 k8s 內建 build（若你的叢集允許）

2) 套用 manifests
```bash
kubectl apply -f k8s/
```

3) 檢查
```bash
kubectl get pods -A | grep -i flowagent
kubectl get svc  -A | grep -i flowagent
```

## 注意
- 若 manifests 內有 image 名稱/namespace/ConfigMap 路徑，請依你環境調整。
- 你已可用 Query API（port 8765）作為 service 對外入口。
- Data 目錄（FLOWAGENT_DATA_ROOT）在 K8s 需對應 PV/PVC 或 emptyDir（視你的持久化策略）。
生成時間：2025-12-29T00:01:04.583174+00:00
