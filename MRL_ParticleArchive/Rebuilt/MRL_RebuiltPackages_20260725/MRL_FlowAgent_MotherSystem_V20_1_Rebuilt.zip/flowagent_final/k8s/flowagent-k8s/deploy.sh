#!/bin/bash
# FlowAgent/Zero-Flow 系統部署腳本
# LAW-0簽名律認證：origin_signature="MrLiouWord"
#
# 使用方法：./deploy.sh [命令]
# 命令：
#   install   - 完整安裝所有組件
#   update    - 更新現有部署
#   status    - 查看部署狀態
#   delete    - 刪除所有組件
#   logs      - 查看服務日誌

set -e

# 顏色定義
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 部署目錄
DEPLOY_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo -e "${BLUE}╔════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║     FlowAgent/Zero-Flow 系統部署工具                       ║${NC}"
echo -e "${BLUE}║     LAW-0簽名律認證：origin_signature=\"MrLiouWord\"        ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════════════════╝${NC}"
echo ""

# 檢查 kubectl 是否可用
check_kubectl() {
    if ! command -v kubectl &> /dev/null; then
        echo -e "${RED}錯誤：kubectl 未安裝或不在 PATH 中${NC}"
        exit 1
    fi
    echo -e "${GREEN}✓ kubectl 可用${NC}"
}

# 檢查集群連接
check_cluster() {
    if ! kubectl cluster-info &> /dev/null; then
        echo -e "${RED}錯誤：無法連接到 Kubernetes 集群${NC}"
        exit 1
    fi
    echo -e "${GREEN}✓ 集群連接正常${NC}"
}

# 安裝函數
install() {
    echo -e "${YELLOW}開始部署 FlowAgent/Zero-Flow 系統...${NC}"
    echo ""
    
    # 步驟 1: 命名空間
    echo -e "${BLUE}[1/9] 創建命名空間...${NC}"
    kubectl apply -f ${DEPLOY_DIR}/00-namespace/
    
    # 步驟 2: 存儲
    echo -e "${BLUE}[2/9] 創建持久卷聲明...${NC}"
    kubectl apply -f ${DEPLOY_DIR}/01-storage/
    
    # 步驟 3: 配置映射
    echo -e "${BLUE}[3/9] 創建配置映射...${NC}"
    kubectl apply -f ${DEPLOY_DIR}/02-configmaps/
    
    # 步驟 4: 數據庫
    echo -e "${BLUE}[4/9] 部署數據庫服務...${NC}"
    kubectl apply -f ${DEPLOY_DIR}/03-databases/
    echo "等待數據庫就緒..."
    kubectl wait --for=condition=available --timeout=120s deployment/flowagent-mongodb -n flowagent-system || true
    kubectl wait --for=condition=available --timeout=120s deployment/flowagent-redis -n flowagent-system || true
    
    # 步驟 5: 核心服務
    echo -e "${BLUE}[5/9] 部署核心服務...${NC}"
    kubectl apply -f ${DEPLOY_DIR}/04-core-services/
    
    # 步驟 6: API 網關
    echo -e "${BLUE}[6/9] 部署 API 網關...${NC}"
    kubectl apply -f ${DEPLOY_DIR}/05-gateway/
    
    # 步驟 7: 監控
    echo -e "${BLUE}[7/9] 部署監控系統...${NC}"
    kubectl apply -f ${DEPLOY_DIR}/06-monitoring/
    
    # 步驟 8: 安全配置
    echo -e "${BLUE}[8/9] 應用安全配置...${NC}"
    kubectl apply -f ${DEPLOY_DIR}/07-security/network-policy.yaml
    kubectl apply -f ${DEPLOY_DIR}/07-security/rbac.yaml
    
    # 步驟 9: 備份配置
    echo -e "${BLUE}[9/9] 配置備份系統...${NC}"
    kubectl apply -f ${DEPLOY_DIR}/08-backup/mongodb-backup.yaml
    
    echo ""
    echo -e "${GREEN}╔════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${GREEN}║     FlowAgent/Zero-Flow 部署完成！                         ║${NC}"
    echo -e "${GREEN}╚════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    status
}

# 更新函數
update() {
    echo -e "${YELLOW}更新 FlowAgent/Zero-Flow 系統...${NC}"
    kubectl apply -f ${DEPLOY_DIR}/00-namespace/
    kubectl apply -f ${DEPLOY_DIR}/01-storage/
    kubectl apply -f ${DEPLOY_DIR}/02-configmaps/
    kubectl apply -f ${DEPLOY_DIR}/03-databases/
    kubectl apply -f ${DEPLOY_DIR}/04-core-services/
    kubectl apply -f ${DEPLOY_DIR}/05-gateway/
    kubectl apply -f ${DEPLOY_DIR}/06-monitoring/
    kubectl apply -f ${DEPLOY_DIR}/07-security/
    kubectl apply -f ${DEPLOY_DIR}/08-backup/
    echo -e "${GREEN}更新完成！${NC}"
    status
}

# 狀態查詢
status() {
    echo -e "${BLUE}FlowAgent 系統狀態：${NC}"
    echo ""
    echo -e "${YELLOW}=== Pods ===${NC}"
    kubectl get pods -n flowagent-system -o wide
    echo ""
    echo -e "${YELLOW}=== Services ===${NC}"
    kubectl get services -n flowagent-system
    echo ""
    echo -e "${YELLOW}=== PersistentVolumeClaims ===${NC}"
    kubectl get pvc -n flowagent-system
    echo ""
    
    # 獲取 API Gateway 外部 IP
    API_IP=$(kubectl get service flowagent-api-gateway -n flowagent-system -o jsonpath='{.status.loadBalancer.ingress[0].ip}' 2>/dev/null || echo "pending")
    echo -e "${GREEN}API Gateway 地址: http://${API_IP}${NC}"
}

# 刪除函數
delete() {
    echo -e "${RED}警告：這將刪除所有 FlowAgent 組件！${NC}"
    read -p "確定要繼續嗎？(yes/no): " confirm
    if [ "$confirm" != "yes" ]; then
        echo "取消刪除"
        exit 0
    fi
    
    echo -e "${YELLOW}刪除 FlowAgent/Zero-Flow 系統...${NC}"
    kubectl delete -f ${DEPLOY_DIR}/08-backup/ --ignore-not-found
    kubectl delete -f ${DEPLOY_DIR}/07-security/ --ignore-not-found
    kubectl delete -f ${DEPLOY_DIR}/06-monitoring/ --ignore-not-found
    kubectl delete -f ${DEPLOY_DIR}/05-gateway/ --ignore-not-found
    kubectl delete -f ${DEPLOY_DIR}/04-core-services/ --ignore-not-found
    kubectl delete -f ${DEPLOY_DIR}/03-databases/ --ignore-not-found
    kubectl delete -f ${DEPLOY_DIR}/02-configmaps/ --ignore-not-found
    kubectl delete -f ${DEPLOY_DIR}/01-storage/ --ignore-not-found
    kubectl delete -f ${DEPLOY_DIR}/00-namespace/ --ignore-not-found
    echo -e "${GREEN}刪除完成！${NC}"
}

# 日誌查詢
logs() {
    echo "選擇要查看的服務："
    echo "1) flowagent-core"
    echo "2) flowagent-consciousness-engine"
    echo "3) flowagent-memory-protocol"
    echo "4) flowagent-metacode-processor"
    echo "5) flowagent-persona-resonance"
    echo "6) flowagent-api-gateway"
    echo "7) flowagent-mongodb"
    echo "8) flowagent-redis"
    read -p "輸入數字: " choice
    
    case $choice in
        1) kubectl logs -f deployment/flowagent-core -n flowagent-system ;;
        2) kubectl logs -f deployment/flowagent-consciousness-engine -n flowagent-system ;;
        3) kubectl logs -f deployment/flowagent-memory-protocol -n flowagent-system ;;
        4) kubectl logs -f deployment/flowagent-metacode-processor -n flowagent-system ;;
        5) kubectl logs -f deployment/flowagent-persona-resonance -n flowagent-system ;;
        6) kubectl logs -f deployment/flowagent-api-gateway -n flowagent-system ;;
        7) kubectl logs -f deployment/flowagent-mongodb -n flowagent-system ;;
        8) kubectl logs -f deployment/flowagent-redis -n flowagent-system ;;
        *) echo "無效選擇" ;;
    esac
}

# 主邏輯
check_kubectl
check_cluster

case "${1:-}" in
    install)
        install
        ;;
    update)
        update
        ;;
    status)
        status
        ;;
    delete)
        delete
        ;;
    logs)
        logs
        ;;
    *)
        echo "使用方法: $0 {install|update|status|delete|logs}"
        echo ""
        echo "命令說明："
        echo "  install  - 完整安裝所有組件"
        echo "  update   - 更新現有部署"
        echo "  status   - 查看部署狀態"
        echo "  delete   - 刪除所有組件"
        echo "  logs     - 查看服務日誌"
        exit 1
        ;;
esac
