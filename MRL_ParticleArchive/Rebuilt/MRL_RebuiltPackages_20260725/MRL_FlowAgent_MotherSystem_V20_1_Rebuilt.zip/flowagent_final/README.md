# pipeline_vnext_guided_breakthrough_v1

目標：保留「Pipeline 敘事入口」，但用 Gate + Runner 讓舊流程自然露出天花板，
並把例外導向旁路 Runner（Audit/Repair/Rebuild/Deploy），為後續 RoleGraph 收斂鋪路。

## 放置方式
把本包解壓到母體根目錄（與 `cli/`、`flowagent/` 同層）。

## 最簡指令

### 1) 跑引導型 pipeline（預設 graph）
```bash
python pipeline_vnext/cli_vnext.py run --data-root data --graph pipeline_vnext/graphs/pipeline_default.json
```

### 2) 只跑旁路（例：audit）
```bash
python pipeline_vnext/cli_vnext.py runner audit --data-root data
```

### 3) 例外導向 repair（示範）
```bash
python pipeline_vnext/cli_vnext.py runner repair --data-root data --reason "manual_hotfix"
```

## 突破點（你要的引導）
- 每個 stage 產生 trace：event_id/rid/tick/persona_id/merkle_root
- 每個 stage 寫 proof：before/after/law_applied/coherence/entropy
- stage 失敗時 redirect 到 runner（不是 if/else 塞回 pipeline）
