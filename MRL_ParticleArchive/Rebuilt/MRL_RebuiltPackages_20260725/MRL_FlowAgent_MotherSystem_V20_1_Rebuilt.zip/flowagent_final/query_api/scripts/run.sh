#!/bin/bash
set -e
export FLOWAGENT_DATA_ROOT=${FLOWAGENT_DATA_ROOT:-./data}
uvicorn server.app:app --host 0.0.0.0 --port ${PORT:-8765}
