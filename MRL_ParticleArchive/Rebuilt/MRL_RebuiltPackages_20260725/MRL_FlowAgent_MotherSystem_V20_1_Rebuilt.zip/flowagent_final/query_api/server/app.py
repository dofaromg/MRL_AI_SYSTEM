from fastapi import FastAPI
from pydantic import BaseModel
import os

try:
    from flowagent.query.search import keyword_query
except Exception:
    keyword_query = None

app = FastAPI(title="FlowAgent Query API", version="v1")

class QueryReq(BaseModel):
    text: str
    top_k: int = 10

@app.get("/health")
def health():
    return {"ok": True}

@app.post("/query")
def query(req: QueryReq):
    data_root = os.environ.get("FLOWAGENT_DATA_ROOT", "data")
    if keyword_query is None:
        return {"ok": False, "error": "flowagent.query.search not found (place this pack next to mother system or install it)."}
    res = keyword_query(data_root, req.text, top_k=req.top_k)
    res["ok"] = True
    return res
