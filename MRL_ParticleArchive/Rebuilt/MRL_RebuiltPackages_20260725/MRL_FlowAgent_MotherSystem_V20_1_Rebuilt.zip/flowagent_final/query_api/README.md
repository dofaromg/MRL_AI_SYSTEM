# FlowAgent Query API v1

把母體的 `query` 從 CLI 升級成 HTTP API（FastAPI）。

## Install
```bash
pip install -r requirements.txt
```

## Run
```bash
export FLOWAGENT_DATA_ROOT=./data
uvicorn server.app:app --host 0.0.0.0 --port 8765
```

## Endpoints
- GET `/health`
- POST `/query`  ({"text":"...", "top_k":10})
