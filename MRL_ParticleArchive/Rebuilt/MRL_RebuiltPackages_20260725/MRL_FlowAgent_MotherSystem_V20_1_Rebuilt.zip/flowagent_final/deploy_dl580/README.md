# DL580G9 Deploy Pack v2

目標：把 `flowagent_mother_system_v1` 以真實主機路徑部署成長駐服務。

建議：
- 安裝目錄：/opt/flowagent
- Secrets：/etc/flowagent/secrets.env
- Data：/opt/flowagent/data

## systemd
```bash
sudo mkdir -p /etc/flowagent
sudo cp env/secrets.env.example /etc/flowagent/secrets.env
sudo cp systemd/flowagent.service /etc/systemd/system/flowagent.service
sudo systemctl daemon-reload
sudo systemctl enable flowagent
sudo systemctl start flowagent
```

## docker（可選）
```bash
cd docker
cp ../env/secrets.env.example ./secrets.env
docker compose up -d
```

生成時間：2025-12-16T22:54:52.931089+00:00
