#!/bin/bash
systemctl status flowagent --no-pager
