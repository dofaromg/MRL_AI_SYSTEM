#!/bin/bash
set -e
sudo mkdir -p /etc/flowagent
sudo cp ./env/secrets.env.example /etc/flowagent/secrets.env || true
sudo cp ./systemd/flowagent.service /etc/systemd/system/flowagent.service
sudo systemctl daemon-reload
sudo systemctl enable flowagent
sudo systemctl restart flowagent
echo "OK"
