#!/bin/bash
set -e
echo "Additive install:"
echo "  1) unzip this package at mother root"
echo "  2) run: python pipeline_vnext/cli_vnext.py run --data-root data --graph pipeline_vnext/graphs/pipeline_default.json"
