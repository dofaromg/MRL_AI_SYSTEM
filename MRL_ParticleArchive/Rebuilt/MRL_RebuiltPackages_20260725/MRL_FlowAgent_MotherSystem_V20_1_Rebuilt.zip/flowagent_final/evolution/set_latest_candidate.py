#!/usr/bin/env python3
import argparse, os, shutil, json
from datetime import datetime, timezone

def utc():
    return datetime.now(timezone.utc).isoformat()

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--data-root", default="data")
    ap.add_argument("--candidate", required=True, help="path to candidate json")
    args=ap.parse_args()

    dr=args.data_root
    src=args.candidate
    dst=os.path.join(dr,"evolution","candidates","latest.json")
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    shutil.copy(src, dst)

    meta={"latest": dst, "source": os.path.abspath(src), "updated_at": utc()}
    with open(os.path.join(dr,"evolution","candidates","latest_meta.json"),"w",encoding="utf-8") as f:
        json.dump(meta,f,ensure_ascii=False,indent=2)

    print(json.dumps({"ok":True, **meta}, ensure_ascii=False, indent=2))

if __name__=="__main__":
    main()
