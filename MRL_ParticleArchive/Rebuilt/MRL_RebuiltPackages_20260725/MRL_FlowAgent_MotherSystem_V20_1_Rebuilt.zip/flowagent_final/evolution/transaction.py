#!/usr/bin/env python3
import argparse, os, json, shutil, subprocess, shlex, hashlib
from datetime import datetime, timezone
from typing import Dict, Any, List

def utc():
    return datetime.now(timezone.utc).isoformat()

def _sha(s: str) -> str:
    return hashlib.sha256(s.encode("utf-8")).hexdigest()

def load_json(p: str) -> dict:
    return json.loads(open(p,"r",encoding="utf-8").read())

def deep_merge(a: dict, b: dict) -> dict:
    out = dict(a)
    for k,v in (b or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = deep_merge(out[k], v)
        else:
            out[k] = v
    return out

def run_cmd(cmd: str) -> Dict[str, Any]:
    argv = shlex.split(cmd)
    p = subprocess.run(argv, capture_output=True, text=True)
    return {"cmd": cmd, "returncode": p.returncode, "stdout": (p.stdout or "")[-4000:], "stderr": (p.stderr or "")[-4000:]}

def apply_patches(root: str, suggestions: List[dict], txn_dir: str) -> List[dict]:
    results=[]
    backups_dir=os.path.join(txn_dir, "backups")
    os.makedirs(backups_dir, exist_ok=True)
    for s in suggestions:
        tgt=s.get("target")
        patch=s.get("patch") or {}
        if not tgt:
            continue
        tp=os.path.join(root, tgt)
        if not os.path.exists(tp):
            results.append({"ok":False,"target":tgt,"error":"target_missing"})
            continue
        before=load_json(tp)
        after=deep_merge(before, patch)
        bak=os.path.join(backups_dir, os.path.basename(tgt)+".bak.json")
        shutil.copy(tp, bak)
        with open(tp,"w",encoding="utf-8") as f:
            json.dump(after,f,ensure_ascii=False,indent=2)
        results.append({"ok":True,"target":tgt,"backup":bak,"changed": before!=after})
    return results

def rollback(root: str, patch_results: List[dict]) -> None:
    for r in patch_results:
        if not r.get("ok"): 
            continue
        tgt=r.get("target")
        bak=r.get("backup")
        if tgt and bak and os.path.exists(bak):
            shutil.copy(bak, os.path.join(root, tgt))

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--data-root", default="data")
    ap.add_argument("--candidate", required=True)
    ap.add_argument("--verify-cmd", action="append", default=[
        "python cli/main.py --data-root data proof_verify"
    ], help="can be repeated; default includes proof_verify")
    ap.add_argument("--commit", action="store_true", help="if not set, runs as dry-run with rollback")
    args=ap.parse_args()

    root=os.getcwd()
    cand=load_json(args.candidate)
    suggestions=cand.get("suggestions") or []
    txn_id=_sha(json.dumps(cand,ensure_ascii=False)+utc())[:16]
    txn_dir=os.path.join(args.data_root,"evolution","transactions",txn_id)
    os.makedirs(txn_dir, exist_ok=True)

    report={"txn_id":txn_id,"candidate":os.path.abspath(args.candidate),"commit":args.commit,"started_at":utc(),"patch_results":[],"verify_results":[],"final":"unknown"}

    pr=apply_patches(root, suggestions, txn_dir)
    report["patch_results"]=pr

    all_ok=True
    for cmd in args.verify_cmd:
        vr=run_cmd(cmd)
        report["verify_results"].append(vr)
        if vr["returncode"]!=0:
            all_ok=False

    if all_ok and args.commit:
        applied_dir=os.path.join(args.data_root,"evolution","applied_backups")
        os.makedirs(applied_dir, exist_ok=True)
        for r in pr:
            if r.get("ok") and r.get("backup") and os.path.exists(r["backup"]):
                dst=os.path.join(applied_dir, os.path.basename(r["backup"]).replace(".bak.json", f".{txn_id}.bak.json"))
                shutil.copy(r["backup"], dst)
        report["final"]="committed"
    else:
        rollback(root, pr)
        report["final"]="rolled_back"

    report["ended_at"]=utc()
    os.makedirs(os.path.join(args.data_root,"evolution","transaction_reports"), exist_ok=True)
    out_path=os.path.join(args.data_root,"evolution","transaction_reports",f"{txn_id}.json")
    with open(out_path,"w",encoding="utf-8") as f:
        json.dump(report,f,ensure_ascii=False,indent=2)

    
# append ledger (immutable log)
try:
    ledger_path = os.path.join(args.data_root, "evolution", "ledger.jsonl")
    os.makedirs(os.path.dirname(ledger_path), exist_ok=True)
    ledger_rec = {
        "txn_id": txn_id,
        "candidate": os.path.abspath(args.candidate),
        "final": report["final"],
        "commit": args.commit,
        "started_at": report.get("started_at"),
        "ended_at": report.get("ended_at"),
        "verify_ok": all_ok,
    }
    with open(ledger_path, "a", encoding="utf-8") as lf:
        lf.write(json.dumps(ledger_rec, ensure_ascii=False) + "\n")
except Exception:
    pass

print(json.dumps({"ok":True,"txn_id":txn_id,"final":report["final"],"report":out_path}, ensure_ascii=False, indent=2))

if __name__=="__main__":
    main()
