#!/usr/bin/env python3
import argparse, os, json, shutil
from datetime import datetime, timezone
from typing import Dict, Any

def utc():
    return datetime.now(timezone.utc).isoformat()

def load_json(p: str) -> dict:
    return json.loads(open(p,"r",encoding="utf-8").read())

def deep_merge(a: dict, b: dict) -> dict:
    # b overrides/merges into a
    out = dict(a)
    for k,v in (b or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = deep_merge(out[k], v)
        else:
            out[k] = v
    return out

def apply_one(root: str, target_rel: str, patch_obj: dict, dry_run: bool) -> Dict[str, Any]:
    target_path = os.path.join(root, target_rel)
    if not os.path.exists(target_path):
        return {"ok": False, "error": "target_missing", "target": target_rel}

    before = load_json(target_path)
    after = deep_merge(before, patch_obj)

    if dry_run:
        return {"ok": True, "target": target_rel, "changed": before != after}

    # backup
    backup_dir = os.path.join(root, "data", "evolution", "applied_backups")
    os.makedirs(backup_dir, exist_ok=True)
    bak_path = os.path.join(backup_dir, os.path.basename(target_rel) + "." + utc().replace(":","-") + ".bak.json")
    shutil.copy(target_path, bak_path)

    with open(target_path, "w", encoding="utf-8") as f:
        json.dump(after, f, ensure_ascii=False, indent=2)

    return {"ok": True, "target": target_rel, "backup": bak_path, "changed": True}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--data-root", default="data")
    ap.add_argument("--candidate", required=True, help="path to data/evolution/candidates/<id>.json")
    ap.add_argument("--dry-run", action="store_true")
    args=ap.parse_args()

    cand = load_json(args.candidate)
    suggestions = cand.get("suggestions") or []
    root = os.getcwd()

    report = {
        "candidate": os.path.abspath(args.candidate),
        "dry_run": args.dry_run,
        "applied_at": utc(),
        "results": []
    }

    for s in suggestions:
        tgt = s.get("target")
        patch = s.get("patch") or {}
        if not tgt:
            continue
        res = apply_one(root, tgt, patch, dry_run=args.dry_run)
        report["results"].append(res)

    os.makedirs(os.path.join(args.data_root, "evolution", "applied_reports"), exist_ok=True)
    out_path = os.path.join(args.data_root, "evolution", "applied_reports", "latest.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)

    print(json.dumps({"ok": True, "report": out_path, "dry_run": args.dry_run}, ensure_ascii=False, indent=2))

if __name__=="__main__":
    main()
