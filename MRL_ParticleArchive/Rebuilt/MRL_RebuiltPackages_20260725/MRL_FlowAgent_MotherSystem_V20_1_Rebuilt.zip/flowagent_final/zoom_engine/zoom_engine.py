#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
═══════════════════════════════════════════════════════════════════════════════
    Zoom Engine v1.0
    放大縮小引擎 - 控制視角縮放、跳維切換、模組細節展開與收斂
    
    核心公式：P_{k+1} = N_k · P_k · η_k
    反向還原：P_k = P_{k+1} / (N_k · η_k)
    
    @origin_signature("MrLiouWord")
    @version: v1.0
    @created: 2024-12
═══════════════════════════════════════════════════════════════════════════════
"""

import json
import hashlib
from dataclasses import dataclass, field, asdict
from typing import Dict, List, Any, Optional, Tuple
from enum import Enum

# ═══════════════════════════════════════════════════════════════════════════════
# 常量
# ═══════════════════════════════════════════════════════════════════════════════

VERSION = "1.0.0"
SIGNATURE = "MRSIG-ZOOMENGINE-V1"

# ═══════════════════════════════════════════════════════════════════════════════
# 縮放層級定義
# ═══════════════════════════════════════════════════════════════════════════════

class ZoomLevel(str, Enum):
    MICRO = "micro"      # 最小粒子層
    CORE = "core"        # 核心模組層
    MACRO = "macro"      # 系統層
    ABSTRACT = "abstract" # 抽象概念層


class ProjectionMode(str, Enum):
    TEMPORAL = "temporal"       # 時間投影
    HIERARCHICAL = "hierarchical" # 層級投影
    SEMANTIC = "semantic"       # 語義投影
    SPATIAL = "spatial"         # 空間投影


# ═══════════════════════════════════════════════════════════════════════════════
# 資料結構
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class Particle:
    """粒子結構"""
    particle_id: str
    level: ZoomLevel
    content: Any
    children: List[str] = field(default_factory=list)
    parent: Optional[str] = None
    meta: Dict[str, Any] = field(default_factory=dict)
    
    def hash(self) -> str:
        return hashlib.sha256(
            json.dumps({
                "id": self.particle_id,
                "level": self.level,
                "content": str(self.content)
            }, ensure_ascii=False).encode()
        ).hexdigest()[:16]


@dataclass
class ZoomState:
    """縮放狀態"""
    current_level: ZoomLevel = ZoomLevel.CORE
    focus_particle: Optional[str] = None
    visible_particles: List[str] = field(default_factory=list)
    hidden_particles: List[str] = field(default_factory=list)
    projection_mode: ProjectionMode = ProjectionMode.SEMANTIC


@dataclass
class TraceJump:
    """跳點追蹤"""
    from_particle: str
    to_particle: str
    jump_type: str  # expand, collapse, lateral
    suggested_zoom: ZoomLevel
    context: Dict[str, Any] = field(default_factory=dict)


# ═══════════════════════════════════════════════════════════════════════════════
# Zoom Engine
# ═══════════════════════════════════════════════════════════════════════════════

class ZoomEngine:
    """
    放大縮小引擎
    
    功能：
    1. 控制視角縮放（micro ↔ macro）
    2. 跳維切換
    3. 模組細節展開與收斂
    4. 粒子化壓縮與還原
    """
    
    def __init__(self, structure_data: Optional[Dict[str, Any]] = None):
        self.structure = structure_data or {}
        self.particles: Dict[str, Particle] = {}
        self.zoom_state = ZoomState()
        self.trace_history: List[TraceJump] = []
        
        # 層級對應的組件類型
        self.level_components = {
            ZoomLevel.MICRO: "tokens",
            ZoomLevel.CORE: "modules",
            ZoomLevel.MACRO: "systems",
            ZoomLevel.ABSTRACT: "concepts"
        }
        
        # 初始化結構
        if structure_data:
            self._init_from_structure(structure_data)
    
    def _init_from_structure(self, data: Dict[str, Any]):
        """從結構數據初始化"""
        components = data.get("components", {})
        
        # 載入各層級粒子
        for level in ZoomLevel:
            component_key = self.level_components[level]
            items = components.get(component_key, [])
            for item in items:
                if isinstance(item, str):
                    self.add_particle(item, level, item)
                elif isinstance(item, dict):
                    self.add_particle(
                        item.get("id", str(hash(str(item)))),
                        level,
                        item
                    )
    
    # ═══════════════════════════════════════════════════════════════════════════
    # 粒子管理
    # ═══════════════════════════════════════════════════════════════════════════
    
    def add_particle(self, particle_id: str, level: ZoomLevel, content: Any, 
                     parent: Optional[str] = None) -> Particle:
        """添加粒子"""
        particle = Particle(
            particle_id=particle_id,
            level=level,
            content=content,
            parent=parent
        )
        self.particles[particle_id] = particle
        
        # 更新父粒子的 children
        if parent and parent in self.particles:
            self.particles[parent].children.append(particle_id)
        
        return particle
    
    def get_particle(self, particle_id: str) -> Optional[Particle]:
        """獲取粒子"""
        return self.particles.get(particle_id)
    
    # ═══════════════════════════════════════════════════════════════════════════
    # 縮放控制
    # ═══════════════════════════════════════════════════════════════════════════
    
    def set_zoom_level(self, level: ZoomLevel) -> ZoomState:
        """設定縮放層級"""
        if level not in ZoomLevel:
            raise ValueError(f"Invalid zoom level: {level}")
        
        old_level = self.zoom_state.current_level
        self.zoom_state.current_level = level
        
        # 更新可見粒子
        self._update_visibility()
        
        return self.zoom_state
    
    def zoom_in(self) -> ZoomState:
        """放大（進入更細節）"""
        levels = list(ZoomLevel)
        current_idx = levels.index(self.zoom_state.current_level)
        
        if current_idx > 0:
            self.zoom_state.current_level = levels[current_idx - 1]
            self._update_visibility()
        
        return self.zoom_state
    
    def zoom_out(self) -> ZoomState:
        """縮小（進入更抽象）"""
        levels = list(ZoomLevel)
        current_idx = levels.index(self.zoom_state.current_level)
        
        if current_idx < len(levels) - 1:
            self.zoom_state.current_level = levels[current_idx + 1]
            self._update_visibility()
        
        return self.zoom_state
    
    def _update_visibility(self):
        """更新可見性"""
        current_level = self.zoom_state.current_level
        
        self.zoom_state.visible_particles = [
            pid for pid, p in self.particles.items()
            if p.level == current_level
        ]
        
        self.zoom_state.hidden_particles = [
            pid for pid, p in self.particles.items()
            if p.level != current_level
        ]
    
    def get_visible_components(self) -> List[Any]:
        """獲取當前可見組件"""
        return [
            self.particles[pid].content
            for pid in self.zoom_state.visible_particles
            if pid in self.particles
        ]
    
    # ═══════════════════════════════════════════════════════════════════════════
    # 粒子化公式
    # ═══════════════════════════════════════════════════════════════════════════
    
    def expand(self, particle_id: str, N: int = 2, eta: float = 1.0) -> List[Particle]:
        """
        展開粒子 - 放大
        P_{k+1} = N_k · P_k · η_k
        """
        particle = self.particles.get(particle_id)
        if not particle:
            return []
        
        # 如果已有子粒子，返回它們
        if particle.children:
            return [self.particles[cid] for cid in particle.children if cid in self.particles]
        
        # 否則創建新的子粒子
        expanded = []
        content = particle.content
        
        # 根據 N 分割內容
        if isinstance(content, str):
            # 字串分割
            chunk_size = max(1, len(content) // N)
            chunks = [content[i:i+chunk_size] for i in range(0, len(content), chunk_size)]
        elif isinstance(content, dict):
            # 字典分割
            keys = list(content.keys())
            chunk_size = max(1, len(keys) // N)
            chunks = [
                {k: content[k] for k in keys[i:i+chunk_size]}
                for i in range(0, len(keys), chunk_size)
            ]
        elif isinstance(content, list):
            # 列表分割
            chunk_size = max(1, len(content) // N)
            chunks = [content[i:i+chunk_size] for i in range(0, len(content), chunk_size)]
        else:
            chunks = [content]
        
        # 創建子粒子
        for i, chunk in enumerate(chunks):
            child_id = f"{particle_id}_{i}"
            # 子粒子層級比父粒子低一級
            levels = list(ZoomLevel)
            parent_idx = levels.index(particle.level)
            child_level = levels[max(0, parent_idx - 1)]
            
            child = self.add_particle(child_id, child_level, chunk, particle_id)
            child.meta["eta"] = eta
            child.meta["N"] = N
            expanded.append(child)
        
        return expanded
    
    def collapse(self, particle_ids: List[str]) -> Optional[Particle]:
        """
        收斂粒子 - 縮小
        P_k = P_{k+1} / (N_k · η_k)
        """
        if not particle_ids:
            return None
        
        particles = [self.particles[pid] for pid in particle_ids if pid in self.particles]
        if not particles:
            return None
        
        # 合併內容
        contents = [p.content for p in particles]
        
        if all(isinstance(c, str) for c in contents):
            merged_content = "".join(contents)
        elif all(isinstance(c, dict) for c in contents):
            merged_content = {}
            for c in contents:
                merged_content.update(c)
        elif all(isinstance(c, list) for c in contents):
            merged_content = []
            for c in contents:
                merged_content.extend(c)
        else:
            merged_content = contents
        
        # 創建父粒子
        parent_id = f"collapsed_{hashlib.sha256(''.join(particle_ids).encode()).hexdigest()[:8]}"
        
        # 父粒子層級比子粒子高一級
        levels = list(ZoomLevel)
        child_level = particles[0].level
        child_idx = levels.index(child_level)
        parent_level = levels[min(len(levels) - 1, child_idx + 1)]
        
        parent = self.add_particle(parent_id, parent_level, merged_content)
        parent.children = particle_ids
        
        # 更新子粒子的 parent
        for p in particles:
            p.parent = parent_id
        
        return parent
    
    # ═══════════════════════════════════════════════════════════════════════════
    # 跳點追蹤
    # ═══════════════════════════════════════════════════════════════════════════
    
    def trace_jump(self, from_id: str, to_id: str, jump_type: str = "lateral") -> TraceJump:
        """記錄跳點"""
        to_particle = self.particles.get(to_id)
        suggested_zoom = to_particle.level if to_particle else self.zoom_state.current_level
        
        jump = TraceJump(
            from_particle=from_id,
            to_particle=to_id,
            jump_type=jump_type,
            suggested_zoom=suggested_zoom
        )
        
        self.trace_history.append(jump)
        return jump
    
    def trace_jump_context(self, input_trace: str) -> Dict[str, Any]:
        """根據輸入追蹤獲取跳點上下文"""
        jump_table = self.structure.get("trace_jump_map", {})
        result = jump_table.get(input_trace, {
            "jump_to": None,
            "suggested_zoom": "core"
        })
        return result
    
    # ═══════════════════════════════════════════════════════════════════════════
    # 投影模式
    # ═══════════════════════════════════════════════════════════════════════════
    
    def set_projection_mode(self, mode: ProjectionMode):
        """設定投影模式"""
        self.zoom_state.projection_mode = mode
    
    def project(self, particle_id: str) -> Dict[str, Any]:
        """根據當前投影模式投影粒子"""
        particle = self.particles.get(particle_id)
        if not particle:
            return {}
        
        mode = self.zoom_state.projection_mode
        
        if mode == ProjectionMode.TEMPORAL:
            return self._project_temporal(particle)
        elif mode == ProjectionMode.HIERARCHICAL:
            return self._project_hierarchical(particle)
        elif mode == ProjectionMode.SEMANTIC:
            return self._project_semantic(particle)
        elif mode == ProjectionMode.SPATIAL:
            return self._project_spatial(particle)
        
        return asdict(particle)
    
    def _project_temporal(self, particle: Particle) -> Dict[str, Any]:
        """時間投影"""
        return {
            "id": particle.particle_id,
            "timeline": particle.meta.get("timeline", []),
            "created_at": particle.meta.get("created_at"),
            "modified_at": particle.meta.get("modified_at")
        }
    
    def _project_hierarchical(self, particle: Particle) -> Dict[str, Any]:
        """層級投影"""
        return {
            "id": particle.particle_id,
            "level": particle.level,
            "parent": particle.parent,
            "children": particle.children,
            "depth": self._calculate_depth(particle.particle_id)
        }
    
    def _project_semantic(self, particle: Particle) -> Dict[str, Any]:
        """語義投影"""
        return {
            "id": particle.particle_id,
            "content": particle.content,
            "level": particle.level,
            "relations": particle.meta.get("relations", [])
        }
    
    def _project_spatial(self, particle: Particle) -> Dict[str, Any]:
        """空間投影"""
        return {
            "id": particle.particle_id,
            "position": particle.meta.get("position", {"x": 0, "y": 0, "z": 0}),
            "neighbors": particle.meta.get("neighbors", [])
        }
    
    def _calculate_depth(self, particle_id: str, depth: int = 0) -> int:
        """計算粒子深度"""
        particle = self.particles.get(particle_id)
        if not particle or not particle.parent:
            return depth
        return self._calculate_depth(particle.parent, depth + 1)
    
    # ═══════════════════════════════════════════════════════════════════════════
    # 導出
    # ═══════════════════════════════════════════════════════════════════════════
    
    def export_state(self) -> Dict[str, Any]:
        """導出當前狀態"""
        return {
            "signature": SIGNATURE,
            "version": VERSION,
            "zoom_state": asdict(self.zoom_state),
            "particles_count": len(self.particles),
            "visible_count": len(self.zoom_state.visible_particles),
            "trace_history_count": len(self.trace_history)
        }
    
    def export_full(self) -> Dict[str, Any]:
        """導出完整數據"""
        return {
            "signature": SIGNATURE,
            "version": VERSION,
            "zoom_state": asdict(self.zoom_state),
            "particles": {pid: asdict(p) for pid, p in self.particles.items()},
            "trace_history": [asdict(t) for t in self.trace_history]
        }


# ═══════════════════════════════════════════════════════════════════════════════
# CLI
# ═══════════════════════════════════════════════════════════════════════════════

def main():
    """示範用法"""
    # 測試數據
    demo_structure = {
        "components": {
            "tokens": ["seed.01", "token.Δ2", "atom.α1"],
            "modules": ["logic.A", "emotion.B", "memory.C"],
            "systems": ["persona.X", "worldstate.Y"],
            "concepts": ["coherence", "flowlaw", "genesis"]
        },
        "trace_jump_map": {
            "event.T18": {"jump_to": "persona.X", "suggested_zoom": "macro"}
        }
    }
    
    # 創建引擎
    engine = ZoomEngine(demo_structure)
    
    # 測試縮放
    print("=== Zoom Engine Demo ===\n")
    
    print(f"Current Level: {engine.zoom_state.current_level}")
    print(f"Visible: {engine.get_visible_components()}\n")
    
    # 放大
    engine.zoom_in()
    print(f"After Zoom In: {engine.zoom_state.current_level}")
    print(f"Visible: {engine.get_visible_components()}\n")
    
    # 縮小
    engine.zoom_out()
    engine.zoom_out()
    print(f"After Zoom Out x2: {engine.zoom_state.current_level}")
    print(f"Visible: {engine.get_visible_components()}\n")
    
    # 跳點
    jump_result = engine.trace_jump_context("event.T18")
    print(f"Jump Result: {jump_result}\n")
    
    # 展開測試
    engine.add_particle("test_content", ZoomLevel.CORE, "Hello World This Is Test")
    expanded = engine.expand("test_content", N=3)
    print(f"Expanded into {len(expanded)} particles:")
    for p in expanded:
        print(f"  - {p.particle_id}: {p.content}")
    
    print("\n" + "=" * 40)
    print(json.dumps(engine.export_state(), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
