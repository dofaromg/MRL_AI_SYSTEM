# ControlPlane + SelfGrow v1

Additive 安裝：解壓到母體根目錄即可。

## Intent Router（統一入口）
```bash
# 範例：建立 intent 檔
echo '{"intent":"query_check"}' > intent_query.json
python control_plane/intent_router.py --data-root data --intent intent_query.json
```

回執：
- data/intent/<intent_id>.json

## SelfGrow（產生候選 patch，不自動套用）
```bash
python pipeline_vnext/cli_vnext.py run --data-root data --graph pipeline_vnext/graphs/pipeline_evolution_cycle.json
```

產物：
- data/telemetry/aggregates.json
- data/evaluation/latest.json
- data/evolution/candidates/<candidate_id>.json

## Control API（可選）
```bash
pip install -r control_plane/requirements.txt
bash control_plane/scripts/run_api.sh
```

生成時間：2025-12-29T07:36:29.251399+00:00
