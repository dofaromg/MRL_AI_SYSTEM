# ControlPlane + SelfGrow v4 (Evolution Ledger + Commit Graph)

新增：
- evolution/ledger.jsonl：交易結果不可變日誌（transaction.py 自動追加）
- evolution/set_latest_candidate.py：指定 latest.json 指標
- graph: pipeline_apply_transaction_commit.json（commit 模式）
- API: GET /evaluation/latest、GET /evolution/ledger

## 使用建議流程
1) 產生候選
python pipeline_vnext/cli_vnext.py run --data-root data --graph pipeline_vnext/graphs/pipeline_evolution_cycle.json

2) 指定 latest（建議做）
python evolution/set_latest_candidate.py --data-root data --candidate data/evolution/candidates/<id>.json

3) 交易 dry-run（rollback）
python evolution/transaction.py --data-root data --candidate data/evolution/candidates/latest.json

4) 交易 commit（通過 verify 才 commit）
python pipeline_vnext/cli_vnext.py run --data-root data --graph pipeline_vnext/graphs/pipeline_apply_transaction_commit.json

5) API 觀測
- GET /evaluation/latest
- GET /evolution/ledger?limit=50

生成時間：2025-12-29T08:40:33.490502+00:00
