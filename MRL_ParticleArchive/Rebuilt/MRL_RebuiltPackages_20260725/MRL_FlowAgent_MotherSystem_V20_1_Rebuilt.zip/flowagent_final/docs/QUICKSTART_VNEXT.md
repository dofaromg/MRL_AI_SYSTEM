# Quickstart vNext v2 (Guided Breakthrough)

## 1) Default (snapshot + audit + rebuild)
python pipeline_vnext/cli_vnext.py run --data-root data --graph pipeline_vnext/graphs/pipeline_default.json

## 2) Sync ExternalChat sample (uses samples/external_chat_export/)
python pipeline_vnext/cli_vnext.py run --data-root data --graph pipeline_vnext/graphs/pipeline_sync_external_chat.json

## 3) Sync LocalFS (default root=.)
python pipeline_vnext/cli_vnext.py run --data-root data --graph pipeline_vnext/graphs/pipeline_sync_localfs.json

## 4) Query check (proof + query + audit)
python pipeline_vnext/cli_vnext.py run --data-root data --graph pipeline_vnext/graphs/pipeline_query_check.json

## 5) Deploy intent (k8s)
python pipeline_vnext/cli_vnext.py run --data-root data --graph pipeline_vnext/graphs/pipeline_deploy_intent_k8s.json

Outputs:
- data/trace/trace.jsonl
- data/proof/chain.jsonl
- data/audit/latest.json
- data/repair/ticket_latest.json (when redirected)
