# ControlPlane + SelfGrow v3 (Transactional Apply)

新增：
- evolution/transaction.py：apply -> verify -> commit/rollback（交易化）
- runner: apply_txn（仍經 Gate，並寫入 EVOLUTION proof 記錄）
- graph: pipeline_apply_transaction.json
- API: POST /evolution/transaction

## 使用
1) 先產生候選
python pipeline_vnext/cli_vnext.py run --data-root data --graph pipeline_vnext/graphs/pipeline_evolution_cycle.json

2) 交易 dry-run（最後 rollback）
python evolution/transaction.py --data-root data --candidate data/evolution/candidates/<id>.json

3) 交易 commit（通過 verify 才 commit）
python evolution/transaction.py --data-root data --candidate data/evolution/candidates/<id>.json --commit

報告：
- data/evolution/transaction_reports/<txn_id>.json

生成時間：2025-12-29T08:26:59.901364+00:00
