# ControlPlane + SelfGrow v2 (Patch Apply)

新增：
- data/runs/<rid>.json：每次 graph/run 的回執（供 telemetry 計算 redirect_rate）
- telemetry v2：含 redirect_rate
- evolution/apply_candidate.py：候選 patch dry-run / apply（含備份）
- runner: apply_patch（仍經 Gate）
- API：/metrics、/evolution/candidates、/evolution/apply

## 1) 產生候選（同 v1）
python pipeline_vnext/cli_vnext.py run --data-root data --graph pipeline_vnext/graphs/pipeline_evolution_cycle.json

## 2) dry-run 套用候選（不改檔）
python evolution/apply_candidate.py --data-root data --candidate data/evolution/candidates/<id>.json --dry-run

## 3) 正式套用（會備份目標 json）
python evolution/apply_candidate.py --data-root data --candidate data/evolution/candidates/<id>.json

備份位置：
- data/evolution/applied_backups/

## 4) API 套用（仍走 Gate）
啟動 API：
pip install -r control_plane/requirements.txt
bash control_plane/scripts/run_api.sh

- GET /evolution/candidates
- POST /evolution/apply  {"candidate":"data/evolution/candidates/<id>.json","dry_run":true}

生成時間：2025-12-29T07:50:53.091287+00:00
