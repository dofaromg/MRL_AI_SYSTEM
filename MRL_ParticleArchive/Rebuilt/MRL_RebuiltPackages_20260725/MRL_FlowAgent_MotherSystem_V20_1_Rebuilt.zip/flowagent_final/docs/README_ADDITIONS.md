# Additions in v2_k8s_full

## vendor/flowagent-core-v1.0.0
你上傳的 core zip 已完整內嵌於 vendor 目錄，保持原狀不改動。

## samples/external_chat_export
你上傳的 ExportBlock 已放入 samples 供 ingest 測試用（如需你自己的 export.zip，直接替換此目錄內容即可）。

## Quick ingest sample
```bash
# 進入母體 payload（若你用 fltnz 解包，請改成對應路徑）
python cli/main.py --data-root data ingest_external_chat --zip samples/external_chat_export/<your_export_zip>.zip
```

生成時間：2025-12-29T00:05:53.999235+00:00
