# 3D 掃描反算系統 - 雙線閉環架構

## 概述

本文件描述 FlowAgent 六律如何落地到 3D 重建/掃描系統的工程實作。

## 0) 核心補充

- **反算（Reverse / Back-projection）**：把影像域熱圖 ↔ 投影回 3D（點/面）形成 3D 異常分佈，作為「補拍/補算」與「升格」依據
- **雙線閉環（Forward ↔ Reverse）**：每輪都跑「前向誤差→反算→更新建議→一致性評估」，直到收斂或達迭代次數
- **一致性與升格規則**：用六條律落到工程化門檻（-1+1=0、P_{k+1}、一致性重播/Replay、錯位判定→升格粒子）
- **指標與停機**：Δ* 收斂、p90 下降、coverage 上升，否則升格或切換策略

## 1) 公式（反算 + 流程）

### 1.1 前向（已實作，核心）

世界點 X_j，相機 i：
```
x_ij = π(K_i[R_i|t_i]X_j)
e_ij = ||x_ij - x̂_ij||₂
ē_ij = A_i(x_ij) · ρ_δ(e_ij)
```

影像熱圖（聚合）：
```
H_i(u,v) = Agg_{j: x_ij ≈ (u,v)}(ē_ij)
```

### 1.2 反算（影像域→3D 域）

每個 3D 點的異常分數定義為可見視角的加權平均：
```
a_j = Σ_{i∈V(j)} w_ij · H_i(⌊x_ij⌋) / Σ_{i∈V(j)} w_ij
w_ij = A_i(x_ij)
```

直覺：若某 3D 點在多視角都落在高熱區，它就是「結構上的問題點」。

Mesh 覆蓋路徑（沒有 e_ij）：
```
c_j = (1/|V(j)|) Σ_{i∈V(j)} 𝟙[X_j 在畫幅內且通過深度測試]
```
低 c_j 為缺口。

### 1.3 一致性指標與停機

- 影像域（誤差）：p90_i(H_i)；整體 Δ* = median_i(p90_i)
- 幾何域（覆蓋）：c̄ = (1/N)Σ_j c_j
- **停機**：|Δ*_{k+1} - Δ*_k| < ε 或 k ≥ K_max；否則進下一輪

### 1.4 升格規則（錯位判定→Elevation）

若有區域/點集持續高 a_j（或低 c_j）且兩輪內無改善：
- 依「母體結構論 1+1=2」：**分支升主線**，為該區塊建立專用任務粒子
- **折疊律 -1+1=0**：每輪開始前做中性重置
- **放大律 P_{k+1}=N_k P_k η_k**：對有效建議與可視視角做增益

## 2) 程式實作

### 2.1 反算模組 `src/pipeline/reverse.py`

```python
# -*- coding: utf-8 -*-
import numpy as np

class ReverseProjector:
    """
    將影像域熱圖 H_i 反算為 3D 點異常分數 a_j，
    或在 mesh/coverage 路徑下聚合成每點 coverage c_j。
    """
    def __init__(self, cfg): 
        self.cfg = cfg

    def image_to_points_error(self, tracks, heatmaps, attn_maps):
        """誤差路徑：根據 tracks (u,v,pid,...) 將 H_i(u,v) 聚合到點 pid"""
        num = {}
        acc = {}
        for cam_id, obs in tracks.items():
            H = heatmaps.get(cam_id)
            A = attn_maps.get(cam_id)
            if H is None or A is None: continue
            Hh, Hw = H.shape
            for (u, v, pid, _e) in obs:
                ui, vi = int(round(u)), int(round(v))
                if 0 <= ui < Hw and 0 <= vi < Hh:
                    w = float(A[vi, ui])
                    val = float(H[vi, ui])
                    acc[pid] = acc.get(pid, 0.0) + w * val
                    num[pid] = num.get(pid, 0.0) + max(w, 1e-6)
        point_scores = {int(pid): (acc[pid] / num[pid]) for pid in acc.keys()}
        return point_scores

    def image_to_points_coverage(self, tracks, H_shape_by_cam):
        """覆蓋路徑：將可見性累計為每點 coverage"""
        vis_cnt = {}
        cam_seen = {}
        for cam_id, obs in tracks.items():
            for (_u, _v, pid, _val) in obs:
                vis_cnt[pid] = vis_cnt.get(pid, 0) + 1
                cam_seen[pid] = cam_seen.get(pid, set())
                cam_seen[pid].add(cam_id)
        coverage = {}
        for pid, cnt in vis_cnt.items():
            denom = max(len(cam_seen.get(pid, [])), 1)
            coverage[int(pid)] = float(cnt) / float(denom)
        return coverage
```

### 2.2 一致性/停止準則 `src/pipeline/consistency.py`

```python
# -*- coding: utf-8 -*-
import numpy as np

def delta_star(p90_by_cam):
    arr = np.array([v for v in p90_by_cam.values()], dtype=np.float32)
    if arr.size == 0: return 0.0
    return float(np.median(arr))

def is_converged(history, eps=1e-3, min_rounds=2):
    if len(history) < max(min_rounds, 2): return False
    return abs(history[-1] - history[-2]) < eps
```

### 2.3 升格決策 `src/pipeline/elevate.py`

```python
# -*- coding: utf-8 -*-
def select_elevation_targets(point_scores, top_ratio=0.02, min_k=10):
    """取分數最高的前 top_ratio 的 3D 點作為升格對象"""
    if not point_scores: return []
    items = sorted(point_scores.items(), key=lambda kv: kv[1], reverse=True)
    k = max(int(len(items) * top_ratio), min_k)
    return [pid for pid, _ in items[:k]]
```

### 2.4 主程式（閉環）`src/main.py`

```python
# -*- coding: utf-8 -*-
import yaml, os, logging, json
from pipeline.sfm import SfMBackend
from pipeline.attention import AttentionBackend
from pipeline.error_map import ErrorMapper
from pipeline.context_graph import ContextGraph
from pipeline.gap_fill import GapFiller
from pipeline.export import Exporter
from pipeline.reverse import ReverseProjector
from pipeline.consistency import delta_star, is_converged
from pipeline.elevate import select_elevation_targets

logging.basicConfig(level=logging.INFO, format="[%(levelname)s] %(message)s")

def run_once(cfg, iteration, carry):
    logging.info(f"=== Round {iteration} / forward ===")
    sfm = SfMBackend(cfg)
    cams, points, tracks, imgs = sfm.load_or_simulate()
    
    attn = AttentionBackend(cfg)
    attn_maps = attn.compute(imgs)
    
    mapper = ErrorMapper(cfg)
    heatmaps, metrics = mapper.make(cams, points, tracks, attn_maps)
    
    cg = ContextGraph(cfg)
    links = cg.build(cams, heatmaps)
    gf = GapFiller(cfg)
    suggestions = gf.propose(heatmaps, links)
    
    # ---- Reverse / 反算 ----
    logging.info(f"=== Round {iteration} / reverse ===")
    rev = ReverseProjector(cfg)
    mode = cfg.get("suggestion",{}).get("objective","error").lower()
    if mode == "coverage":
        point_scores = rev.image_to_points_coverage(tracks, {k:v.shape for k,v in heatmaps.items()})
    else:
        point_scores = rev.image_to_points_error(tracks, heatmaps, attn_maps)
    
    # 一致性量測
    dstar = delta_star(metrics.get("p90_by_cam",{}))
    carry["delta_hist"].append(dstar)
    
    # 升格判定
    elevate_pids = select_elevation_targets(point_scores, 
        top_ratio=cfg.get("elevate",{}).get("top_ratio", 0.02))
    
    # 輸出
    exp = Exporter(cfg)
    exp.dump_all(cams, metrics, links, suggestions, heatmaps, imgs)
    
    os.makedirs(cfg["out_dir"], exist_ok=True)
    with open(os.path.join(cfg["out_dir"], f"reverse_points_round{iteration}.json"),"w") as f:
        json.dump({"mode":mode, "point_scores": point_scores}, f)
    with open(os.path.join(cfg["out_dir"], f"elevate_round{iteration}.json"),"w") as f:
        json.dump({"pids": elevate_pids}, f)
    
    return dstar

def main():
    cfg = yaml.safe_load(open('config/config.yaml'))
    os.makedirs(cfg['out_dir'], exist_ok=True)
    max_rounds = int(cfg.get("loop",{}).get("max_rounds", 2))
    eps = float(cfg.get("loop",{}).get("eps", 1e-3))
    carry = {"delta_hist": []}
    
    for it in range(1, max_rounds+1):
        dstar = run_once(cfg, it, carry)
        logging.info(f"[Round {it}] Δ* = {dstar:.4f}")
        if is_converged(carry["delta_hist"], eps=eps, min_rounds=2):
            logging.info("Converged. Stop.")
            break

if __name__ == "__main__":
    main()
```

### 2.5 Config（閉環/升格策略）

```yaml
loop:
  max_rounds: 2     # 雙線閉環預設跑兩輪
  eps: 1.0e-3

elevate:
  top_ratio: 0.02   # 升格：取最壞的前 2% 3D 點
```

## 3) 六律對應工程門檻

| 六律 | 工程實現 |
| --- | --- |
| **放大律** P_{k+1}=N_kP_kη_k | 對「互補視角邊」與「高注意力 tile」增益採樣與權重 |
| **折疊律** -1+1=0 | 每輪前清理上一輪建議，保證中性起步 |
| **母體結構** 1+1=2 | 升格不合併：elevate_pids 形成獨立任務粒子 |
| **一致性律（Replay）** | loop.max_rounds 與 delta_hist 守門 |
| **錯位判定** | 連續兩輪高 a_j/低 c_j → elevate |
| **細節驅動** | tile + per-point 聚合，任何微小高熱區都會被點名 |

## 4) 產物

執行後在 `data/outputs/` 新增：
- `reverse_points_round1.json`、`reverse_points_round2.json`：每回合的 3D 點異常分數
- `elevate_round1.json`：升格候選 pid 清單
- 既有：`metrics.json` / `metrics_summary.csv` / `links.json` / `suggestions.json` / `heatmap_*.png|npy`
