#!/usr/bin/env python3
import argparse, os, json
from collections import defaultdict
from datetime import datetime, timezone

def utc():
    return datetime.now(timezone.utc).isoformat()

def read_jsonl(path):
    if not os.path.exists(path): return []
    out=[]
    with open(path,"r",encoding="utf-8") as f:
        for line in f:
            line=line.strip()
            if not line: 
                continue
            try: out.append(json.loads(line))
            except Exception: continue
    return out

def list_run_receipts(runs_dir):
    if not os.path.isdir(runs_dir): return []
    out=[]
    for fn in os.listdir(runs_dir):
        if fn.endswith(".json"):
            p=os.path.join(runs_dir, fn)
            try:
                out.append(json.loads(open(p,"r",encoding="utf-8").read()))
            except Exception:
                continue
    return out

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--data-root", default="data")
    args=ap.parse_args()
    dr=args.data_root

    trace=read_jsonl(os.path.join(dr,"trace","trace.jsonl"))
    proof=read_jsonl(os.path.join(dr,"proof","chain.jsonl"))
    receipts=list_run_receipts(os.path.join(dr,"runs"))

    by_rid=defaultdict(lambda: {"events":0,"fails":0})
    for t in trace:
        rid=t.get("rid","")
        if not rid: continue
        by_rid[rid]["events"] += 1
        subj=t.get("subject") or {}
        if subj.get("ok") is False or subj.get("denied") is True:
            by_rid[rid]["fails"] += 1

    coh=[]
    for p in proof:
        c=p.get("coherence_score")
        if isinstance(c,(int,float)):
            coh.append(float(c))

    redirects=0
    for r in receipts:
        if r.get("redirected") is True:
            redirects += 1

    os.makedirs(os.path.join(dr,"telemetry"), exist_ok=True)
    events_path=os.path.join(dr,"telemetry","events.jsonl")
    with open(events_path,"a",encoding="utf-8") as f:
        for rid, m in by_rid.items():
            rec={"rid":rid,"events":m["events"],"fails":m["fails"],"timestamp":utc()}
            f.write(json.dumps(rec, ensure_ascii=False)+"\n")

    total_runs=len(by_rid) if by_rid else 0
    total_events=sum(m["events"] for m in by_rid.values()) if by_rid else 0
    total_fails=sum(m["fails"] for m in by_rid.values()) if by_rid else 0
    agg={
        "total_runs": total_runs,
        "total_events": total_events,
        "total_fails": total_fails,
        "fail_rate": (total_fails/total_events) if total_events else 0.0,
        "redirect_rate": (redirects/len(receipts)) if receipts else 0.0,
        "mean_coherence": (sum(coh)/len(coh)) if coh else None,
        "updated_at": utc()
    }
    with open(os.path.join(dr,"telemetry","aggregates.json"),"w",encoding="utf-8") as f:
        json.dump(agg,f,ensure_ascii=False,indent=2)

    print(json.dumps({"ok":True,"aggregates":agg,"events_path":events_path,"receipts":len(receipts)}, ensure_ascii=False, indent=2))

if __name__=="__main__":
    main()
