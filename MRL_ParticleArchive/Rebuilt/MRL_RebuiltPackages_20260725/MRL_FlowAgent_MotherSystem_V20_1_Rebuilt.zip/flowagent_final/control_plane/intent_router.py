#!/usr/bin/env python3
import argparse, json, os, hashlib
from datetime import datetime, timezone
from pipeline_vnext.orchestrator import run_graph

def utc():
    return datetime.now(timezone.utc).isoformat()

def sha256_text(s: str) -> str:
    return hashlib.sha256(s.encode("utf-8")).hexdigest()

def load_json(path: str) -> dict:
    with open(path,"r",encoding="utf-8") as f:
        return json.load(f)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--data-root", default="data")
    ap.add_argument("--intent", required=True)
    ap.add_argument("--persona-id", default="ANALYST_BG")
    args=ap.parse_args()

    intent_obj=load_json(args.intent)
    intent=intent_obj.get("intent") or ""
    schema_path=os.path.join("control_plane","intent_schema",f"{intent}.json")
    if not os.path.exists(schema_path):
        raise FileNotFoundError(f"intent_schema_not_found:{schema_path}")
    schema=load_json(schema_path)
    graph=schema.get("maps_to",{}).get("graph")
    if not graph:
        raise RuntimeError("schema_missing_graph")

    # Override example: localfs root
    if intent=="sync_localfs" and intent_obj.get("root"):
        g=load_json(graph)
        root=intent_obj["root"]
        for n in g.get("nodes",[]):
            if n.get("id")=="bridge_localfs" and "cmd" in n:
                n["cmd"]=f"python cli/main.py --data-root data bridge_localfs --root {root}"
        tmp=os.path.join("pipeline_vnext","graphs","_tmp","intent_sync_localfs.json")
        os.makedirs(os.path.dirname(tmp), exist_ok=True)
        with open(tmp,"w",encoding="utf-8") as f:
            json.dump(g,f,ensure_ascii=False,indent=2)
        graph=tmp

    res=run_graph(args.data_root, graph, persona_id=args.persona_id)

    os.makedirs(os.path.join(args.data_root,"intent"), exist_ok=True)
    iid=sha256_text(json.dumps(intent_obj,ensure_ascii=False)+res.get("rid","")+utc())[:16]
    receipt={"intent_id":iid,"rid":res.get("rid",""),"intent":intent_obj,"result":res,"timestamp":utc()}
    receipt_path=os.path.join(args.data_root,"intent",f"{iid}.json")
    with open(receipt_path,"w",encoding="utf-8") as f:
        json.dump(receipt,f,ensure_ascii=False,indent=2)
    res["intent_receipt"]=receipt_path
    print(json.dumps(res,ensure_ascii=False,indent=2))

if __name__=="__main__":
    main()
