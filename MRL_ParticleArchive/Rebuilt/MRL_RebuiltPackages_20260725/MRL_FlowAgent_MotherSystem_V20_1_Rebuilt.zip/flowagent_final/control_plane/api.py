from fastapi import FastAPI
from pydantic import BaseModel
import os, json
from pipeline_vnext.orchestrator import run_graph

app = FastAPI(title="FlowAgent ControlPlane", version="selfgrow_v1")

class IntentReq(BaseModel):
    intent: str
    payload: dict = {}
    persona_id: str = "ANALYST_BG"

@app.get("/health")
def health():
    return {"ok": True}

@app.get("/state")
def state():
    data_root = os.environ.get("FLOWAGENT_DATA_ROOT", "data")
    out = {"data_root": data_root}
    idx = os.path.join(data_root, "index", "conversations.json")
    out["has_index"] = os.path.exists(idx)
    audit = os.path.join(data_root, "audit", "latest.json")
    if os.path.exists(audit):
        out["latest_audit"] = json.loads(open(audit,"r",encoding="utf-8").read())
    return out

@app.post("/intent")
def intent(req: IntentReq):
    data_root = os.environ.get("FLOWAGENT_DATA_ROOT", "data")
    schema_path = os.path.join("control_plane","intent_schema", f"{req.intent}.json")
    if not os.path.exists(schema_path):
        return {"ok": False, "error": "intent_schema_not_found"}
    schema = json.loads(open(schema_path,"r",encoding="utf-8").read())
    graph = schema.get("maps_to", {}).get("graph")
    if not graph:
        return {"ok": False, "error": "schema_missing_graph"}
    res = run_graph(data_root, graph, persona_id=req.persona_id)
    res["ok"] = True
    return res


@app.get("/metrics")
def metrics():
    data_root = os.environ.get("FLOWAGENT_DATA_ROOT", "data")
    agg = os.path.join(data_root, "telemetry", "aggregates.json")
    if os.path.exists(agg):
        return {"ok": True, "aggregates": json.loads(open(agg,"r",encoding="utf-8").read())}
    return {"ok": False, "error": "missing_aggregates"}

@app.get("/evolution/candidates")
def list_candidates():
    data_root = os.environ.get("FLOWAGENT_DATA_ROOT", "data")
    cdir = os.path.join(data_root, "evolution", "candidates")
    out=[]
    if os.path.isdir(cdir):
        for fn in sorted(os.listdir(cdir)):
            if fn.endswith(".json"):
                out.append(fn)
    return {"ok": True, "candidates": out}

class ApplyReq(BaseModel):
    candidate: str
    dry_run: bool = True
    persona_id: str = "ANALYST_BG"

@app.post("/evolution/apply")
def evolution_apply(req: ApplyReq):
    data_root = os.environ.get("FLOWAGENT_DATA_ROOT", "data")
    # run apply via pipeline runner (Gate-protected)
    g = {
        "graph_id": "api_apply_candidate",
        "nodes": [{"id":"runner_apply_patch","kind":"runner","name":"apply_patch","kwargs":{"candidate": req.candidate, "dry_run": req.dry_run}}],
        "policy": {"on_fail":"abort", "default_redirect_runner":"repair"}
    }
    os.makedirs(os.path.join("pipeline_vnext","graphs","_tmp"), exist_ok=True)
    tmp = os.path.join("pipeline_vnext","graphs","_tmp","api_apply_candidate.json")
    with open(tmp,"w",encoding="utf-8") as f:
        json.dump(g,f,ensure_ascii=False,indent=2)
    res = run_graph(data_root, tmp, persona_id=req.persona_id)
    res["ok"] = True
    return res


class TxnReq(BaseModel):
    candidate: str
    commit: bool = False
    persona_id: str = "ANALYST_BG"

@app.post("/evolution/transaction")
def evolution_transaction(req: TxnReq):
    data_root = os.environ.get("FLOWAGENT_DATA_ROOT", "data")
    g = {
        "graph_id": "api_apply_txn",
        "nodes": [{"id":"runner_apply_txn","kind":"runner","name":"apply_txn","kwargs":{"candidate": req.candidate, "commit": req.commit}}],
        "policy": {"on_fail":"abort", "default_redirect_runner":"repair"}
    }
    os.makedirs(os.path.join("pipeline_vnext","graphs","_tmp"), exist_ok=True)
    tmp = os.path.join("pipeline_vnext","graphs","_tmp","api_apply_txn.json")
    with open(tmp,"w",encoding="utf-8") as f:
        json.dump(g,f,ensure_ascii=False,indent=2)
    res = run_graph(data_root, tmp, persona_id=req.persona_id)
    res["ok"] = True
    return res


@app.get("/evaluation/latest")
def evaluation_latest():
    data_root = os.environ.get("FLOWAGENT_DATA_ROOT", "data")
    p = os.path.join(data_root, "evaluation", "latest.json")
    if os.path.exists(p):
        return {"ok": True, "evaluation": json.loads(open(p,"r",encoding="utf-8").read())}
    return {"ok": False, "error": "missing_latest_evaluation"}

@app.get("/evolution/ledger")
def evolution_ledger(limit: int = 50):
    data_root = os.environ.get("FLOWAGENT_DATA_ROOT", "data")
    lp = os.path.join(data_root, "evolution", "ledger.jsonl")
    if not os.path.exists(lp):
        return {"ok": True, "items": []}
    items=[]
    with open(lp,"r",encoding="utf-8") as f:
        for line in f:
            line=line.strip()
            if not line:
                continue
            try:
                items.append(json.loads(line))
            except Exception:
                continue
    items = items[-limit:]
    return {"ok": True, "items": items}
