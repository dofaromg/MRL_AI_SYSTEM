#!/bin/bash
set -e
export FLOWAGENT_DATA_ROOT=${FLOWAGENT_DATA_ROOT:-data}
uvicorn control_plane.api:app --host 0.0.0.0 --port ${PORT:-8766}
