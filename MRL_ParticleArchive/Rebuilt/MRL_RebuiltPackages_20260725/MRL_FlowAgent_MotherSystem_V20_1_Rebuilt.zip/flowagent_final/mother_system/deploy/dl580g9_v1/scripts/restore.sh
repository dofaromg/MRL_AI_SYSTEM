#!/bin/bash
echo 'restore is manual in v1 (copy data/snapshots/<id> back)'
