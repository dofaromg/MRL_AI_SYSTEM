#!/bin/bash
set -e
python cli/main.py --data-root data proof_verify
