#!/bin/bash
set -e
python cli/main.py --data-root data snapshot_create
