# 可跑的最小 stub：不做網路請求（避免 token/速率/條款問題）
# 要接 GitHub API：替換 pull_repo/pull_object 內部實作。
from typing import Dict, Any, List

def pull_repo(repo: str) -> List[Dict[str, Any]]:
    raise RuntimeError("GitHub bridge 未啟用：請提供 GITHUB_TOKEN 並實作 API 呼叫（本母體交付先保持安全離線）")
