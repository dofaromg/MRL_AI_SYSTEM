import os, json
from typing import Dict, Any, List
from ..core.util import sha256_file, utc_now_iso

def scan(root: str, exts: List[str] | None = None, max_bytes: int = 2_000_000) -> List[Dict[str, Any]]:
    exts = [e.lower() for e in (exts or [])]
    out = []
    for dp, _, fns in os.walk(root):
        for fn in fns:
            p = os.path.join(dp, fn)
            try:
                st = os.stat(p)
            except OSError:
                continue
            if st.st_size > max_bytes:
                continue
            ext = os.path.splitext(fn)[1].lower()
            if exts and ext not in exts:
                continue
            kind = "text" if ext in (".md",".txt",".json",".py",".js",".ts",".yml",".yaml",".toml",".ini") else "binary"
            out.append({
                "source": "local_fs",
                "path": os.path.abspath(p),
                "size": int(st.st_size),
                "mtime": utc_now_iso(),
                "sha256": sha256_file(p),
                "kind": kind,
                "chunk_policy": "by_lines" if kind == "text" else "none"
            })
    return out

def load_prev_index(index_path: str) -> Dict[str, Any]:
    if not os.path.exists(index_path):
        return {}
    return json.loads(open(index_path, "r", encoding="utf-8").read())

def save_index(index_path: str, idx: Dict[str, Any]):
    os.makedirs(os.path.dirname(index_path), exist_ok=True)
    with open(index_path, "w", encoding="utf-8") as f:
        f.write(json.dumps(idx, ensure_ascii=False, indent=2))

def diff(prev: Dict[str, Any], current_list: List[Dict[str, Any]]) -> Dict[str, List[Dict[str, Any]]]:
    curr = {it["path"]: it for it in current_list}
    prev_map = prev.get("files") or {}
    added, changed = [], []
    for p, it in curr.items():
        old = prev_map.get(p)
        if not old:
            added.append(it)
        elif old.get("sha256") != it.get("sha256"):
            changed.append(it)
    return {"added": added, "changed": changed}

def materialize_prev_format(current_list: List[Dict[str, Any]]) -> Dict[str, Any]:
    return {"files": {it["path"]: it for it in current_list}, "updated_at": utc_now_iso()}
