import os, json, re
from typing import Dict, Any, List, Tuple
from ..core.util import sha256_text
from ..memory.index import index_state_hash

def _load_jsonl(path: str) -> List[Dict[str, Any]]:
    if not os.path.exists(path):
        return []
    out = []
    with open(path, "r", encoding="utf-8") as f:
        for ln in f:
            ln = ln.strip()
            if not ln:
                continue
            out.append(json.loads(ln))
    return out

def keyword_query(data_root: str, text: str, top_k: int = 10) -> Dict[str, Any]:
    # 搜 chunks.jsonl 的 text
    chunks_path = os.path.join(data_root, "memory", "chunks.jsonl")
    chunks = _load_jsonl(chunks_path)
    q = text.strip()
    if not q:
        return {"query_id": sha256_text("empty")[:16], "text": text, "hits": [], "index_state_hash": index_state_hash(data_root)}
    tokens = [t for t in re.split(r"\s+", q) if t]
    hits = []
    for ch in chunks:
        hay = (ch.get("text") or "")
        score = 0
        for t in tokens:
            score += hay.count(t)
        if score > 0:
            hits.append({
                "conversation_id": ch.get("conversation_id",""),
                "chunk_id": ch.get("chunk_id"),
                "score": float(score),
                "snippet": hay[:240],
                "proof_chain": ch.get("proof_chain", [])
            })
    hits.sort(key=lambda x: x["score"], reverse=True)
    return {
        "query_id": sha256_text(q)[:16],
        "text": text,
        "hits": hits[:top_k],
        "index_state_hash": index_state_hash(data_root)
    }
