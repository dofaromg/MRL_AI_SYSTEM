import os, json
from typing import Dict, Any, List
from ..core.util import atomic_write, sha256_text

def index_path(data_root: str) -> str:
    return os.path.join(data_root, "index", "conversations.json")

def load_index(data_root: str) -> List[Dict[str, Any]]:
    p = index_path(data_root)
    if not os.path.exists(p):
        return []
    return json.loads(open(p, "r", encoding="utf-8").read())

def save_index(data_root: str, idx: List[Dict[str, Any]]):
    p = index_path(data_root)
    atomic_write(p, json.dumps(idx, ensure_ascii=False, indent=2))

def index_state_hash(data_root: str) -> str:
    idx = load_index(data_root)
    return sha256_text(json.dumps(idx, ensure_ascii=False))
