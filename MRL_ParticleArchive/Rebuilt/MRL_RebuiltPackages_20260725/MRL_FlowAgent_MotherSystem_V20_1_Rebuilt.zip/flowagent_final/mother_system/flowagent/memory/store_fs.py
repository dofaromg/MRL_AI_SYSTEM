import os, json
from typing import Dict, Any
from ..core.util import atomic_write, utc_now_iso

def append_jsonl(path: str, obj: Dict[str, Any]):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(obj, ensure_ascii=False) + "\n")

class FSStore:
    def __init__(self, data_root: str):
        self.data_root = data_root
        os.makedirs(os.path.join(self.data_root, "memory"), exist_ok=True)

    def write_particle(self, particle: Dict[str, Any]):
        path = os.path.join(self.data_root, "memory", "particles.jsonl")
        append_jsonl(path, particle)

    def write_chunk(self, chunk: Dict[str, Any]):
        path = os.path.join(self.data_root, "memory", "chunks.jsonl")
        append_jsonl(path, chunk)
