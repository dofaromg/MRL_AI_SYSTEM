import os, json
from typing import Dict, Any, Optional
from .util import utc_now_iso, sha256_text, atomic_write

def _append_jsonl(path: str, obj: Dict[str, Any]):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(obj, ensure_ascii=False) + "\n")

def write_proof(data_root: str, record: Dict[str, Any]) -> str:
    chain_path = os.path.join(data_root, "proof", "chain.jsonl")
    proof_id = record.get("proof_id") or sha256_text(json.dumps(record, ensure_ascii=False) + utc_now_iso())[:32]
    record["proof_id"] = proof_id
    record.setdefault("timestamp", utc_now_iso())
    _append_jsonl(chain_path, record)
    return proof_id

def latest_proof(data_root: str) -> Optional[Dict[str, Any]]:
    chain_path = os.path.join(data_root, "proof", "chain.jsonl")
    if not os.path.exists(chain_path):
        return None
    with open(chain_path, "r", encoding="utf-8") as f:
        lines = [ln for ln in f.read().splitlines() if ln.strip()]
    if not lines:
        return None
    return json.loads(lines[-1])

def verify_latest(data_root: str) -> bool:
    # 最小驗證：chain 存在且最後一筆具 proof_id
    lp = latest_proof(data_root)
    return bool(lp and lp.get("proof_id"))
