from typing import Dict, Any
import math

def coherence_score(meta: Dict[str, Any]) -> float:
    # 最小：若有 proof/ hash / index_state 這些欄位越齊全，分數越高
    keys = ["before_hash", "after_hash", "index_state_hash", "law_applied"]
    hit = sum(1 for k in keys if meta.get(k))
    return min(1.0, 0.6 + 0.1 * hit)

def entropy_delta(before_size: int, after_size: int) -> float:
    if before_size <= 0:
        return 0.0
    return (after_size - before_size) / float(before_size)
