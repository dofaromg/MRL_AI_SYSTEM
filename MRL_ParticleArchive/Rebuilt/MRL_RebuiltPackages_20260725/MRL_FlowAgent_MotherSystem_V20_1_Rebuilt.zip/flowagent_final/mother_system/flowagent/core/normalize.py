from typing import Dict, Any
from .util import sha256_text

def normalize_doc(source: str, primary_id: str, title: str, body: str, meta: Dict[str, Any] | None = None):
    meta = meta or {}
    doc = {
        "doc_id": sha256_text(source + ":" + primary_id)[:32],
        "source": source,
        "primary_id": primary_id,
        "title": title or "",
        "body": body or "",
        "meta": meta,
        "anchors": []
    }
    return doc
