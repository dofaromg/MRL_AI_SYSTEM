import os, json, shutil
from typing import Dict, Any, Optional
from .util import utc_now_iso, sha256_text, sha256_file, atomic_write

def _dir_hash(root: str) -> str:
    # 穩定 hash：遍歷檔案路徑+內容hash
    items = []
    for dp, _, fns in os.walk(root):
        for fn in sorted(fns):
            p = os.path.join(dp, fn)
            rel = os.path.relpath(p, root)
            items.append(rel + ":" + sha256_file(p))
    return sha256_text("\n".join(items))

def create_snapshot(data_root: str) -> Dict[str, Any]:
    snap_id = sha256_text(utc_now_iso())[:16]
    snap_dir = os.path.join(data_root, "snapshots", snap_id)
    os.makedirs(snap_dir, exist_ok=True)

    includes = ["memory", "index", "proof"]
    for name in includes:
        src = os.path.join(data_root, name)
        dst = os.path.join(snap_dir, name)
        if os.path.exists(dst):
            shutil.rmtree(dst)
        if os.path.exists(src):
            shutil.copytree(src, dst)

    state_hash = _dir_hash(snap_dir)
    meta = {
        "snapshot_id": snap_id,
        "includes": includes,
        "state_hash": state_hash,
        "created_at": utc_now_iso(),
        "verify": "unknown"
    }
    atomic_write(os.path.join(snap_dir, "snapshot.json"), json.dumps(meta, ensure_ascii=False, indent=2))
    return meta

def verify_snapshot(data_root: str, snapshot_id: str) -> bool:
    snap_dir = os.path.join(data_root, "snapshots", snapshot_id)
    meta_path = os.path.join(snap_dir, "snapshot.json")
    if not os.path.exists(meta_path):
        return False
    meta = json.loads(open(meta_path, "r", encoding="utf-8").read())
    expect = meta.get("state_hash")
    actual = _dir_hash(snap_dir)
    ok = (expect == actual)
    meta["verify"] = "pass" if ok else "fail"
    atomic_write(meta_path, json.dumps(meta, ensure_ascii=False, indent=2))
    return ok
