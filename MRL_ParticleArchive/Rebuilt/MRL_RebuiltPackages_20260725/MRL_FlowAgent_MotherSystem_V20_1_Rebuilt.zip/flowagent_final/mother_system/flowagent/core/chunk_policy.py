from typing import List, Dict, Any
from .util import sha256_text

DEFAULT_POLICY = {
    "policy_id": "default_v1",
    "rules": [
        {"kind": "chat", "by": "message_turn", "max_chars": 2000},
        {"kind": "code", "by": "paragraph", "max_chars": 2400},
        {"kind": "text", "by": "paragraph", "max_chars": 1800},
    ]
}

def chunk_paragraphs(text: str, max_chars: int) -> List[str]:
    paras = [p.strip() for p in text.replace("\r\n", "\n").split("\n\n") if p.strip()]
    out, buf = [], ""
    for p in paras:
        if len(buf) + len(p) + 2 <= max_chars:
            buf = (buf + "\n\n" + p).strip()
        else:
            if buf:
                out.append(buf)
            buf = p
    if buf:
        out.append(buf)
    return out or ([""] if text else [])

def make_chunks(doc: Dict[str, Any], kind: str = "text") -> List[Dict[str, Any]]:
    rule = next((r for r in DEFAULT_POLICY["rules"] if r["kind"] == kind), DEFAULT_POLICY["rules"][-1])
    max_chars = int(rule["max_chars"])
    blocks = chunk_paragraphs(doc["body"], max_chars=max_chars)
    chunks = []
    for i, blk in enumerate(blocks):
        cid = sha256_text(doc["doc_id"] + f":{i}:{sha256_text(blk)}")[:32]
        chunks.append({
            "chunk_id": cid,
            "doc_id": doc["doc_id"],
            "seq": i,
            "text": blk,
            "content_hash": sha256_text(blk),
        })
    return chunks
