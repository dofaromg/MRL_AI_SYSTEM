from typing import Dict, Any
from .util import sha256_text

def compress_chunk(chunk: Dict[str, Any], method: str = "plain") -> Dict[str, Any]:
    # 最小可逆：payload 保存原文（你要的可回放）
    payload = {
        "method": method,
        "text": chunk["text"],
        "len": len(chunk["text"])
    }
    pid = sha256_text(chunk["chunk_id"] + ":" + chunk["content_hash"])[:32]
    return {
        "particle_id": pid,
        "from_chunk_id": chunk["chunk_id"],
        "compression": method,
        "payload": payload,
        "content_hash": chunk["content_hash"],
        "proof_chain": []
    }
