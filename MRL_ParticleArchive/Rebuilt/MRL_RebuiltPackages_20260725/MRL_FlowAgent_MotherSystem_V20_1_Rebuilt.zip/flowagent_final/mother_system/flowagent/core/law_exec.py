from dataclasses import dataclass
from typing import Dict, Any, List

class LawViolation(Exception):
    pass

@dataclass(frozen=True)
class LawDecision:
    allow: bool
    reason: str
    redirect_layer: str = ""

class LawEngine:
    """最小可執行 Law：阻擋外部 ingest 直寫 persona、阻擋無 trace 的刪除。"""
    def __init__(self):
        self.root_laws = [
            ("persona_external_write_deny", 0),
            ("delete_without_trace_deny", 1),
        ]

    def arbitrate(self, event: Dict[str, Any]) -> LawDecision:
        src = event.get("source", "")
        target = event.get("target_layer", "")
        action = event.get("action", "")
        # Persona Safety Gate (L38 hard)
        if target == "persona" and src not in ("internal",):
            return LawDecision(False, "external_ingest_blocked")
        # No delete without trace
        if action == "delete" and not event.get("trace_id"):
            return LawDecision(False, "delete_without_trace")
        return LawDecision(True, "ok")
