# FlowAgent Mother System v1 (MrLiou)

這個交付把「你說的補上、拿掉虛擬世界的虛擬世界」直接落地成**同一個可跑母體**：
- 不是 patch 口頭規約
- 是真實模組：normalize / chunk / compress / local_fs bridge / query contract / proof / snapshot / deploy pack

## Quick Run
```bash
python cli/main.py --data-root data proof_verify
```

## ExternalChat Export Ingest
```bash
python cli/main.py --data-root data ingest_external_chat --zip data/imports/external-chat-export.zip
```

## LocalFS Bridge
```bash
python cli/main.py --data-root data bridge_localfs --root /path/to/dir
```

## Query
```bash
python cli/main.py --data-root data query --text "關鍵字"
```
