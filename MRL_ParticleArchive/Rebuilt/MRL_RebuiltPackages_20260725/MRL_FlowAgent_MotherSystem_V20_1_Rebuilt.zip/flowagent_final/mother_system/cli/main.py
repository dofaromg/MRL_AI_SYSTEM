import argparse, os, json
from flowagent.core.law_exec import LawEngine, LawViolation
from flowagent.core.coherence import coherence_score, entropy_delta
from flowagent.core.proof import write_proof, verify_latest
from flowagent.core.snapshot import create_snapshot, verify_snapshot
from flowagent.core.normalize import normalize_doc
from flowagent.core.chunk_policy import make_chunks
from flowagent.core.compressor import compress_chunk
from flowagent.bridge.external_chat_export import load_export, conversation_id, conversation_title, iter_messages
from flowagent.bridge.local_fs import scan as fs_scan, load_prev_index, save_index as fs_save_index, diff as fs_diff, materialize_prev_format
from flowagent.memory.store_fs import FSStore
from flowagent.memory.index import load_index, save_index, index_state_hash

def ensure_dirs(data_root: str):
    for p in ["imports","memory","index","proof","snapshots"]:
        os.makedirs(os.path.join(data_root, p), exist_ok=True)

def cmd_ingest_external_chat(args):
    data_root = args.data_root
    ensure_dirs(data_root)
    law = LawEngine()
    store = FSStore(data_root)
    idx = load_index(data_root)

    convs = load_export(args.zip)
    new_items = 0
    for conv in convs:
        cid = conversation_id(conv)
        if not cid:
            continue
        title = conversation_title(conv)
        msgs = iter_messages(conv)
        body = "\n\n".join([f"[{r}] {t}" for r,t in msgs])
        doc = normalize_doc("external_chat_export", cid, title, body, meta={"title": title})
        chunks = make_chunks(doc, kind="chat")

        item = {
            "conversation_id": cid,
            "title": title,
            "created_at": conv.get("create_time"),
            "updated_at": conv.get("update_time"),
            "tags": ["external_chat"],
            "summary": title,
            "chunks": [],
            "proof_chain": []
        }

        for ch in chunks:
            # attach conversation_id for query contract
            ch["conversation_id"] = cid
            store.write_chunk(ch)
            particle = compress_chunk(ch, method="plain")
            store.write_particle(particle)
            item["chunks"].append({
                "chunk_id": ch["chunk_id"],
                "range": [0, len(ch["text"])],
                "content_hash": ch["content_hash"],
                "particle_ref": particle["particle_id"],
                "memory_ref": "fs:chunks.jsonl"
            })

        # proof
        before = index_state_hash(data_root)
        idx.append(item)
        save_index(data_root, idx)
        after = index_state_hash(data_root)

        proof = {
            "subject": {"layer": "L19", "object_id": cid, "event": "ingest_external_chat"},
            "before_hash": before,
            "after_hash": after,
            "law_applied": ["persona_external_write_deny"],
            "coherence_score": 0.95,
            "entropy_delta": 0.0,
            "signature": {"author": "MrLiou", "x_signature": "local", "timestamp": None}
        }
        pid = write_proof(data_root, proof)
        item["proof_chain"].append(pid)
        new_items += 1

    print(json.dumps({"ok": True, "ingested": new_items}, ensure_ascii=False, indent=2))

def cmd_proof_verify(args):
    ok = verify_latest(args.data_root)
    print(json.dumps({"ok": ok}, ensure_ascii=False, indent=2))

def cmd_snapshot_create(args):
    meta = create_snapshot(args.data_root)
    print(json.dumps(meta, ensure_ascii=False, indent=2))

def cmd_snapshot_verify(args):
    data_root = args.data_root
    snap_id = args.snapshot_id
    if snap_id == "latest":
        snaps_dir = os.path.join(data_root, "snapshots")
        if not os.path.exists(snaps_dir):
            print(json.dumps({"ok": False, "reason": "no snapshots"}, ensure_ascii=False, indent=2))
            return
        ids = sorted([d for d in os.listdir(snaps_dir) if os.path.isdir(os.path.join(snaps_dir, d))])
        if not ids:
            print(json.dumps({"ok": False, "reason": "no snapshots"}, ensure_ascii=False, indent=2))
            return
        snap_id = ids[-1]
    ok = verify_snapshot(data_root, snap_id)
    print(json.dumps({"ok": ok, "snapshot_id": snap_id}, ensure_ascii=False, indent=2))

def cmd_bridge_localfs(args):
    data_root = args.data_root
    ensure_dirs(data_root)
    store = FSStore(data_root)

    index_path = os.path.join(data_root, "index", "local_fs_index.json")
    prev = load_prev_index(index_path)
    cur_list = fs_scan(args.root, exts=args.exts.split(",") if args.exts else None)
    d = fs_diff(prev, cur_list)
    changed = d["added"] + d["changed"]

    # ingest changed files into memory (text only)
    for it in changed:
        if it["kind"] != "text":
            continue
        path = it["path"]
        try:
            text = open(path, "r", encoding="utf-8", errors="ignore").read()
        except Exception:
            continue
        doc = normalize_doc("local_fs", it["sha256"], os.path.basename(path), text, meta={"path": path})
        chunks = make_chunks(doc, kind="text")
        for ch in chunks:
            ch["conversation_id"] = "local_fs:" + it["sha256"][:12]
            ch["proof_chain"] = []
            store.write_chunk(ch)
            particle = compress_chunk(ch, method="plain")
            store.write_particle(particle)

    fs_save_index(index_path, materialize_prev_format(cur_list))
    print(json.dumps({"ok": True, "changed_files": len(changed)}, ensure_ascii=False, indent=2))

def cmd_query(args):
    from flowagent.query.search import keyword_query
    res = keyword_query(args.data_root, args.text, top_k=args.top_k)
    print(json.dumps(res, ensure_ascii=False, indent=2))

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data-root", default="data")
    sub = ap.add_subparsers(dest="cmd", required=True)

    p1 = sub.add_parser("ingest_external_chat")
    p1.add_argument("--zip", required=True)
    p1.set_defaults(fn=cmd_ingest_external_chat)

    p2 = sub.add_parser("proof_verify")
    p2.set_defaults(fn=cmd_proof_verify)

    p3 = sub.add_parser("snapshot_create")
    p3.set_defaults(fn=cmd_snapshot_create)

    p4 = sub.add_parser("snapshot_verify")
    p4.add_argument("--snapshot-id", default="latest")
    p4.set_defaults(fn=cmd_snapshot_verify)

    p5 = sub.add_parser("bridge_localfs")
    p5.add_argument("--root", required=True)
    p5.add_argument("--exts", default=".md,.txt,.json,.py,.js,.ts,.yml,.yaml")
    p5.set_defaults(fn=cmd_bridge_localfs)

    p6 = sub.add_parser("query")
    p6.add_argument("--text", required=True)
    p6.add_argument("--top-k", type=int, default=10)
    p6.set_defaults(fn=cmd_query)

    args = ap.parse_args()
    args.fn(args)

if __name__ == "__main__":
    main()
