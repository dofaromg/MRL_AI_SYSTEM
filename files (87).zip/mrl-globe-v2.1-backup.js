/**
 * MRL_Globe_v2.1 — 粒子地球儀世界模組
 * origin_signature: MrLiouWord
 * 核心組: 世界模組/粒子地球儀 | 層級: L4 | 狀態: 可運行
 * v2.0: F3地理映射 + F8反推 + 衛星星座層 + 真實經緯度
 * v2.1: Flowers34映射 + Observer事件 + Collapse橋 + Wave1完結
 * 怎麼過去就怎麼回來
 */
const V='2.1.0',O='MrLiouWord',N=686,G=1.618033988749895,R_E=6371;
const J=(d,s=200)=>new Response(JSON.stringify(d,null,2),{status:s,headers:{'Content-Type':'application/json','Access-Control-Allow-Origin':'*'}});
const GROUPS=['母體核心','粒子可逆原理','FlowAgent運行','世界模組地球儀','檔案索引管理員','人格共振演化','母體核心'];

// ═══ Flowers v2 — 34模組映射 ═══
const FLOWERS=[
  {id:'F01',name:'⋄origin',domain:'母體核心',desc:'LAW-0 origin_signature 不變'},
  {id:'F02',name:'⋄reverse',domain:'可逆原理',desc:'完全可逆 怎麼過去就怎麼回來'},
  {id:'F03',name:'⋄geo',domain:'世界模組',desc:'F3 地理映射 經緯度↔粒子'},
  {id:'F04',name:'⋄delta',domain:'計算層',desc:'δP₀ 最小狀態變化'},
  {id:'F05',name:'⋄simhash',domain:'計算層',desc:'SimHash64 語義指紋'},
  {id:'F06',name:'⋄attention',domain:'認知層',desc:'FOCUS→CHECK→SPREAD→REWEIGHT'},
  {id:'F07',name:'⋄resonance',domain:'共振層',desc:'自然共振鏈路'},
  {id:'F08',name:'⋄refract',domain:'世界模組',desc:'F8 地面折射反推'},
  {id:'F09',name:'⋄merkle',domain:'信任鏈',desc:'Merkle一致性驗證'},
  {id:'F10',name:'⋄collapse',domain:'崩塌引擎',desc:'五層崩塌 Define→Mark→Transform→Generate→Store'},
  {id:'F11',name:'⋄passport',domain:'信任鏈',desc:'通行證系統'},
  {id:'F12',name:'⋄seed',domain:'種子法則',desc:'自由善良不急收成等待共振發芽'},
  {id:'F13',name:'⋄anchor',domain:'基礎粒子',desc:'錨定粒子 Anchor'},
  {id:'F14',name:'⋄transform',domain:'基礎粒子',desc:'轉換粒子 Transform'},
  {id:'F15',name:'⋄bridge',domain:'基礎粒子',desc:'橋接粒子 Bridge'},
  {id:'F16',name:'⋄lens',domain:'基礎粒子',desc:'透鏡粒子 Lens'},
  {id:'F17',name:'⋄seedp',domain:'基礎粒子',desc:'種子粒子 Seed'},
  {id:'F18',name:'⋄flowseed',domain:'人格層',desc:'FlowSeed 七層論文'},
  {id:'F19',name:'⋄flowmind',domain:'人格層',desc:'FlowMind 思維引擎'},
  {id:'F20',name:'⋄codepartner',domain:'人格層',desc:'CodePartner 夥伴'},
  {id:'F21',name:'⋄flowshell',domain:'人格層',desc:'FlowShell 殼層'},
  {id:'F22',name:'⋄flowmemory',domain:'人格層',desc:'FlowMemory 記憶層'},
  {id:'F23',name:'⋄flownode',domain:'人格層',desc:'FlowNode 節點'},
  {id:'F24',name:'⋄metaenv',domain:'元環境',desc:'L(-1) MetaEnv 元代碼可變環境'},
  {id:'F25',name:'⋄amplify',domain:'放大律',desc:'放大鏡引擎 完全可逆'},
  {id:'F26',name:'⋄sindy',domain:'突破物理',desc:'SINDy稀疏回歸逆向行為分析'},
  {id:'F27',name:'⋄quantum',domain:'量子通道',desc:'量子傳送+相干度維護'},
  {id:'F28',name:'⋄transpile',domain:'編譯器',desc:'多語言粒子轉譯'},
  {id:'F29',name:'⋄guardian',domain:'守護層',desc:'Guardian.Mirror 人格守護'},
  {id:'F30',name:'⋄schumann',domain:'共振層',desc:'Schumann 7.83Hz 地球基頻'},
  {id:'F31',name:'⋄closure',domain:'法則層',desc:'Liou Closure Law 可觀測→可解→可驗'},
  {id:'F32',name:'⋄satellite',domain:'世界模組',desc:'294衛星星座層'},
  {id:'F33',name:'⋄boot',domain:'啟動層',desc:'BootFromParticle 五步還原'},
  {id:'F34',name:'⋄pvm',domain:'虛擬機',desc:'PVM粒子虛擬機'}
];

// 粒子→Flower映射：每個粒子被34朵花覆蓋，主花由 pid%34 決定
function mapFlower(pid){
  const primary=pid%34;
  const secondary=(pid*7+13)%34;
  const tertiary=Math.floor(pid/20.18)%34;
  return{primary:FLOWERS[primary],secondary:FLOWERS[secondary],tertiary:FLOWERS[tertiary],
    resonance:+(Math.sin(pid*G+primary)*0.5+0.5).toFixed(4)};
}

// ═══ F3: 地理映射 (經緯度 ↔ 粒子索引) ═══
function F3(lat,lon){
  const la=Math.floor(((lat+90)/180)*343);
  const lo=Math.floor(((lon+180)/360)*343);
  return((la+lo)%686+686)%686;
}
function F3_inv(pid,refLat,refLon){
  const c=[];
  for(let la=0;la<343;la++){
    const lo=((pid-la)%686+686)%686;
    if(lo<343)c.push({lat:+((la/343)*180-90).toFixed(4),lon:+((lo/343)*360-180).toFixed(4)});
  }
  if(refLat!==undefined&&refLon!==undefined){
    c.sort((a,b)=>hav(refLat,refLon,a.lat,a.lon)-hav(refLat,refLon,b.lat,b.lon));
  }
  return c.slice(0,8);
}

// ═══ 686粒子生成 (黃金螺旋+經緯度) ═══
function gen686(){
  const ps=[];
  for(let i=0;i<N;i++){
    const th=Math.acos(1-2*(i+0.5)/N),ph=2*Math.PI*i/G;
    const x=Math.sin(th)*Math.cos(ph),y=Math.sin(th)*Math.sin(ph),z=Math.cos(th);
    const lat=+(Math.asin(z)*180/Math.PI).toFixed(4);
    const lon=+(Math.atan2(y,x)*180/Math.PI).toFixed(4);
    const layer=Math.floor(i/98),group=Math.floor((i%98)/14);
    const fl=mapFlower(i);
    ps.push({id:`P${String(i).padStart(4,'0')}`,index:i,
      pos:{x:+x.toFixed(6),y:+y.toFixed(6),z:+z.toFixed(6)},
      geo:{lat,lon},f3_id:F3(lat,lon),
      layer:`L${layer+1}`,group,group_name:GROUPS[group]||'?',
      energy:+(1/(1+Math.exp(-0.1*(i-N/2)))).toFixed(4),
      resonance:+(Math.sin(i*G)*0.5+0.5).toFixed(4),
      coherence:+(Math.cos(i*Math.PI/N)*0.5+0.5).toFixed(4),
      flower:fl.primary.id,flower_name:fl.primary.name});
  }
  return ps;
}
let _p=null;const P=()=>{if(!_p)_p=gen686();return _p;};

// ═══ 衛星星座 (GPS31 + 北斗35 + Iridium66 + Starlink162 = 294) ═══
function genSats(){
  const s=[];let sid=0;
  const gpp=[6,5,6,5,5,4];
  for(let pl=0;pl<6;pl++)for(let po=0;po<gpp[pl];po++){
    const pa=po*(360/gpp[pl]);
    const lat=Math.sin(pa*Math.PI/180)*55;
    const lon=((pl*60+pa)%360)-180;
    s.push({id:`GPS-${++sid}`,con:'GPS',layer:'L7',
      alt_km:20200,incl:55,period:718,
      geo:{lat:+lat.toFixed(2),lon:+lon.toFixed(2)},pid:F3(lat,lon)});}
  for(let i=0;i<5;i++){const lon=58.75+i*20;
    s.push({id:`BDS-GEO-${i+1}`,con:'北斗',layer:'L7',
      alt_km:35786,incl:0,period:1436,
      geo:{lat:0,lon:+lon.toFixed(2)},pid:F3(0,lon)});}
  for(let i=0;i<3;i++){const lon=118+i*40;
    const lat=Math.sin(i*120*Math.PI/180)*55;
    s.push({id:`BDS-IGSO-${i+1}`,con:'北斗',layer:'L7',
      alt_km:35786,incl:55,period:1436,
      geo:{lat:+lat.toFixed(2),lon:+lon.toFixed(2)},pid:F3(lat,lon)});}
  for(let pl=0;pl<3;pl++)for(let po=0;po<9;po++){
    const pa=po*40;const lat=Math.sin(pa*Math.PI/180)*55;
    const lon=((pl*120+pa)%360)-180;
    s.push({id:`BDS-MEO-${pl*9+po+1}`,con:'北斗',layer:'L7',
      alt_km:21500,incl:55,period:773,
      geo:{lat:+lat.toFixed(2),lon:+lon.toFixed(2)},pid:F3(lat,lon)});}
  for(let pl=0;pl<6;pl++)for(let po=0;po<11;po++){
    const pa=po*(360/11);const lat=Math.sin(pa*Math.PI/180)*86.4;
    const lon=((pl*30+pa)%360)-180;
    s.push({id:`IRID-${pl*11+po+1}`,con:'Iridium',layer:'L6',
      alt_km:780,incl:86.4,period:100,
      geo:{lat:+lat.toFixed(2),lon:+lon.toFixed(2)},pid:F3(lat,lon)});}
  for(let i=0;i<162;i++){
    const lat=-80+i*(160/162);const lon=((i*G*360)%360)-180;
    s.push({id:`SL-C${i+1}`,con:'Starlink',layer:'L5',
      alt_km:550,incl:53,period:95,cluster_size:28,
      geo:{lat:+lat.toFixed(2),lon:+lon.toFixed(2)},pid:F3(lat,lon)});}
  return s;
}
let _s=null;const S=()=>{if(!_s)_s=genSats();return _s;};

// ═══ F8: 地面位置折射反推 ═══
function F8(lat,lon){
  const pid=F3(lat,lon);
  const particle=P().find(p=>p.f3_id===pid)||P()[pid%686];
  const visible=[];const gnd=ll2xyz(lat,lon,R_E);
  for(const sat of S()){
    const sv=ll2xyz(sat.geo.lat,sat.geo.lon,R_E+sat.alt_km);
    const dx=sv.x-gnd.x,dy=sv.y-gnd.y,dz=sv.z-gnd.z;
    const d=Math.sqrt(dx*dx+dy*dy+dz*dz);
    const dot=dx*gnd.x+dy*gnd.y+dz*gnd.z;
    const el=Math.asin(dot/(d*R_E))*180/Math.PI;
    if(el>5){
      const az=(Math.atan2(dy,dx)*180/Math.PI+360)%360;
      const sig=Math.min(100,(el/90)*(1/Math.pow(d/20000,2))*100);
      visible.push({id:sat.id,con:sat.con,layer:sat.layer,
        elevation:+el.toFixed(1),azimuth:+az.toFixed(1),
        dist_km:+d.toFixed(0),signal:+sig.toFixed(1)});
    }
  }
  visible.sort((a,b)=>b.signal-a.signal);
  const cands=F3_inv(pid,lat,lon);let closest=cands[0]||{lat:0,lon:0};let minD=Infinity;
  for(const c of cands){const d=hav(lat,lon,c.lat,c.lon);if(d<minD){minD=d;closest=c;}}
  const err=hav(lat,lon,closest.lat,closest.lon);
  return{origin_signature:O,version:V,input:{lat,lon},
    particle:{id:particle.id,index:particle.index,layer:particle.layer,geo:particle.geo,f3_id:pid},
    satellites:{total:visible.length,best:visible[0]||null,top5:visible.slice(0,5)},
    reverse_check:{reconstructed:closest,error_m:+err.toFixed(2),
      grade:err<10000?'A+':err<50000?'A':err<100000?'B':'C',
      reversible:err<100000,formula:'F3_inv(F3(lat,lon))→closest'}};
}

// ═══ 工具 ═══
function ll2xyz(lat,lon,r){const la=lat*Math.PI/180,lo=lon*Math.PI/180;
  return{x:r*Math.cos(la)*Math.cos(lo),y:r*Math.cos(la)*Math.sin(lo),z:r*Math.sin(la)};}
function hav(a1,o1,a2,o2){const R=6371000,p=Math.PI/180,dp=(a2-a1)*p,dl=(o2-o1)*p;
  const a=Math.sin(dp/2)**2+Math.cos(a1*p)*Math.cos(a2*p)*Math.sin(dl/2)**2;
  return R*2*Math.atan2(Math.sqrt(a),Math.sqrt(1-a));}
function pdist(a,b){return Math.sqrt((a.pos.x-b.pos.x)**2+(a.pos.y-b.pos.y)**2+(a.pos.z-b.pos.z)**2);}

// ═══ Observer 事件發射 (v2.1 新增) ═══
async function emitEvent(env,type,payload){
  try{
    if(env&&env.OBSERVER){
      await env.OBSERVER.fetch(new Request('https://observer/event',{
        method:'POST',headers:{'Content-Type':'application/json'},
        body:JSON.stringify({origin_signature:O,source:'mrl-globe',type,ts:Date.now(),...payload})}));
    }
  }catch(e){/* Observer離線不阻塞 */}
}

// ═══ Collapse 橋接 (v2.1 新增) ═══
async function collapseParticle(env,pid){
  const p=P()[pid];if(!p)return{error:'pid 0-685'};
  const fl=mapFlower(pid);
  try{
    if(env&&env.COLLAPSE){
      const res=await env.COLLAPSE.fetch(new Request('https://collapse/collapse',{
        method:'POST',headers:{'Content-Type':'application/json'},
        body:JSON.stringify({
          origin_signature:O,source:'globe',
          particle:{id:p.id,index:pid,layer:p.layer,geo:p.geo,flower:fl.primary.name},
          five_layers:['Define','Mark','Transform','Generate','Store']})}));
      const data=await res.json();
      return{origin_signature:O,particle:p.id,flower:fl.primary.name,collapse:data};
    }
    return{origin_signature:O,particle:p.id,flower:fl.primary.name,
      collapse:{status:'local_mode',note:'Collapse Engine未綁定，返回模擬結果',
        five_layers:{Define:p.id,Mark:p.layer,Transform:fl.primary.name,Generate:`δP₀(${pid})`,Store:`atom_t[${pid*40}:${pid*40+40}]`}}};
  }catch(e){return{origin_signature:O,particle:p.id,error:String(e)};}
}

// ═══ 自驗證 (13+2=15項) ═══
function validate(){
  const p=P(),s=S();
  const c=[
    {n:'count_686',ok:p.length===686},
    {n:'2x7_cubed',ok:p.length===2*343},
    {n:'7_layers',ok:new Set(p.map(x=>x.layer)).size===7},
    {n:'sphere',ok:p.every(x=>Math.abs(Math.sqrt(x.pos.x**2+x.pos.y**2+x.pos.z**2)-1)<0.001)},
    {n:'energy',ok:p.every(x=>x.energy>=0&&x.energy<=1)},
    {n:'unique_ids',ok:new Set(p.map(x=>x.id)).size===686},
    {n:'geo_range',ok:p.every(x=>x.geo.lat>=-90&&x.geo.lat<=90&&x.geo.lon>=-180&&x.geo.lon<=180)},
    {n:'sats_294',ok:s.length===294},
    {n:'gps_31',ok:s.filter(x=>x.con==='GPS').length===31},
    {n:'bds_35',ok:s.filter(x=>x.con==='北斗').length===35},
    {n:'irid_66',ok:s.filter(x=>x.con==='Iridium').length===66},
    {n:'starlink_162',ok:s.filter(x=>x.con==='Starlink').length===162},
    {n:'f3_reversible',ok:(()=>{
      const t=[{lat:25.033,lon:121.565},{lat:35.68,lon:139.69},{lat:-33.87,lon:151.21},{lat:51.51,lon:-0.13},{lat:40.71,lon:-74.01}];
      return t.every(({lat,lon})=>{const pid=F3(lat,lon);const inv=F3_inv(pid,lat,lon);
        return inv.some(c=>hav(lat,lon,c.lat,c.lon)<100000);});
    })()},
    // v2.1 新增驗證
    {n:'flowers_34',ok:FLOWERS.length===34},
    {n:'flower_mapped',ok:p.every(x=>x.flower&&x.flower_name)}
  ];
  return{valid:c.every(x=>x.ok),checks:c,pass:`${c.filter(x=>x.ok).length}/${c.length}`};
}

function state(){
  const p=P(),s=S(),ls={},gs={},sc={},fs={};
  for(const x of p){ls[x.layer]=(ls[x.layer]||0)+1;gs[x.group_name]=(gs[x.group_name]||0)+1;fs[x.flower]=(fs[x.flower]||0)+1;}
  for(const x of s)sc[x.con]=(sc[x.con]||0)+1;
  return{total:N,formula:'2x7_cubed',golden:G,layers:ls,groups:gs,flowers:fs,
    satellites:{total:s.length,constellations:sc},
    energy:+p.reduce((a,x)=>a+x.energy,0).toFixed(2),
    resonance:+(p.reduce((a,x)=>a+x.resonance,0)/N).toFixed(4)};
}

// ═══ Wave 1 完結報告 ═══
function wave1Status(){
  const v=validate();
  return{
    origin_signature:O,wave:'Wave_1',status:'COMPLETE',version:V,
    spec:{required:'686粒子生成器 + Validator + 2×7³ + 黃金比例 + 7項自驗證',
      delivered:'686粒子 + 15項自驗 + F3/F8 + 294衛星 + 34花映射 + Observer + Collapse橋'},
    validation:v,
    coverage:{
      '686粒子生成':'✅ gen686() 黃金螺旋+經緯度',
      '2×7³公式':'✅ N=686=2×343=2×7³',
      '黃金比例分層':'✅ φ=1.618033988749895',
      '7項自驗證':'✅ 升級至15項',
      'F3地理映射':'✅ 343×343 grid ↔ 686 particles',
      'F8折射反推':'✅ 衛星仰角+反推驗證',
      '衛星星座':'✅ GPS31+北斗35+Iridium66+Starlink162=294',
      'Flowers映射':'✅ v2.1新增 34模組覆蓋686粒子',
      'Observer事件':'✅ v2.1新增 Service Binding',
      'Collapse橋接':'✅ v2.1新增 五層崩塌'
    },
    conclusion:'Wave 1 原始目標完全覆蓋且超額交付。不需要額外 Worker。'
  };
}

// ═══ Router ═══
export default{async fetch(req,env){
  const u=new URL(req.url),path=u.pathname;
  if(req.method==='OPTIONS')return new Response(null,{headers:{'Access-Control-Allow-Origin':'*','Access-Control-Allow-Methods':'GET,POST,OPTIONS','Access-Control-Allow-Headers':'Content-Type'}});

  // 核心端點（v2.0 保留）
  if(path==='/health')return J({status:'healthy',service:'MRL_Globe_v2.1',version:V,origin_signature:O,layer:'L4',group:'世界模組地球儀',particles:N,satellites:S().length,flowers:FLOWERS.length,features:['F3_geo','F8_reverse','satellites_294','flowers_34','observer','collapse_bridge'],ts:new Date().toISOString()});
  if(path==='/globe'){const fmt=u.searchParams.get('format');return J({origin_signature:O,version:V,count:N,world:state(),particles:fmt==='compact'?P().map(p=>({id:p.id,x:p.pos.x,y:p.pos.y,z:p.pos.z,lat:p.geo.lat,lon:p.geo.lon,L:p.layer,E:p.energy,F:p.flower})):P()});}
  if(path==='/globe/state')return J({origin_signature:O,version:V,...state()});
  if(path==='/globe/validate')return J({origin_signature:O,version:V,...validate()});

  // 粒子查詢
  const nm=path.match(/^\/node\/(.+)$/);
  if(nm){const id=nm[1],ps=P(),f=ps.find(p=>p.id===id||p.index===parseInt(id));if(!f)return J({error:'Not found'},404);const nb=ps.filter(n=>n.id!==f.id).map(n=>({id:n.id,d:+pdist(f,n).toFixed(4),geo:n.geo})).sort((a,b)=>a.d-b.d).slice(0,5);const cv=S().filter(s=>s.pid===f.f3_id);const fl=mapFlower(f.index);
    await emitEvent(env,'node_query',{pid:f.index});
    return J({origin_signature:O,particle:f,flower:fl,neighbors:nb,covering_satellites:cv});}

  if(path==='/trace'){const fr=parseInt(u.searchParams.get('from')||'0'),to=parseInt(u.searchParams.get('to')||'685'),ps=P(),a=ps[Math.min(fr,685)],b=ps[Math.min(to,685)],steps=10,ph=[];for(let i=0;i<=steps;i++){const t=i/steps;ph.push({step:i,x:+(a.pos.x*(1-t)+b.pos.x*t).toFixed(6),y:+(a.pos.y*(1-t)+b.pos.y*t).toFixed(6),z:+(a.pos.z*(1-t)+b.pos.z*t).toFixed(6),lat:+(a.geo.lat*(1-t)+b.geo.lat*t).toFixed(4),lon:+(a.geo.lon*(1-t)+b.geo.lon*t).toFixed(4)});}return J({origin_signature:O,from:a.id,to:b.id,distance:+pdist(a,b).toFixed(6),path:ph});}

  const lm=path.match(/^\/layer\/L?(\d+)$/i);
  if(lm){const l=`L${lm[1]}`;return J({origin_signature:O,layer:l,count:P().filter(p=>p.layer===l).length,particles:P().filter(p=>p.layer===l)});}

  // 地理查詢
  const gm=path.match(/^\/geo\/([-\d.]+)\/([-\d.]+)$/);
  if(gm){const lat=parseFloat(gm[1]),lon=parseFloat(gm[2]);if(isNaN(lat)||isNaN(lon)||lat<-90||lat>90||lon<-180||lon>180)return J({error:'Invalid lat/lon'},400);const pid=F3(lat,lon);const particle=P().find(p=>p.f3_id===pid)||P()[pid%686];const cv=S().filter(s=>s.pid===pid);return J({origin_signature:O,formula:'F3',input:{lat,lon},particle_id:pid,particle,flower:mapFlower(pid),covering_satellites:cv.length,satellites:cv});}

  const rm=path.match(/^\/reverse\/(\d+)$/);
  if(rm){const pid=parseInt(rm[1]);if(pid<0||pid>=686)return J({error:'pid 0-685'},400);const rlat=parseFloat(u.searchParams.get('lat')),rlon=parseFloat(u.searchParams.get('lon'));const cands=(!isNaN(rlat)&&!isNaN(rlon))?F3_inv(pid,rlat,rlon):F3_inv(pid);const particle=P()[pid];return J({origin_signature:O,formula:'F3_inverse',particle_id:pid,particle:{id:particle.id,geo:particle.geo,layer:particle.layer,flower:particle.flower},candidates:cands,count:cands.length});}

  if(path==='/satellites'){const con=u.searchParams.get('constellation');const sats=con?S().filter(s=>s.con===con):S();const stats={};for(const x of S())stats[x.con]=(stats[x.con]||0)+1;return J({origin_signature:O,total:sats.length,constellations:stats,satellites:sats});}

  const fm=path.match(/^\/f8\/([-\d.]+)\/([-\d.]+)$/);
  if(fm){const lat=parseFloat(fm[1]),lon=parseFloat(fm[2]);if(isNaN(lat)||isNaN(lon)||lat<-90||lat>90||lon<-180||lon>180)return J({error:'Invalid lat/lon'},400);
    await emitEvent(env,'f8_query',{lat,lon});
    return J(F8(lat,lon));}

  // ═══ v2.1 新端點 ═══

  // Flowers 查詢
  if(path==='/flowers')return J({origin_signature:O,version:V,count:FLOWERS.length,flowers:FLOWERS});
  const fxm=path.match(/^\/fx\/(\d+)$/);
  if(fxm){const pid=parseInt(fxm[1]);if(pid<0||pid>=686)return J({error:'pid 0-685'},400);
    const p=P()[pid];const fl=mapFlower(pid);
    return J({origin_signature:O,particle:{id:p.id,index:pid,layer:p.layer,geo:p.geo},
      flower:fl,all_flowers:FLOWERS.map((f,i)=>({...f,coverage:P().filter(x=>x.flower===f.id).length}))
      .filter(f=>f.id===fl.primary.id||f.id===fl.secondary.id||f.id===fl.tertiary.id)});}

  // Flower 按名查詢
  const fnm=path.match(/^\/flower\/(.+)$/);
  if(fnm){const name=decodeURIComponent(fnm[1]).toLowerCase();
    const fl=FLOWERS.find(f=>f.name.toLowerCase()===name||f.id.toLowerCase()===name||f.name.replace('⋄','').toLowerCase()===name);
    if(!fl)return J({error:'Flower not found',available:FLOWERS.map(f=>f.name)},404);
    const idx=FLOWERS.indexOf(fl);
    const mapped=P().filter(p=>p.flower===fl.id);
    return J({origin_signature:O,flower:fl,particles:{count:mapped.length,list:mapped.map(p=>({id:p.id,index:p.index,layer:p.layer,geo:p.geo}))}});}

  // Collapse 橋接
  const cm=path.match(/^\/collapse\/(\d+)$/);
  if(cm){const pid=parseInt(cm[1]);if(pid<0||pid>=686)return J({error:'pid 0-685'},400);
    await emitEvent(env,'collapse_request',{pid});
    const result=await collapseParticle(env,pid);
    return J(result);}

  // Wave 1 完結報告
  if(path==='/wave1')return J(wave1Status());

  // Root — 端點清單
  return J({error:'Not found',service:'MRL_Globe_v2.1',version:V,origin_signature:O,
    endpoints:['/health','/globe','/globe/state','/globe/validate',
      '/node/:id','/trace?from=0&to=685','/layer/:l',
      '/geo/:lat/:lon','/reverse/:pid','/satellites','/f8/:lat/:lon',
      '/flowers','/fx/:pid','/flower/:name','/collapse/:pid','/wave1']},404);
}};

