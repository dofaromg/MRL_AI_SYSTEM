#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Fluin .fltnz Decoder / Viewer  (Python 2 & 3 compatible)

What changed (fix):
- Removed Python 3–only features (f-strings, pathlib, typing, print(file=...)).
- Replaced stderr prints with a tiny eprint() helper (works on Py2/Py3).
- Made gzip, tkinter imports/version handling cross‑version.
- Added --selftest that builds a sample native FLTNZ buffer and verifies decoding.

Features:
- Detect & decode: native FLTNZ header, ZIP, GZIP, MessagePack, JSON
- Outputs readable JSON and a tree summary (.tree.txt)
- CLI and simple GUI (drag & choose)

Usage:
  python fluin_decoder.py FILE.fltnz
  python fluin_decoder.py --gui
  python fluin_decoder.py --selftest
"""
from __future__ import print_function
import argparse
import gzip
import io
import json
import os
import struct
import sys
import textwrap
import zipfile

# Optional msgpack
try:
    import msgpack  # type: ignore
except Exception:  # pragma: no cover
    msgpack = None

# Tk cross-version imports (Py2: Tkinter / Py3: tkinter)
try:  # Python 3
    import tkinter as tk  # type: ignore
    from tkinter import filedialog, messagebox  # type: ignore
except Exception:  # Python 2
    try:
        import Tkinter as tk  # type: ignore
        import tkFileDialog as filedialog  # type: ignore
        import tkMessageBox as messagebox  # type: ignore
    except Exception:
        tk = None
        filedialog = None
        messagebox = None

PY2 = sys.version_info[0] == 2
MAGIC = b"FLTNZ\x00"

# ----------------------------
# Utilities
# ----------------------------

def eprint(msg):
    sys.stderr.write(str(msg) + "\n")


def ensure_out_dir(path):
    if not os.path.isdir(path):
        try:
            os.makedirs(path)
        except OSError:
            pass


def write_text(path, text):
    # robust UTF-8 writer for Py2/Py3
    if PY2:
        import codecs
        with codecs.open(path, 'w', 'utf-8') as f:
            f.write(text)
    else:
        with open(path, 'w', encoding='utf-8') as f:  # type: ignore
            f.write(text)


# ----------------------------
# Core decoders
# ----------------------------

def decode_native_fltnz(data):
    """Parse a minimal native FLTNZ header + JSON payload.

    Expected layout:
      0..5  : magic "FLTNZ\0"
      6..9  : u32 be header_length
      10..13: u32 be json_length
      14..  : header bytes (UTF-8 JSON)
      14+H  : json bytes   (UTF-8 JSON payload)
    """
    if not data.startswith(MAGIC):
        raise ValueError('Not native FLTNZ')
    off = len(MAGIC)
    if len(data) < off + 8:
        raise ValueError('Truncated FLTNZ header')
    header_len = struct.unpack_from('>I', data, off)[0]
    off += 4
    json_len = struct.unpack_from('>I', data, off)[0]
    off += 4
    if len(data) < off + header_len + json_len:
        raise ValueError('FLTNZ size mismatch')
    header_raw = data[off:off + header_len]
    off += header_len
    json_raw = data[off:off + json_len]

    header = json.loads(header_raw.decode('utf-8'))
    payload = json.loads(json_raw.decode('utf-8'))
    return {'container': 'fltnz-native', 'header': header, 'payload': payload}


# Heuristics for other containers

def try_zip(buf):
    try:
        zf = zipfile.ZipFile(io.BytesIO(buf))
        _ = zf.namelist()
        return zf
    except Exception:
        return None


def try_gzip(buf):
    # Python 3: gzip.decompress exists; Py2 fallback uses GzipFile
    try:
        if hasattr(gzip, 'decompress'):
            return gzip.decompress(buf)  # type: ignore[attr-defined]
        else:  # Python 2 path
            bio = io.BytesIO(buf)
            gf = gzip.GzipFile(fileobj=bio)
            return gf.read()
    except Exception:
        return None


def try_msgpack(buf):
    if msgpack is None:
        return None
    try:
        # raw=False ensures strings are unicode in Py3 and unicode in Py2
        return msgpack.unpackb(buf, raw=False)
    except Exception:
        return None


def try_json(buf):
    try:
        return json.loads(buf.decode('utf-8'))
    except Exception:
        return None


# ----------------------------
# Emitters
# ----------------------------

def emit_tree(obj):
    lines = []

    def walk(o, prefix='$'):
        if isinstance(o, dict):
            lines.append('%s <obj> %d keys' % (prefix, len(o)))
            for k in o:
                walk(o[k], '%s.%s' % (prefix, k))
        elif isinstance(o, list):
            lines.append('%s <arr> %d items' % (prefix, len(o)))
            limit = 50
            for i, v in enumerate(o[:limit]):
                walk(v, '%s[%d]' % (prefix, i))
            if len(o) > limit:
                lines.append('%s[…] (%d more)' % (prefix, len(o) - limit))
        else:
            s = u'' + (u'' if o is None else unicode(o) if PY2 else str(o))  # noqa: F821 for Py3 linters
            if len(s) > 120:
                s = s[:117] + u'…'
            lines.append('%s = %s' % (prefix, s))

    walk(obj)
    return '\n'.join(lines)


# ----------------------------
# Decode pipeline
# ----------------------------

def decode_file(path):
    with open(path, 'rb') as f:
        buf = f.read()

    # 1) native fltnz
    try:
        native = decode_native_fltnz(buf)
        return 'native', native, {'raw': buf}
    except Exception:
        pass

    # 2) zip
    zf = try_zip(buf)
    if zf is not None:
        return 'zip', zf, {'raw': buf}

    # 3) gzip (+ inner formats)
    gz = try_gzip(buf)
    if gz is not None:
        mp = try_msgpack(gz)
        if mp is not None:
            return 'msgpack', mp, {'raw': gz}
        js = try_json(gz)
        if js is not None:
            return 'json', js, {'raw': gz}
        return 'gzip', gz, {'raw': gz}

    # 4) msgpack (raw)
    mp = try_msgpack(buf)
    if mp is not None:
        return 'msgpack', mp, {'raw': buf}

    # 5) json (raw)
    js = try_json(buf)
    if js is not None:
        return 'json', js, {'raw': buf}

    raise SystemExit('Unrecognized .fltnz format. Provide spec or sample header.')


# ----------------------------
# CLI
# ----------------------------

def run_cli(args):
    path = args.input
    mode, data, meta = decode_file(path)
    out_dir = args.output or (os.path.splitext(path)[0] + '_decoded')
    ensure_out_dir(out_dir)

    print("[ok] decoded '%s' as %s" % (os.path.basename(path), mode))

    if mode == 'zip':
        with data as zf:
            zf.extractall(out_dir)
        print("[ok] extracted zip payload -> %s" % out_dir)
        return

    if mode in ('json', 'msgpack', 'native'):
        obj = data
        json_path = os.path.join(out_dir, 'payload.json')
        tree_path = os.path.join(out_dir, 'payload.tree.txt')
        write_text(json_path, json.dumps(obj, indent=2, ensure_ascii=False))
        write_text(tree_path, emit_tree(obj))
        print("[ok] wrote %s and %s" % (json_path, tree_path))
        return

    if mode == 'gzip':
        raw_path = os.path.join(out_dir, 'payload.raw')
        with open(raw_path, 'wb') as f:
            f.write(meta['raw'])
        print("[ok] wrote gzip-decompressed stream -> %s" % raw_path)


# ----------------------------
# (Optional) Tiny GUI
# ----------------------------

def run_gui():
    if tk is None or filedialog is None or messagebox is None:
        eprint('Tkinter is not available in this Python environment.')
        return

    def choose_and_decode():
        ftypes = [("FLTNZ", "*.fltnz"), ("All", "*.*")]
        fpath = filedialog.askopenfilename(title='Open .fltnz', filetypes=ftypes)
        if not fpath:
            return
        try:
            class Dummy(object):
                pass
            args = Dummy()
            args.input = fpath
            args.output = None
            run_cli(args)
            messagebox.showinfo('Fluin Decoder', 'Decode complete. Output folder next to your file.')
        except Exception as e:
            messagebox.showerror('Fluin Decoder', str(e))

    root = tk.Tk()
    root.title('Fluin .fltnz Decoder')
    root.geometry('420x200')

    lbl = tk.Label(root, text=textwrap.dedent('''
        Choose a .fltnz file to decode.
        Output will be saved next to the file.
    '''))
    lbl.pack(padx=12, pady=12)

    btn = tk.Button(root, text='Choose .fltnz…', command=choose_and_decode)
    btn.pack(pady=12)

    root.mainloop()


# ----------------------------
# Tests / Self-check
# ----------------------------

def selftest(tmpdir=None):
    # Build a minimal native FLTNZ sample in-memory, then decode it
    header = {"version": 1, "kind": "test"}
    payload = {"hello": "world", "arr": [1, 2, 3]}
    h = json.dumps(header).encode('utf-8')
    p = json.dumps(payload).encode('utf-8')
    buf = MAGIC + struct.pack('>I', len(h)) + struct.pack('>I', len(p)) + h + p

    # Write temp file
    base = os.path.abspath(tmpdir or '.')
    path = os.path.join(base, 'sample_test.fltnz')
    with open(path, 'wb') as f:
        f.write(buf)

    mode, data, _ = decode_file(path)
    assert mode == 'native', 'Expected native mode'
    assert data['header']['version'] == 1
    assert data['payload']['hello'] == 'world'
    # emit tree shouldn't crash
    _ = emit_tree(data)
    # cleanup
    try:
        os.remove(path)
    except Exception:
        pass
    print('[ok] selftest passed')


# ----------------------------
# Entrypoint
# ----------------------------

def parse_args(argv=None):
    p = argparse.ArgumentParser(description='Fluin .fltnz Decoder / Viewer')
    p.add_argument('input', nargs='?', help='input .fltnz file (omit with --gui or --selftest)')
    p.add_argument('-o', '--output', help='output directory')
    p.add_argument('--gui', action='store_true', help='launch simple GUI')
    p.add_argument('--selftest', action='store_true', help='run built-in tests')
    return p.parse_args(argv)


if __name__ == '__main__':
    args = parse_args()
    if args.selftest:
        selftest()
        sys.exit(0)
    if args.gui and not args.input:
        run_gui()
    elif args.input:
        run_cli(args)
    else:
        eprint('Provide an input file, or use --gui or --selftest')
        sys.exit(2)
