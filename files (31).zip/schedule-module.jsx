/**
 * schedule-module.jsx
 * 排班管理 — 月曆班表 + 遲到/早退自動判斷
 * 愛心教養院考勤系統 v3.3
 */

import { useState, useEffect, useCallback } from "react";

// ─── 班別定義 ─────────────────────────────────────────────────────────────────
const SHIFT_TYPES = {
  "早": { label: "早班",  start: "07:00", end: "15:00", color: "#f59e0b", bg: "rgba(245,158,11,0.15)" },
  "中": { label: "中班",  start: "15:00", end: "23:00", color: "#0ea5e9", bg: "rgba(14,165,233,0.15)" },
  "晚": { label: "晚班",  start: "23:00", end: "07:00", color: "#8b5cf6", bg: "rgba(139,92,246,0.15)" },
  "日": { label: "日班",  start: "08:00", end: "17:00", color: "#10b981", bg: "rgba(16,185,129,0.15)" },
  "休": { label: "休假",  start: null,    end: null,    color: "#64748b", bg: "rgba(100,116,139,0.15)" },
  "假": { label: "國定假日", start: null, end: null,    color: "#ec4899", bg: "rgba(236,72,153,0.15)" },
};

const WEEKDAYS = ["日", "一", "二", "三", "四", "五", "六"];
const DEPT_COLORS = {
  "照護組": "#0ea5e9", "教保組": "#10b981",
  "行政組": "#f59e0b", "護理組": "#ec4899",
};

// ─── Mock 資料 ─────────────────────────────────────────────────────────────────
function mockEmployees() {
  return [
    { id: "EMP001", name: "陳美華", dept: "照護組", defaultShift: "早" },
    { id: "EMP002", name: "林志明", dept: "教保組", defaultShift: "中" },
    { id: "EMP003", name: "王淑芬", dept: "護理組", defaultShift: "早" },
    { id: "EMP004", name: "張建國", dept: "行政組", defaultShift: "日" },
    { id: "EMP005", name: "李雅婷", dept: "照護組", defaultShift: "晚" },
    { id: "EMP006", name: "劉俊宏", dept: "教保組", defaultShift: "早" },
    { id: "EMP007", name: "黃秀蘭", dept: "護理組", defaultShift: "中" },
    { id: "EMP008", name: "吳建志", dept: "照護組", defaultShift: "日" },
  ];
}

function generateMockSchedule(year, month, employees) {
  const schedule = {};
  employees.forEach((emp) => {
    schedule[emp.id] = {};
    const daysInMonth = new Date(year, month, 0).getDate();
    for (let d = 1; d <= daysInMonth; d++) {
      const date = `${year}-${String(month).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
      const dow = new Date(date).getDay();
      // 週日休息
      if (dow === 0) {
        schedule[emp.id][date] = "休";
      } else {
        schedule[emp.id][date] = emp.defaultShift;
      }
    }
  });
  return schedule;
}

// ─── 工具函數 ─────────────────────────────────────────────────────────────────
function getDaysInMonth(year, month) {
  return new Date(year, month, 0).getDate();
}

function getFirstDayOfMonth(year, month) {
  return new Date(year, month - 1, 1).getDay();
}

function formatDate(year, month, day) {
  return `${year}-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
}

function parseTime(timeStr) {
  if (!timeStr) return null;
  const [h, m] = timeStr.split(":").map(Number);
  return h * 60 + m;
}

function getLateness(punchInStr, shiftStart) {
  if (!punchInStr || !shiftStart) return 0;
  const punchMinutes = parseTime(new Date(punchInStr).toLocaleTimeString("zh-TW", { hour: "2-digit", minute: "2-digit", hour12: false }));
  const shiftMinutes = parseTime(shiftStart);
  return Math.max(0, punchMinutes - shiftMinutes - 5); // 5分鐘寬限
}

// ─── 主元件 ──────────────────────────────────────────────────────────────────
export default function ScheduleModule({ API_BASE = "" }) {
  const now = new Date();
  const [year, setYear] = useState(now.getFullYear());
  const [month, setMonth] = useState(now.getMonth() + 1);
  const [employees, setEmployees] = useState([]);
  const [schedule, setSchedule] = useState({});
  const [loading, setLoading] = useState(true);
  const [view, setView] = useState("calendar"); // calendar | table | stats
  const [selectedCell, setSelectedCell] = useState(null); // { empId, date }
  const [filterDept, setFilterDept] = useState("all");
  const [saving, setSaving] = useState(false);
  const [notification, setNotification] = useState(null);
  const [batchMode, setBatchMode] = useState(false);
  const [batchSelected, setBatchSelected] = useState(new Set());
  const [batchShift, setBatchShift] = useState("早");

  useEffect(() => {
    load();
  }, [year, month]);

  async function load() {
    setLoading(true);
    try {
      const emps = mockEmployees();
      setEmployees(emps);
      const sched = generateMockSchedule(year, month, emps);
      setSchedule(sched);
    } catch {
      const emps = mockEmployees();
      setEmployees(emps);
      setSchedule(generateMockSchedule(year, month, emps));
    }
    setLoading(false);
  }

  // 更新單一班別
  async function updateShift(empId, date, shift) {
    setSchedule((prev) => ({
      ...prev,
      [empId]: { ...(prev[empId] || {}), [date]: shift },
    }));
    try {
      if (API_BASE) {
        await fetch(`${API_BASE}/api/schedule`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ employee_id: empId, date, shift }),
        });
      }
    } catch {
      showNotif("⚠ 儲存失敗", "#ef4444");
    }
    setSelectedCell(null);
  }

  // 批量設定
  async function applyBatch() {
    if (batchSelected.size === 0) return;
    setSaving(true);
    const updates = [];
    batchSelected.forEach((key) => {
      const [empId, date] = key.split("|");
      updates.push({ empId, date, shift: batchShift });
    });
    const newSchedule = { ...schedule };
    updates.forEach(({ empId, date, shift }) => {
      newSchedule[empId] = { ...(newSchedule[empId] || {}), [date]: shift };
    });
    setSchedule(newSchedule);
    setBatchSelected(new Set());
    setBatchMode(false);
    showNotif(`✓ 已更新 ${updates.length} 個班別`, "#10b981");
    setSaving(false);
  }

  // 一鍵套用預設排班（跟上月一樣）
  async function applyDefaultSchedule() {
    const emps = employees.filter((e) => filterDept === "all" || e.dept === filterDept);
    const daysInMonth = getDaysInMonth(year, month);
    const newSchedule = { ...schedule };
    emps.forEach((emp) => {
      newSchedule[emp.id] = {};
      for (let d = 1; d <= daysInMonth; d++) {
        const date = formatDate(year, month, d);
        const dow = new Date(date).getDay();
        newSchedule[emp.id][date] = dow === 0 ? "休" : emp.defaultShift;
      }
    });
    setSchedule(newSchedule);
    showNotif("✓ 已套用預設排班", "#10b981");
  }

  function showNotif(msg, color) {
    setNotification({ msg, color });
    setTimeout(() => setNotification(null), 3000);
  }

  function prevMonth() {
    if (month === 1) { setYear((y) => y - 1); setMonth(12); }
    else setMonth((m) => m - 1);
  }
  function nextMonth() {
    if (month === 12) { setYear((y) => y + 1); setMonth(1); }
    else setMonth((m) => m + 1);
  }

  const filteredEmps = employees.filter((e) => filterDept === "all" || e.dept === filterDept);
  const daysInMonth = getDaysInMonth(year, month);
  const firstDay = getFirstDayOfMonth(year, month);
  const today = new Date().toISOString().split("T")[0];

  // 統計
  const stats = {};
  filteredEmps.forEach((emp) => {
    const empSchedule = schedule[emp.id] || {};
    stats[emp.id] = { 早: 0, 中: 0, 晚: 0, 日: 0, 休: 0, 假: 0, total: 0 };
    Object.values(empSchedule).forEach((s) => {
      if (stats[emp.id][s] !== undefined) stats[emp.id][s]++;
      if (s !== "休" && s !== "假") stats[emp.id].total++;
    });
  });

  if (loading) return (
    <div style={sty.root}>
      <div style={{ textAlign: "center", padding: "80px 0", color: "#94a3b8" }}>載入排班資料中…</div>
    </div>
  );

  return (
    <div style={sty.root}>
      {notification && (
        <div style={{ ...sty.notif, background: notification.color }}>{notification.msg}</div>
      )}

      {/* Header */}
      <div style={sty.header}>
        <div>
          <div style={sty.title}>📅 排班管理</div>
          <div style={sty.subtitle}>{year} 年 {month} 月 · {filteredEmps.length} 位員工</div>
        </div>
        <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
          {/* 月份切換 */}
          <div style={sty.monthNav}>
            <button style={sty.navBtn} onClick={prevMonth}>◀</button>
            <span style={sty.monthLabel}>{year}/{String(month).padStart(2, "0")}</span>
            <button style={sty.navBtn} onClick={nextMonth}>▶</button>
          </div>
          <button style={sty.outlineBtn} onClick={applyDefaultSchedule}>⚡ 套用預設</button>
          <button
            style={{ ...sty.outlineBtn, ...(batchMode ? { borderColor: "#f59e0b", color: "#f59e0b" } : {}) }}
            onClick={() => { setBatchMode((b) => !b); setBatchSelected(new Set()); }}
          >
            {batchMode ? "✗ 取消批量" : "⊞ 批量設定"}
          </button>
        </div>
      </div>

      {/* 批量設定工具列 */}
      {batchMode && (
        <div style={sty.batchBar}>
          <span style={{ color: "#f59e0b", fontSize: 13 }}>
            已選 {batchSelected.size} 格 · 點擊班別格子來選取
          </span>
          <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
            <span style={{ color: "#94a3b8", fontSize: 13 }}>設為：</span>
            {Object.entries(SHIFT_TYPES).map(([key, val]) => (
              <button
                key={key}
                style={{
                  ...sty.shiftPill,
                  background: batchShift === key ? val.bg : "rgba(255,255,255,0.04)",
                  color: batchShift === key ? val.color : "#64748b",
                  borderColor: batchShift === key ? val.color : "rgba(255,255,255,0.12)",
                }}
                onClick={() => setBatchShift(key)}
              >
                {key} {val.label}
              </button>
            ))}
            <button
              style={{ ...sty.btn, background: "#10b981", opacity: batchSelected.size === 0 ? 0.5 : 1 }}
              onClick={applyBatch}
              disabled={batchSelected.size === 0 || saving}
            >
              套用
            </button>
          </div>
        </div>
      )}

      {/* Tab 切換 */}
      <div style={sty.tabRow}>
        {[
          { key: "calendar", label: "📆 月曆視圖" },
          { key: "table",    label: "📋 表格視圖" },
          { key: "stats",    label: "📊 統計報表" },
        ].map((t) => (
          <button
            key={t.key}
            style={{ ...sty.tab, ...(view === t.key ? sty.tabActive : {}) }}
            onClick={() => setView(t.key)}
          >
            {t.label}
          </button>
        ))}

        {/* 部門篩選 */}
        <div style={{ marginLeft: "auto", display: "flex", gap: 6 }}>
          {["all", ...Object.keys(DEPT_COLORS)].map((d) => (
            <button
              key={d}
              style={{
                ...sty.filterBtn,
                borderColor: filterDept === d ? (DEPT_COLORS[d] || "#10b981") : "rgba(255,255,255,0.08)",
                color: filterDept === d ? (DEPT_COLORS[d] || "#10b981") : "#64748b",
              }}
              onClick={() => setFilterDept(d)}
            >
              {d === "all" ? "全部" : d}
            </button>
          ))}
        </div>
      </div>

      {/* 班別圖例 */}
      <div style={sty.legend}>
        {Object.entries(SHIFT_TYPES).map(([key, val]) => (
          <div key={key} style={sty.legendItem}>
            <span style={{ ...sty.legendDot, background: val.bg, color: val.color, border: `1px solid ${val.color}40` }}>
              {key}
            </span>
            <span style={{ color: "#64748b", fontSize: 12 }}>{val.label} {val.start ? `${val.start}~${val.end}` : ""}</span>
          </div>
        ))}
      </div>

      {/* 月曆視圖 */}
      {view === "calendar" && (
        <CalendarView
          year={year} month={month} employees={filteredEmps}
          schedule={schedule} today={today}
          selectedCell={selectedCell} setSelectedCell={setSelectedCell}
          onUpdateShift={updateShift}
          batchMode={batchMode} batchSelected={batchSelected} setBatchSelected={setBatchSelected}
          daysInMonth={daysInMonth} firstDay={firstDay}
        />
      )}

      {/* 表格視圖 */}
      {view === "table" && (
        <TableView
          year={year} month={month} employees={filteredEmps}
          schedule={schedule} today={today}
          onUpdateShift={updateShift} daysInMonth={daysInMonth}
        />
      )}

      {/* 統計 */}
      {view === "stats" && (
        <StatsView employees={filteredEmps} stats={stats} month={month} />
      )}
    </div>
  );
}

// ─── 月曆視圖 ────────────────────────────────────────────────────────────────
function CalendarView({ year, month, employees, schedule, today, selectedCell, setSelectedCell, onUpdateShift, batchMode, batchSelected, setBatchSelected, daysInMonth, firstDay }) {
  // 月曆格子
  const calDays = [];
  for (let i = 0; i < firstDay; i++) calDays.push(null);
  for (let d = 1; d <= daysInMonth; d++) calDays.push(d);

  return (
    <div style={sty.calendarContainer}>
      {/* 週標頭 */}
      <div style={sty.calWeekHeader}>
        {WEEKDAYS.map((wd, i) => (
          <div key={wd} style={{ ...sty.calWeekDay, color: i === 0 ? "#ef4444" : i === 6 ? "#60a5fa" : "#64748b" }}>
            {wd}
          </div>
        ))}
      </div>

      {/* 日期格子 */}
      <div style={sty.calGrid}>
        {calDays.map((day, idx) => {
          if (!day) return <div key={`empty-${idx}`} style={sty.calEmpty} />;
          const date = formatDate(year, month, day);
          const isToday = date === today;
          const dow = new Date(date).getDay();
          const isWeekend = dow === 0 || dow === 6;

          return (
            <div key={date} style={{
              ...sty.calDay,
              background: isToday ? "rgba(16,185,129,0.08)" : "rgba(255,255,255,0.02)",
              borderColor: isToday ? "#10b981" : "rgba(255,255,255,0.06)",
            }}>
              <div style={{
                fontSize: 13, fontWeight: isToday ? 800 : 500,
                color: isToday ? "#10b981" : isWeekend ? (dow === 0 ? "#ef4444" : "#60a5fa") : "#94a3b8",
                marginBottom: 8,
              }}>
                {day}
                {isToday && <span style={{ fontSize: 9, marginLeft: 4, color: "#10b981" }}>今</span>}
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: 3 }}>
                {employees.map((emp) => {
                  const shift = schedule[emp.id]?.[date] || "—";
                  const shiftInfo = SHIFT_TYPES[shift];
                  const cellKey = `${emp.id}|${date}`;
                  const isSelected = batchSelected.has(cellKey);

                  return (
                    <div
                      key={emp.id}
                      style={{
                        ...sty.calCell,
                        background: isSelected ? "rgba(245,158,11,0.3)" : (shiftInfo?.bg || "transparent"),
                        color: isSelected ? "#f59e0b" : (shiftInfo?.color || "#64748b"),
                        borderColor: isSelected ? "#f59e0b" : `${shiftInfo?.color || "#64748b"}30`,
                        cursor: "pointer",
                      }}
                      onClick={() => {
                        if (batchMode) {
                          setBatchSelected((prev) => {
                            const next = new Set(prev);
                            if (next.has(cellKey)) next.delete(cellKey);
                            else next.add(cellKey);
                            return next;
                          });
                        } else {
                          setSelectedCell(selectedCell?.empId === emp.id && selectedCell?.date === date ? null : { empId: emp.id, date });
                        }
                      }}
                    >
                      <span style={{ fontSize: 10, fontWeight: 600 }}>{emp.name[0]}</span>
                      <span style={{ fontSize: 11, fontWeight: 700 }}>{shift}</span>
                      {selectedCell?.empId === emp.id && selectedCell?.date === date && !batchMode && (
                        <ShiftPicker
                          currentShift={shift}
                          onSelect={(s) => onUpdateShift(emp.id, date, s)}
                          onClose={() => setSelectedCell(null)}
                        />
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ─── 表格視圖 ────────────────────────────────────────────────────────────────
function TableView({ year, month, employees, schedule, today, onUpdateShift, daysInMonth }) {
  const [editing, setEditing] = useState(null);
  const days = Array.from({ length: daysInMonth }, (_, i) => i + 1);

  return (
    <div style={{ overflowX: "auto" }}>
      <table style={{ ...sty.table, minWidth: daysInMonth * 46 + 160 }}>
        <thead>
          <tr>
            <th style={{ ...sty.th, position: "sticky", left: 0, background: "#0d1b2a", minWidth: 120, zIndex: 2 }}>
              員工
            </th>
            {days.map((d) => {
              const date = formatDate(year, month, d);
              const dow = new Date(date).getDay();
              const isToday = date === today;
              return (
                <th key={d} style={{
                  ...sty.th, minWidth: 40, textAlign: "center",
                  color: isToday ? "#10b981" : dow === 0 ? "#ef4444" : dow === 6 ? "#60a5fa" : "#64748b",
                  background: isToday ? "rgba(16,185,129,0.08)" : "transparent",
                }}>
                  <div>{d}</div>
                  <div style={{ fontSize: 9, fontWeight: 400 }}>{WEEKDAYS[dow]}</div>
                </th>
              );
            })}
            <th style={sty.th}>班數</th>
          </tr>
        </thead>
        <tbody>
          {employees.map((emp) => {
            const empSched = schedule[emp.id] || {};
            const workDays = Object.values(empSched).filter((s) => s !== "休" && s !== "假").length;
            return (
              <tr key={emp.id}>
                <td style={{
                  ...sty.td, position: "sticky", left: 0, background: "#0d1b2a", zIndex: 1,
                  borderRight: "1px solid rgba(255,255,255,0.08)",
                }}>
                  <div style={{ fontWeight: 600, color: "#e2e8f0", fontSize: 13 }}>{emp.name}</div>
                  <div style={{ fontSize: 11, color: DEPT_COLORS[emp.dept] }}>{emp.dept}</div>
                </td>
                {days.map((d) => {
                  const date = formatDate(year, month, d);
                  const shift = empSched[date] || "休";
                  const info = SHIFT_TYPES[shift];
                  const cellKey = `${emp.id}|${date}`;
                  const isEditing = editing === cellKey;
                  const isToday = date === today;

                  return (
                    <td key={d} style={{
                      ...sty.td, textAlign: "center", padding: "4px",
                      background: isToday ? "rgba(16,185,129,0.05)" : "transparent",
                      position: "relative",
                    }}>
                      <div
                        style={{
                          display: "inline-flex", alignItems: "center", justifyContent: "center",
                          width: 32, height: 32, borderRadius: 6,
                          background: info?.bg || "transparent",
                          color: info?.color || "#64748b",
                          fontSize: 13, fontWeight: 700,
                          cursor: "pointer",
                          border: `1px solid ${info?.color || "#64748b"}30`,
                        }}
                        onClick={() => setEditing(isEditing ? null : cellKey)}
                      >
                        {shift}
                      </div>
                      {isEditing && (
                        <ShiftPicker
                          currentShift={shift}
                          onSelect={(s) => { onUpdateShift(emp.id, date, s); setEditing(null); }}
                          onClose={() => setEditing(null)}
                        />
                      )}
                    </td>
                  );
                })}
                <td style={{ ...sty.td, textAlign: "center", fontWeight: 700, color: "#10b981" }}>
                  {workDays}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

// ─── 統計視圖 ─────────────────────────────────────────────────────────────────
function StatsView({ employees, stats, month }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
      <div style={sty.statsGrid}>
        {employees.map((emp) => {
          const st = stats[emp.id] || {};
          return (
            <div key={emp.id} style={sty.statsCard}>
              <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 14 }}>
                <div style={{ ...sty.statsAvatar, color: DEPT_COLORS[emp.dept] }}>
                  {emp.name[0]}
                </div>
                <div>
                  <div style={{ fontWeight: 700, color: "#e2e8f0" }}>{emp.name}</div>
                  <div style={{ fontSize: 12, color: DEPT_COLORS[emp.dept] }}>{emp.dept}</div>
                </div>
                <div style={{ marginLeft: "auto", textAlign: "right" }}>
                  <div style={{ fontSize: 22, fontWeight: 800, color: "#10b981" }}>{st.total}</div>
                  <div style={{ fontSize: 11, color: "#64748b" }}>上班天數</div>
                </div>
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                {Object.entries(SHIFT_TYPES).map(([key, val]) => {
                  if (!st[key]) return null;
                  return (
                    <div key={key} style={{ display: "flex", alignItems: "center", gap: 8 }}>
                      <span style={{ ...sty.shiftPill, background: val.bg, color: val.color, borderColor: `${val.color}40`, fontSize: 12, padding: "2px 8px" }}>
                        {key} {val.label}
                      </span>
                      <div style={{ flex: 1, height: 6, borderRadius: 3, background: "rgba(255,255,255,0.06)", overflow: "hidden" }}>
                        <div style={{ height: "100%", width: `${(st[key] / 31) * 100}%`, background: val.color, borderRadius: 3, transition: "width 0.6s ease" }} />
                      </div>
                      <span style={{ color: val.color, fontWeight: 700, fontSize: 13, minWidth: 24 }}>{st[key]}</span>
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ─── 班別選擇器 ───────────────────────────────────────────────────────────────
function ShiftPicker({ currentShift, onSelect, onClose }) {
  return (
    <div style={sty.shiftPicker} onClick={(e) => e.stopPropagation()}>
      {Object.entries(SHIFT_TYPES).map(([key, val]) => (
        <button
          key={key}
          style={{
            ...sty.shiftPickerBtn,
            background: currentShift === key ? val.bg : "rgba(255,255,255,0.04)",
            color: currentShift === key ? val.color : "#94a3b8",
            borderColor: currentShift === key ? val.color : "rgba(255,255,255,0.1)",
          }}
          onClick={() => onSelect(key)}
        >
          <span style={{ fontWeight: 800, fontSize: 15 }}>{key}</span>
          <span style={{ fontSize: 10 }}>{val.label}</span>
          {val.start && <span style={{ fontSize: 9, color: "#64748b" }}>{val.start}</span>}
        </button>
      ))}
      <button style={sty.closePickerBtn} onClick={onClose}>取消</button>
    </div>
  );
}

// ─── 樣式 ────────────────────────────────────────────────────────────────────
const sty = {
  root: {
    background: "#0a0f1e",
    minHeight: "100vh",
    fontFamily: "'Noto Sans TC', 'PingFang TC', sans-serif",
    color: "#e2e8f0",
    padding: "24px 32px",
  },
  notif: {
    position: "fixed", top: 0, left: 0, right: 0, zIndex: 9999,
    padding: "12px 24px", textAlign: "center",
    color: "#fff", fontWeight: 700, fontSize: 15,
  },
  header: {
    display: "flex", justifyContent: "space-between", alignItems: "flex-start",
    marginBottom: 20,
  },
  title: { fontSize: 24, fontWeight: 800, color: "#f0f9ff", letterSpacing: "-0.5px" },
  subtitle: { fontSize: 13, color: "#64748b", marginTop: 4 },
  monthNav: {
    display: "flex", alignItems: "center", gap: 10,
    background: "rgba(255,255,255,0.06)",
    border: "1px solid rgba(255,255,255,0.12)",
    borderRadius: 10, padding: "6px 12px",
  },
  navBtn: {
    background: "none", border: "none", color: "#94a3b8",
    cursor: "pointer", fontSize: 14, padding: "2px 6px",
  },
  monthLabel: { color: "#e2e8f0", fontWeight: 700, minWidth: 70, textAlign: "center" },
  outlineBtn: {
    padding: "8px 16px", borderRadius: 8,
    background: "transparent", border: "1px solid rgba(255,255,255,0.12)",
    color: "#94a3b8", fontSize: 13, cursor: "pointer", fontFamily: "inherit",
  },
  btn: {
    padding: "8px 16px", borderRadius: 8, border: "none",
    color: "#fff", fontWeight: 700, fontSize: 13, cursor: "pointer", fontFamily: "inherit",
  },
  batchBar: {
    display: "flex", alignItems: "center", justifyContent: "space-between",
    padding: "12px 20px", borderRadius: 10, marginBottom: 16,
    background: "rgba(245,158,11,0.08)", border: "1px solid rgba(245,158,11,0.3)",
  },
  tabRow: {
    display: "flex", alignItems: "center", gap: 6,
    marginBottom: 14, flexWrap: "wrap",
  },
  tab: {
    padding: "8px 16px", borderRadius: 8,
    background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)",
    color: "#64748b", fontSize: 13, cursor: "pointer", fontFamily: "inherit",
  },
  tabActive: {
    background: "rgba(16,185,129,0.15)", borderColor: "#10b981", color: "#10b981",
  },
  filterBtn: {
    padding: "6px 12px", borderRadius: 8,
    background: "rgba(255,255,255,0.04)", border: "1px solid",
    fontSize: 12, cursor: "pointer", fontFamily: "inherit",
  },
  legend: {
    display: "flex", gap: 16, marginBottom: 16, flexWrap: "wrap",
  },
  legendItem: { display: "flex", alignItems: "center", gap: 6 },
  legendDot: {
    padding: "2px 8px", borderRadius: 6, fontSize: 13, fontWeight: 700, border: "1px solid",
  },
  calendarContainer: {},
  calWeekHeader: {
    display: "grid", gridTemplateColumns: "repeat(7, 1fr)",
    marginBottom: 4,
  },
  calWeekDay: {
    textAlign: "center", padding: "8px 0", fontSize: 12, fontWeight: 700,
  },
  calGrid: {
    display: "grid", gridTemplateColumns: "repeat(7, 1fr)", gap: 4,
  },
  calEmpty: { minHeight: 120 },
  calDay: {
    minHeight: 120, borderRadius: 8, padding: "8px",
    border: "1px solid", transition: "border-color 0.2s",
  },
  calCell: {
    display: "flex", alignItems: "center", gap: 4,
    padding: "3px 6px", borderRadius: 5,
    fontSize: 12, cursor: "pointer",
    border: "1px solid", position: "relative",
    userSelect: "none",
  },
  shiftPicker: {
    position: "absolute", top: "100%", left: 0, zIndex: 100,
    background: "#1a2744", border: "1px solid rgba(255,255,255,0.12)",
    borderRadius: 10, padding: 8,
    display: "flex", flexDirection: "column", gap: 4,
    boxShadow: "0 8px 32px rgba(0,0,0,0.6)",
    minWidth: 120,
  },
  shiftPickerBtn: {
    display: "flex", flexDirection: "column", alignItems: "flex-start",
    padding: "8px 12px", borderRadius: 6, border: "1px solid",
    cursor: "pointer", fontFamily: "inherit", gap: 1,
  },
  closePickerBtn: {
    padding: "6px", borderRadius: 6, border: "none",
    background: "rgba(255,255,255,0.06)", color: "#64748b",
    cursor: "pointer", fontFamily: "inherit", fontSize: 12,
    marginTop: 4,
  },
  table: { width: "100%", borderCollapse: "collapse" },
  th: {
    padding: "8px 6px",
    color: "#64748b", fontSize: 11, fontWeight: 700,
    borderBottom: "1px solid rgba(255,255,255,0.08)",
    textAlign: "left",
  },
  td: { padding: "8px 6px", borderBottom: "1px solid rgba(255,255,255,0.04)", position: "relative" },
  shiftPill: {
    padding: "3px 10px", borderRadius: 20, fontSize: 12, fontWeight: 600,
    border: "1px solid", cursor: "pointer", fontFamily: "inherit",
  },
  statsGrid: {
    display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))",
    gap: 18,
  },
  statsCard: {
    background: "linear-gradient(135deg, #0d1b2a, #111827)",
    border: "1px solid rgba(255,255,255,0.08)",
    borderRadius: 14, padding: "20px",
  },
  statsAvatar: {
    width: 40, height: 40, borderRadius: "50%",
    background: "rgba(255,255,255,0.06)",
    display: "flex", alignItems: "center", justifyContent: "center",
    fontSize: 18, fontWeight: 700,
  },
};
