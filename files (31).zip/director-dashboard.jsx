/**
 * director-dashboard.jsx
 * 院長儀表板 — 每日開機第一眼
 * 愛心教養院考勤系統 v3.3
 */

import { useState, useEffect, useCallback } from "react";

// ─── 台灣國定假日 API ────────────────────────────────────────────────────────
async function fetchTWHolidays(year) {
  try {
    const res = await fetch(
      `https://cdn.jsdelivr.net/gh/ruyut/TaiwanCalendar/data/${year}.json`
    );
    const data = await res.json();
    const holidays = {};
    data.forEach((d) => {
      if (d.isHoliday) holidays[d.date] = d.description || "國定假日";
    });
    return holidays;
  } catch {
    return {};
  }
}

// ─── 工具函數 ────────────────────────────────────────────────────────────────
function today() {
  return new Date().toISOString().split("T")[0];
}
function formatTime(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleTimeString("zh-TW", {
    hour: "2-digit",
    minute: "2-digit",
  });
}
function formatDate(d) {
  return new Date(d).toLocaleDateString("zh-TW", {
    year: "numeric",
    month: "long",
    day: "numeric",
    weekday: "long",
  });
}
function weekLabel(offset) {
  const d = new Date();
  d.setDate(d.getDate() - offset);
  return (d.getMonth() + 1) + "/" + d.getDate();
}

// ─── Mock 資料（生產環境替換為 API 呼叫）────────────────────────────────────
function mockDashboardData() {
  const names = ["陳美華", "林志明", "王淑芬", "張建國", "李雅婷", "劉俊宏", "黃秀蘭", "吳建志"];
  const depts = ["照護組", "教保組", "行政組", "護理組"];
  const shifts = { "早班": "07:00", "中班": "15:00", "晚班": "23:00" };
  
  const employees = names.map((name, i) => ({
    id: `EMP${String(i + 1).padStart(3, "0")}`,
    name,
    dept: depts[i % depts.length],
    shift: Object.keys(shifts)[i % 3],
    shiftStart: Object.values(shifts)[i % 3],
  }));

  const punchData = employees.map((e, i) => {
    const hasAbnormal = i === 2 || i === 5;
    const isAbsent = i === 7;
    const onLeave = i === 6;
    if (isAbsent) return { ...e, status: "absent", punchIn: null, punchOut: null };
    if (onLeave) return { ...e, status: "leave", punchIn: null, punchOut: null };
    const [h, m] = e.shiftStart.split(":").map(Number);
    const delay = hasAbnormal ? Math.floor(Math.random() * 30) + 10 : Math.floor(Math.random() * 5);
    const punchIn = new Date();
    punchIn.setHours(h, m + delay, 0);
    return {
      ...e,
      status: hasAbnormal ? "late" : "normal",
      punchIn: punchIn.toISOString(),
      punchOut: i < 3 ? new Date(punchIn.getTime() + 8 * 3600000).toISOString() : null,
      delayMinutes: hasAbnormal ? delay : 0,
    };
  });

  const pending = {
    leaves: [
      { id: "L001", name: "陳美華", type: "病假", days: 1, date: today(), submitted: "10分鐘前" },
      { id: "L002", name: "吳建志", type: "年假", days: 2, date: today(), submitted: "2小時前" },
    ],
    overtime: [
      { id: "O001", name: "林志明", hours: 3, date: today(), reason: "個案緊急照護", submitted: "昨天" },
    ],
  };

  const weekTrend = Array.from({ length: 7 }, (_, i) => ({
    label: weekLabel(6 - i),
    present: Math.floor(Math.random() * 3) + 5,
    total: 8,
    absent: Math.floor(Math.random() * 2),
  }));

  const stats = {
    total: employees.length,
    present: punchData.filter((p) => p.status === "normal" || p.status === "late").length,
    absent: punchData.filter((p) => p.status === "absent").length,
    onLeave: punchData.filter((p) => p.status === "leave").length,
    late: punchData.filter((p) => p.status === "late").length,
  };

  return { employees, punchData, pending, weekTrend, stats };
}

// ─── 顏色 Map ────────────────────────────────────────────────────────────────
const STATUS_CONFIG = {
  normal: { label: "正常出勤", color: "#10b981", bg: "rgba(16,185,129,0.15)", icon: "✓" },
  late:   { label: "遲到",     color: "#f59e0b", bg: "rgba(245,158,11,0.15)",  icon: "⚡" },
  absent: { label: "未打卡",   color: "#ef4444", bg: "rgba(239,68,68,0.15)",   icon: "✗" },
  leave:  { label: "請假中",   color: "#6366f1", bg: "rgba(99,102,241,0.15)",  icon: "◈" },
};

const DEPT_COLORS = {
  "照護組": "#0ea5e9",
  "教保組": "#10b981",
  "行政組": "#f59e0b",
  "護理組": "#ec4899",
};

// ─── 主元件 ─────────────────────────────────────────────────────────────────
export default function DirectorDashboard({ onApprove, onReject, API_BASE = "" }) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [selectedTab, setSelectedTab] = useState("overview");
  const [holidays, setHolidays] = useState({});
  const [lastUpdate, setLastUpdate] = useState(new Date());
  const [approving, setApproving] = useState(null);
  const [notification, setNotification] = useState(null);
  const [currentTime, setCurrentTime] = useState(new Date());

  // 載入資料
  const loadData = useCallback(async () => {
    try {
      let dashData;
      if (API_BASE) {
        const res = await fetch(`${API_BASE}/api/dashboard?date=${today()}`);
        dashData = await res.json();
      } else {
        dashData = mockDashboardData();
      }
      setData(dashData);
      setLastUpdate(new Date());
    } catch {
      setData(mockDashboardData());
    } finally {
      setLoading(false);
    }
  }, [API_BASE]);

  useEffect(() => {
    loadData();
    fetchTWHolidays(new Date().getFullYear()).then(setHolidays);
    const interval = setInterval(loadData, 60000); // 每分鐘更新
    const clock = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => { clearInterval(interval); clearInterval(clock); };
  }, [loadData]);

  // 審核
  const handleApprove = async (type, id, action) => {
    setApproving(id);
    try {
      if (API_BASE) {
        await fetch(`${API_BASE}/api/${type}/${id}`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ status: action === "approve" ? "approved" : "rejected" }),
        });
      }
      await loadData();
      showNotif(action === "approve" ? "✓ 已核准" : "✗ 已駁回", action === "approve" ? "#10b981" : "#ef4444");
      if (onApprove) onApprove(type, id, action);
    } catch {
      showNotif("⚠ 操作失敗，請重試", "#f59e0b");
    } finally {
      setApproving(null);
    }
  };

  function showNotif(msg, color) {
    setNotification({ msg, color });
    setTimeout(() => setNotification(null), 3000);
  }

  const todayHoliday = holidays[today()];

  if (loading) return <LoadingScreen />;
  if (!data) return null;

  const { stats, punchData, pending, weekTrend } = data;
  const attendanceRate = Math.round((stats.present / stats.total) * 100);

  return (
    <div style={styles.root}>
      {/* 頂部通知欄 */}
      {notification && (
        <div style={{ ...styles.notifBar, background: notification.color }}>
          {notification.msg}
        </div>
      )}

      {/* 頂部 Header */}
      <header style={styles.header}>
        <div style={styles.headerLeft}>
          <div style={styles.logo}>🏥</div>
          <div>
            <div style={styles.headerTitle}>愛心教養院</div>
            <div style={styles.headerSub}>考勤管理系統 — 院長儀表板</div>
          </div>
        </div>
        <div style={styles.headerRight}>
          {todayHoliday && (
            <div style={styles.holidayBadge}>🎌 {todayHoliday}</div>
          )}
          <div style={styles.clockBlock}>
            <div style={styles.clockTime}>
              {currentTime.toLocaleTimeString("zh-TW", { hour: "2-digit", minute: "2-digit", second: "2-digit" })}
            </div>
            <div style={styles.clockDate}>{formatDate(today())}</div>
          </div>
          <button style={styles.refreshBtn} onClick={loadData} title="重新整理">
            ↺
          </button>
        </div>
      </header>

      {/* 分頁 Tab */}
      <nav style={styles.tabNav}>
        {[
          { key: "overview", label: "今日總覽", icon: "◎" },
          { key: "punch",    label: "出勤明細", icon: "⏱" },
          { key: "pending",  label: `待審核 ${pending.leaves.length + pending.overtime.length}`, icon: "📋" },
          { key: "trend",    label: "週趨勢",   icon: "📈" },
        ].map((t) => (
          <button
            key={t.key}
            style={{ ...styles.tab, ...(selectedTab === t.key ? styles.tabActive : {}) }}
            onClick={() => setSelectedTab(t.key)}
          >
            <span style={styles.tabIcon}>{t.icon}</span>
            {t.label}
          </button>
        ))}
        <div style={styles.tabRight}>
          最後更新：{lastUpdate.toLocaleTimeString("zh-TW", { hour: "2-digit", minute: "2-digit" })}
        </div>
      </nav>

      {/* 主內容 */}
      <main style={styles.main}>
        {selectedTab === "overview" && (
          <OverviewTab stats={stats} attendanceRate={attendanceRate} punchData={punchData} pending={pending} />
        )}
        {selectedTab === "punch" && (
          <PunchTab punchData={punchData} />
        )}
        {selectedTab === "pending" && (
          <PendingTab pending={pending} onAction={handleApprove} approving={approving} />
        )}
        {selectedTab === "trend" && (
          <TrendTab weekTrend={weekTrend} stats={stats} />
        )}
      </main>
    </div>
  );
}

// ─── 今日總覽 Tab ────────────────────────────────────────────────────────────
function OverviewTab({ stats, attendanceRate, punchData, pending }) {
  const statCards = [
    { label: "今日出勤",   value: stats.present,  total: stats.total, color: "#10b981", icon: "✓", unit: "人" },
    { label: "缺席/未打卡", value: stats.absent,   total: null,        color: "#ef4444", icon: "✗", unit: "人" },
    { label: "請假中",     value: stats.onLeave,  total: null,        color: "#6366f1", icon: "◈", unit: "人" },
    { label: "遲到",       value: stats.late,     total: null,        color: "#f59e0b", icon: "⚡", unit: "人" },
  ];

  const lateEmployees = punchData.filter((p) => p.status === "late");
  const absentEmployees = punchData.filter((p) => p.status === "absent");
  const pendingCount = pending.leaves.length + pending.overtime.length;

  return (
    <div style={styles.overviewGrid}>
      {/* 統計卡片 */}
      {statCards.map((card) => (
        <StatCard key={card.label} {...card} attendanceRate={card.label === "今日出勤" ? attendanceRate : null} />
      ))}

      {/* 出勤率圓環 */}
      <div style={{ ...styles.card, gridColumn: "1 / 3", display: "flex", alignItems: "center", gap: 32 }}>
        <RingChart value={attendanceRate} size={120} />
        <div>
          <div style={styles.cardTitle}>今日出勤率</div>
          <div style={{ fontSize: 42, fontWeight: 800, color: attendanceRate >= 80 ? "#10b981" : "#ef4444" }}>
            {attendanceRate}%
          </div>
          <div style={{ color: "#94a3b8", fontSize: 13, marginTop: 4 }}>
            {stats.total} 位員工中，{stats.present} 位已出勤
          </div>
        </div>
        <div style={{ marginLeft: "auto" }}>
          {[
            { label: "出勤", count: stats.present, color: "#10b981" },
            { label: "請假", count: stats.onLeave, color: "#6366f1" },
            { label: "缺席", count: stats.absent,  color: "#ef4444" },
            { label: "遲到", count: stats.late,    color: "#f59e0b" },
          ].map((item) => (
            <div key={item.label} style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
              <div style={{ width: 10, height: 10, borderRadius: "50%", background: item.color }} />
              <span style={{ color: "#94a3b8", fontSize: 13 }}>{item.label}</span>
              <span style={{ color: "#e2e8f0", fontWeight: 700, marginLeft: "auto", paddingLeft: 16 }}>
                {item.count} 人
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* 待處理事項 */}
      <div style={{ ...styles.card, gridColumn: "3 / 5" }}>
        <div style={styles.cardTitle}>⚡ 待院長處理</div>
        {pendingCount === 0 ? (
          <div style={{ color: "#10b981", textAlign: "center", padding: "24px 0", fontSize: 14 }}>
            ✓ 目前無待審事項
          </div>
        ) : (
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            {pending.leaves.map((l) => (
              <div key={l.id} style={styles.pendingItem}>
                <span style={{ fontSize: 20 }}>📋</span>
                <div style={{ flex: 1 }}>
                  <div style={{ color: "#e2e8f0", fontWeight: 600, fontSize: 14 }}>{l.name} — {l.type}</div>
                  <div style={{ color: "#94a3b8", fontSize: 12 }}>{l.days} 天 · {l.submitted}</div>
                </div>
                <div style={styles.urgentDot} />
              </div>
            ))}
            {pending.overtime.map((o) => (
              <div key={o.id} style={styles.pendingItem}>
                <span style={{ fontSize: 20 }}>⏱</span>
                <div style={{ flex: 1 }}>
                  <div style={{ color: "#e2e8f0", fontWeight: 600, fontSize: 14 }}>{o.name} — 加班 {o.hours}h</div>
                  <div style={{ color: "#94a3b8", fontSize: 12 }}>{o.reason} · {o.submitted}</div>
                </div>
                <div style={styles.urgentDot} />
              </div>
            ))}
          </div>
        )}
      </div>

      {/* 異常名單 */}
      {(lateEmployees.length > 0 || absentEmployees.length > 0) && (
        <div style={{ ...styles.card, gridColumn: "1 / 3" }}>
          <div style={styles.cardTitle}>🔴 今日異常名單</div>
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {lateEmployees.map((e) => (
              <AbnormalRow key={e.id} employee={e} type="late" />
            ))}
            {absentEmployees.map((e) => (
              <AbnormalRow key={e.id} employee={e} type="absent" />
            ))}
          </div>
        </div>
      )}

      {/* 部門分布 */}
      <div style={{ ...styles.card, gridColumn: "3 / 5" }}>
        <div style={styles.cardTitle}>🏢 部門出勤狀況</div>
        <DeptBreakdown punchData={punchData} />
      </div>
    </div>
  );
}

// ─── 出勤明細 Tab ────────────────────────────────────────────────────────────
function PunchTab({ punchData }) {
  const [filter, setFilter] = useState("all");

  const filtered = filter === "all" ? punchData : punchData.filter((p) => p.status === filter);

  return (
    <div style={styles.card}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
        <div style={styles.cardTitle}>📋 今日出勤明細</div>
        <div style={styles.filterGroup}>
          {[
            { key: "all",    label: "全部" },
            { key: "normal", label: "正常" },
            { key: "late",   label: "遲到" },
            { key: "absent", label: "未打卡" },
            { key: "leave",  label: "請假" },
          ].map((f) => (
            <button
              key={f.key}
              style={{ ...styles.filterBtn, ...(filter === f.key ? styles.filterBtnActive : {}) }}
              onClick={() => setFilter(f.key)}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      <table style={styles.table}>
        <thead>
          <tr>
            {["員工", "部門", "班別", "打卡上班", "打卡下班", "狀態", "備註"].map((h) => (
              <th key={h} style={styles.th}>{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {filtered.map((p) => {
            const cfg = STATUS_CONFIG[p.status];
            return (
              <tr key={p.id} style={styles.tr}>
                <td style={styles.td}>
                  <div style={{ fontWeight: 600, color: "#e2e8f0" }}>{p.name}</div>
                  <div style={{ fontSize: 11, color: "#64748b" }}>{p.id}</div>
                </td>
                <td style={styles.td}>
                  <span style={{ ...styles.deptBadge, background: `${DEPT_COLORS[p.dept]}22`, color: DEPT_COLORS[p.dept] }}>
                    {p.dept}
                  </span>
                </td>
                <td style={styles.td}>{p.shift}</td>
                <td style={styles.td}>{formatTime(p.punchIn)}</td>
                <td style={styles.td}>{formatTime(p.punchOut)}</td>
                <td style={styles.td}>
                  <span style={{ ...styles.statusBadge, background: cfg.bg, color: cfg.color }}>
                    {cfg.icon} {cfg.label}
                  </span>
                </td>
                <td style={styles.td}>
                  {p.status === "late" && (
                    <span style={{ color: "#f59e0b", fontSize: 12 }}>遲到 {p.delayMinutes} 分</span>
                  )}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

// ─── 待審核 Tab ───────────────────────────────────────────────────────────────
function PendingTab({ pending, onAction, approving }) {
  const total = pending.leaves.length + pending.overtime.length;
  
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
      {total === 0 ? (
        <div style={{ ...styles.card, textAlign: "center", padding: "60px 0", color: "#10b981" }}>
          <div style={{ fontSize: 48, marginBottom: 12 }}>✓</div>
          <div style={{ fontSize: 18, fontWeight: 600 }}>目前無待審事項</div>
          <div style={{ color: "#64748b", marginTop: 8 }}>所有請假和加班申請均已處理完畢</div>
        </div>
      ) : (
        <>
          {pending.leaves.length > 0 && (
            <div style={styles.card}>
              <div style={styles.cardTitle}>📋 待審請假申請 ({pending.leaves.length})</div>
              {pending.leaves.map((l) => (
                <ApprovalCard
                  key={l.id}
                  item={l}
                  type="leaves"
                  onAction={onAction}
                  approving={approving}
                  icon="📋"
                  detail={`${l.type} ${l.days} 天`}
                />
              ))}
            </div>
          )}
          {pending.overtime.length > 0 && (
            <div style={styles.card}>
              <div style={styles.cardTitle}>⏱ 待審加班申請 ({pending.overtime.length})</div>
              {pending.overtime.map((o) => (
                <ApprovalCard
                  key={o.id}
                  item={o}
                  type="overtime"
                  onAction={onAction}
                  approving={approving}
                  icon="⏱"
                  detail={`加班 ${o.hours} 小時 — ${o.reason}`}
                />
              ))}
            </div>
          )}
        </>
      )}
    </div>
  );
}

// ─── 週趨勢 Tab ───────────────────────────────────────────────────────────────
function TrendTab({ weekTrend, stats }) {
  const maxVal = Math.max(...weekTrend.map((d) => d.total));

  return (
    <div style={styles.card}>
      <div style={styles.cardTitle}>📈 近 7 天出勤趨勢</div>
      <div style={{ display: "flex", alignItems: "flex-end", gap: 16, height: 220, padding: "20px 0" }}>
        {weekTrend.map((d, i) => {
          const isToday = i === weekTrend.length - 1;
          const presentH = (d.present / maxVal) * 180;
          const absentH = (d.absent / maxVal) * 180;
          const rate = Math.round((d.present / d.total) * 100);
          
          return (
            <div key={i} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 6 }}>
              <div style={{ fontSize: 12, color: "#94a3b8", fontWeight: isToday ? 700 : 400 }}>
                {rate}%
              </div>
              <div style={{ width: "100%", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "flex-end", height: 180, position: "relative", gap: 2 }}>
                {d.absent > 0 && (
                  <div style={{ width: "60%", height: absentH, background: "rgba(239,68,68,0.6)", borderRadius: "4px 4px 0 0" }} />
                )}
                <div style={{
                  width: "60%",
                  height: presentH,
                  background: isToday
                    ? "linear-gradient(180deg, #10b981, #059669)"
                    : "linear-gradient(180deg, #1e40af, #1e3a8a)",
                  borderRadius: d.absent > 0 ? 0 : "4px 4px 0 0",
                  boxShadow: isToday ? "0 0 12px rgba(16,185,129,0.4)" : "none",
                  transition: "height 0.6s ease",
                }} />
              </div>
              <div style={{
                fontSize: 12,
                fontWeight: isToday ? 700 : 400,
                color: isToday ? "#10b981" : "#94a3b8",
                background: isToday ? "rgba(16,185,129,0.1)" : "transparent",
                padding: "2px 6px",
                borderRadius: 4,
              }}>
                {isToday ? "今天" : d.label}
              </div>
              <div style={{ fontSize: 11, color: "#64748b" }}>
                {d.present}/{d.total}
              </div>
            </div>
          );
        })}
      </div>
      <div style={{ display: "flex", gap: 16, marginTop: 12, justifyContent: "center" }}>
        <LegendDot color="#10b981" label="出勤（今日）" />
        <LegendDot color="#1e40af" label="出勤（過去）" />
        <LegendDot color="rgba(239,68,68,0.6)" label="缺席" />
      </div>
    </div>
  );
}

// ─── 子元件 ──────────────────────────────────────────────────────────────────
function StatCard({ label, value, total, color, icon, unit, attendanceRate }) {
  return (
    <div style={{ ...styles.card, ...styles.statCard }}>
      <div style={{ ...styles.statIcon, background: `${color}22`, color }}>{icon}</div>
      <div style={styles.statValue} data-color={color}>
        <span style={{ color, fontSize: 40, fontWeight: 800 }}>{value}</span>
        {total && <span style={{ color: "#64748b", fontSize: 20 }}>/{total}</span>}
        <span style={{ color: "#94a3b8", fontSize: 14, marginLeft: 4 }}>{unit}</span>
      </div>
      <div style={styles.statLabel}>{label}</div>
      {attendanceRate !== null && (
        <div style={{
          marginTop: 8,
          height: 4,
          borderRadius: 2,
          background: "rgba(255,255,255,0.08)",
          overflow: "hidden",
        }}>
          <div style={{
            height: "100%",
            width: `${attendanceRate}%`,
            background: color,
            borderRadius: 2,
            transition: "width 1s ease",
          }} />
        </div>
      )}
    </div>
  );
}

function RingChart({ value, size }) {
  const r = (size - 12) / 2;
  const circ = 2 * Math.PI * r;
  const offset = circ - (value / 100) * circ;
  const color = value >= 80 ? "#10b981" : value >= 60 ? "#f59e0b" : "#ef4444";

  return (
    <svg width={size} height={size} style={{ transform: "rotate(-90deg)" }}>
      <circle cx={size/2} cy={size/2} r={r} fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth={10} />
      <circle
        cx={size/2} cy={size/2} r={r}
        fill="none" stroke={color} strokeWidth={10}
        strokeDasharray={circ} strokeDashoffset={offset}
        strokeLinecap="round"
        style={{ transition: "stroke-dashoffset 1s ease" }}
      />
    </svg>
  );
}

function AbnormalRow({ employee, type }) {
  const cfg = STATUS_CONFIG[type];
  return (
    <div style={{
      display: "flex", alignItems: "center", gap: 12,
      padding: "10px 14px", borderRadius: 8,
      background: cfg.bg, border: `1px solid ${cfg.color}30`,
    }}>
      <span style={{ color: cfg.color, fontSize: 18, minWidth: 24 }}>{cfg.icon}</span>
      <div style={{ flex: 1 }}>
        <span style={{ color: "#e2e8f0", fontWeight: 600 }}>{employee.name}</span>
        <span style={{ color: "#64748b", fontSize: 12, marginLeft: 8 }}>{employee.dept} · {employee.shift}</span>
      </div>
      <span style={{ color: cfg.color, fontSize: 13, fontWeight: 600 }}>
        {cfg.label}
        {type === "late" && ` +${employee.delayMinutes}分`}
      </span>
    </div>
  );
}

function DeptBreakdown({ punchData }) {
  const depts = {};
  punchData.forEach((p) => {
    if (!depts[p.dept]) depts[p.dept] = { present: 0, total: 0 };
    depts[p.dept].total++;
    if (p.status === "normal" || p.status === "late") depts[p.dept].present++;
  });

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 12, marginTop: 8 }}>
      {Object.entries(depts).map(([dept, d]) => {
        const rate = Math.round((d.present / d.total) * 100);
        const color = DEPT_COLORS[dept] || "#94a3b8";
        return (
          <div key={dept}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
              <span style={{ color: "#e2e8f0", fontSize: 13, fontWeight: 600 }}>{dept}</span>
              <span style={{ color, fontSize: 13 }}>{d.present}/{d.total} 人 ({rate}%)</span>
            </div>
            <div style={{ height: 6, borderRadius: 3, background: "rgba(255,255,255,0.06)" }}>
              <div style={{
                height: "100%", width: `${rate}%`,
                background: color, borderRadius: 3,
                transition: "width 1s ease",
              }} />
            </div>
          </div>
        );
      })}
    </div>
  );
}

function ApprovalCard({ item, type, onAction, approving, icon, detail }) {
  const isLoading = approving === item.id;
  return (
    <div style={{
      display: "flex", alignItems: "center", gap: 16,
      padding: "16px 20px", borderRadius: 10,
      background: "rgba(255,255,255,0.04)",
      border: "1px solid rgba(255,255,255,0.08)",
      marginTop: 12,
    }}>
      <span style={{ fontSize: 24 }}>{icon}</span>
      <div style={{ flex: 1 }}>
        <div style={{ color: "#e2e8f0", fontWeight: 700, fontSize: 15 }}>{item.name}</div>
        <div style={{ color: "#94a3b8", fontSize: 13, marginTop: 2 }}>{detail}</div>
        <div style={{ color: "#64748b", fontSize: 11, marginTop: 2 }}>申請時間：{item.submitted}</div>
      </div>
      <div style={{ display: "flex", gap: 8 }}>
        <button
          style={{ ...styles.approveBtn, background: "#10b981" }}
          onClick={() => onAction(type, item.id, "approve")}
          disabled={isLoading}
        >
          {isLoading ? "..." : "✓ 核准"}
        </button>
        <button
          style={{ ...styles.approveBtn, background: "#ef4444" }}
          onClick={() => onAction(type, item.id, "reject")}
          disabled={isLoading}
        >
          {isLoading ? "..." : "✗ 駁回"}
        </button>
      </div>
    </div>
  );
}

function LegendDot({ color, label }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
      <div style={{ width: 12, height: 12, borderRadius: 3, background: color }} />
      <span style={{ color: "#94a3b8", fontSize: 12 }}>{label}</span>
    </div>
  );
}

function LoadingScreen() {
  return (
    <div style={{ ...styles.root, display: "flex", alignItems: "center", justifyContent: "center" }}>
      <div style={{ textAlign: "center" }}>
        <div style={{ fontSize: 48, marginBottom: 16, animation: "pulse 1.5s infinite" }}>🏥</div>
        <div style={{ color: "#94a3b8", fontSize: 16 }}>載入院長儀表板中…</div>
      </div>
    </div>
  );
}

// ─── 樣式 ────────────────────────────────────────────────────────────────────
const styles = {
  root: {
    minHeight: "100vh",
    background: "#0a0f1e",
    fontFamily: "'Noto Sans TC', 'PingFang TC', sans-serif",
    color: "#e2e8f0",
  },
  notifBar: {
    position: "fixed", top: 0, left: 0, right: 0, zIndex: 9999,
    padding: "12px 24px", textAlign: "center",
    color: "#fff", fontWeight: 700, fontSize: 15,
    animation: "slideDown 0.3s ease",
  },
  header: {
    display: "flex", justifyContent: "space-between", alignItems: "center",
    padding: "20px 32px",
    background: "linear-gradient(135deg, #0d1b2a 0%, #1a2744 100%)",
    borderBottom: "1px solid rgba(255,255,255,0.08)",
    boxShadow: "0 4px 24px rgba(0,0,0,0.4)",
  },
  headerLeft: { display: "flex", alignItems: "center", gap: 16 },
  logo: { fontSize: 36, filter: "drop-shadow(0 0 12px rgba(16,185,129,0.4))" },
  headerTitle: { fontSize: 22, fontWeight: 800, color: "#f0f9ff", letterSpacing: "-0.5px" },
  headerSub: { fontSize: 12, color: "#64748b", marginTop: 2 },
  headerRight: { display: "flex", alignItems: "center", gap: 16 },
  holidayBadge: {
    padding: "6px 14px", borderRadius: 20,
    background: "rgba(251,191,36,0.15)", color: "#fbbf24",
    fontSize: 13, fontWeight: 600, border: "1px solid rgba(251,191,36,0.3)",
  },
  clockBlock: { textAlign: "right" },
  clockTime: { fontSize: 24, fontWeight: 800, color: "#e2e8f0", fontVariantNumeric: "tabular-nums" },
  clockDate: { fontSize: 11, color: "#64748b", marginTop: 2 },
  refreshBtn: {
    width: 36, height: 36, borderRadius: "50%",
    background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.12)",
    color: "#94a3b8", fontSize: 18, cursor: "pointer",
    display: "flex", alignItems: "center", justifyContent: "center",
  },
  tabNav: {
    display: "flex", alignItems: "center",
    padding: "0 32px",
    background: "#0d1b2a",
    borderBottom: "1px solid rgba(255,255,255,0.06)",
  },
  tab: {
    display: "flex", alignItems: "center", gap: 6,
    padding: "16px 20px", background: "none", border: "none",
    color: "#64748b", fontSize: 14, cursor: "pointer",
    borderBottom: "2px solid transparent", transition: "all 0.2s",
    fontFamily: "inherit",
  },
  tabActive: {
    color: "#10b981", borderBottomColor: "#10b981",
  },
  tabIcon: { fontSize: 16 },
  tabRight: { marginLeft: "auto", color: "#475569", fontSize: 11 },
  main: { padding: "28px 32px" },
  overviewGrid: {
    display: "grid",
    gridTemplateColumns: "repeat(4, 1fr)",
    gap: 20,
  },
  card: {
    background: "linear-gradient(135deg, #0d1b2a 0%, #111827 100%)",
    border: "1px solid rgba(255,255,255,0.08)",
    borderRadius: 14,
    padding: "22px 24px",
    boxShadow: "0 4px 24px rgba(0,0,0,0.3)",
  },
  cardTitle: {
    fontSize: 14, fontWeight: 700, color: "#94a3b8",
    letterSpacing: "0.05em", marginBottom: 16,
    textTransform: "uppercase",
  },
  statCard: {
    display: "flex", flexDirection: "column", alignItems: "flex-start", gap: 4,
  },
  statIcon: {
    width: 40, height: 40, borderRadius: 10,
    display: "flex", alignItems: "center", justifyContent: "center",
    fontSize: 18, fontWeight: 700, marginBottom: 8,
  },
  statValue: { display: "flex", alignItems: "baseline", gap: 2 },
  statLabel: { color: "#64748b", fontSize: 13, fontWeight: 500 },
  pendingItem: {
    display: "flex", alignItems: "center", gap: 12,
    padding: "10px 12px", borderRadius: 8,
    background: "rgba(255,255,255,0.04)",
  },
  urgentDot: {
    width: 8, height: 8, borderRadius: "50%",
    background: "#ef4444", animation: "pulse 1.5s infinite",
  },
  deptBadge: {
    padding: "3px 10px", borderRadius: 20, fontSize: 12, fontWeight: 600,
  },
  statusBadge: {
    padding: "4px 10px", borderRadius: 20, fontSize: 12, fontWeight: 600,
  },
  table: { width: "100%", borderCollapse: "collapse" },
  th: {
    textAlign: "left", padding: "10px 14px",
    color: "#64748b", fontSize: 12, fontWeight: 700,
    letterSpacing: "0.05em", textTransform: "uppercase",
    borderBottom: "1px solid rgba(255,255,255,0.08)",
  },
  tr: { borderBottom: "1px solid rgba(255,255,255,0.04)", transition: "background 0.2s" },
  td: { padding: "12px 14px", fontSize: 14 },
  filterGroup: { display: "flex", gap: 6 },
  filterBtn: {
    padding: "6px 12px", borderRadius: 6,
    background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)",
    color: "#94a3b8", fontSize: 12, cursor: "pointer", fontFamily: "inherit",
  },
  filterBtnActive: {
    background: "rgba(16,185,129,0.15)", borderColor: "#10b981", color: "#10b981",
  },
  approveBtn: {
    padding: "8px 16px", borderRadius: 8, border: "none",
    color: "#fff", fontWeight: 700, fontSize: 13, cursor: "pointer",
    fontFamily: "inherit", opacity: 1, transition: "opacity 0.2s",
  },
};
