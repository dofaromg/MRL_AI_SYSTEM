/**
 * employee-management.jsx
 * 員工管理後台 — 新增/編輯/停用員工
 * 愛心教養院考勤系統 v3.3
 */

import { useState, useEffect, useRef } from "react";

// ─── 常數 ────────────────────────────────────────────────────────────────────
const DEPARTMENTS = ["照護組", "教保組", "行政組", "護理組"];
const ROLES = ["一般員工", "組長", "副院長", "院長"];
const SHIFTS = ["早班 (07:00-15:00)", "中班 (15:00-23:00)", "晚班 (23:00-07:00)", "日班 (08:00-17:00)"];
const SHIFT_KEYS = {
  "早班 (07:00-15:00)": { key: "早班", start: "07:00", end: "15:00" },
  "中班 (15:00-23:00)": { key: "中班", start: "15:00", end: "23:00" },
  "晚班 (23:00-07:00)": { key: "晚班", start: "23:00", end: "07:00" },
  "日班 (08:00-17:00)": { key: "日班", start: "08:00", end: "17:00" },
};

const EMPTY_FORM = {
  name: "", id_number: "", phone: "", email: "",
  dept: DEPARTMENTS[0], role: "一般員工",
  shift: SHIFTS[0], hire_date: "", pin: "", base_salary: "",
  status: "active", notes: "",
};

// ─── Mock 資料 ────────────────────────────────────────────────────────────────
function mockEmployees() {
  return [
    { id: "EMP001", name: "陳美華", id_number: "A123456789", phone: "0912-345-678", email: "chen@care.org.tw", dept: "照護組", role: "組長", shift: "早班 (07:00-15:00)", hire_date: "2019-03-15", pin: "****", base_salary: 38000, status: "active", notes: "資深照護員", avatar: null },
    { id: "EMP002", name: "林志明", id_number: "B234567890", phone: "0923-456-789", email: "lin@care.org.tw", dept: "教保組", role: "一般員工", shift: "中班 (15:00-23:00)", hire_date: "2021-06-01", pin: "****", base_salary: 32000, status: "active", notes: "", avatar: null },
    { id: "EMP003", name: "王淑芬", id_number: "C345678901", phone: "0934-567-890", email: "wang@care.org.tw", dept: "護理組", role: "一般員工", shift: "早班 (07:00-15:00)", hire_date: "2020-09-10", pin: "****", base_salary: 35000, status: "active", notes: "", avatar: null },
    { id: "EMP004", name: "張建國", id_number: "D456789012", phone: "0945-678-901", email: "chang@care.org.tw", dept: "行政組", role: "組長", shift: "日班 (08:00-17:00)", hire_date: "2018-01-20", pin: "****", base_salary: 40000, status: "active", notes: "負責排班", avatar: null },
    { id: "EMP005", name: "李雅婷", id_number: "E567890123", phone: "0956-789-012", email: "li@care.org.tw", dept: "照護組", role: "一般員工", shift: "晚班 (23:00-07:00)", hire_date: "2022-03-01", pin: "****", base_salary: 33000, status: "active", notes: "", avatar: null },
    { id: "EMP006", name: "劉俊宏", id_number: "F678901234", phone: "0967-890-123", email: "liu@care.org.tw", dept: "教保組", role: "一般員工", shift: "早班 (07:00-15:00)", hire_date: "2023-07-15", pin: "****", base_salary: 31000, status: "inactive", notes: "已離職", avatar: null },
  ];
}

// ─── 工具函數 ─────────────────────────────────────────────────────────────────
function generateId(employees) {
  const nums = employees.map((e) => parseInt(e.id.replace("EMP", "")));
  return `EMP${String(Math.max(0, ...nums) + 1).padStart(3, "0")}`;
}

function generatePin() {
  return String(Math.floor(100000 + Math.random() * 900000));
}

function yearsSince(dateStr) {
  if (!dateStr) return 0;
  const diff = Date.now() - new Date(dateStr).getTime();
  return Math.floor(diff / (365.25 * 24 * 3600 * 1000));
}

function calcAnnualLeave(years) {
  if (years < 1) return 0;
  if (years < 2) return 3;
  if (years < 3) return 7;
  if (years < 5) return 10;
  if (years < 10) return 14;
  return Math.min(30, 14 + (years - 10));
}

const DEPT_COLORS = {
  "照護組": "#0ea5e9", "教保組": "#10b981",
  "行政組": "#f59e0b", "護理組": "#ec4899",
};

// ─── 主元件 ──────────────────────────────────────────────────────────────────
export default function EmployeeManagement({ API_BASE = "" }) {
  const [employees, setEmployees] = useState([]);
  const [loading, setLoading] = useState(true);
  const [view, setView] = useState("list"); // list | form | detail
  const [selectedEmployee, setSelectedEmployee] = useState(null);
  const [formData, setFormData] = useState({ ...EMPTY_FORM });
  const [formErrors, setFormErrors] = useState({});
  const [search, setSearch] = useState("");
  const [filterDept, setFilterDept] = useState("all");
  const [filterStatus, setFilterStatus] = useState("active");
  const [saving, setSaving] = useState(false);
  const [notification, setNotification] = useState(null);
  const [confirmDelete, setConfirmDelete] = useState(null);
  const [pinVisible, setPinVisible] = useState({});
  const fileInputRef = useRef(null);
  const [avatarPreview, setAvatarPreview] = useState(null);

  // 載入
  useEffect(() => {
    loadEmployees();
  }, []);

  async function loadEmployees() {
    setLoading(true);
    try {
      if (API_BASE) {
        const res = await fetch(`${API_BASE}/api/employees`);
        const data = await res.json();
        setEmployees(data.employees || []);
      } else {
        setEmployees(mockEmployees());
      }
    } catch {
      setEmployees(mockEmployees());
    }
    setLoading(false);
  }

  // 篩選
  const filtered = employees.filter((e) => {
    const matchSearch = !search || e.name.includes(search) || e.id.includes(search) || e.phone?.includes(search);
    const matchDept = filterDept === "all" || e.dept === filterDept;
    const matchStatus = filterStatus === "all" || e.status === filterStatus;
    return matchSearch && matchDept && matchStatus;
  });

  // 表單驗證
  function validateForm() {
    const errors = {};
    if (!formData.name.trim()) errors.name = "請輸入姓名";
    if (!formData.phone.trim()) errors.phone = "請輸入電話";
    if (!formData.hire_date) errors.hire_date = "請輸入到職日期";
    if (!formData.base_salary || isNaN(Number(formData.base_salary))) errors.base_salary = "請輸入正確薪資";
    if (formData.pin && (!/^\d{6}$/.test(formData.pin))) errors.pin = "PIN 必須為 6 位數字";
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  }

  // 開啟新增表單
  function openNew() {
    const newPin = generatePin();
    setFormData({ ...EMPTY_FORM, pin: newPin });
    setFormErrors({});
    setAvatarPreview(null);
    setSelectedEmployee(null);
    setView("form");
  }

  // 開啟編輯
  function openEdit(emp) {
    setFormData({
      name: emp.name, id_number: emp.id_number || "",
      phone: emp.phone || "", email: emp.email || "",
      dept: emp.dept, role: emp.role,
      shift: emp.shift, hire_date: emp.hire_date || "",
      pin: "", base_salary: emp.base_salary || "",
      status: emp.status, notes: emp.notes || "",
    });
    setFormErrors({});
    setAvatarPreview(emp.avatar || null);
    setSelectedEmployee(emp);
    setView("form");
  }

  // 儲存
  async function handleSave() {
    if (!validateForm()) return;
    setSaving(true);
    try {
      const payload = {
        ...formData,
        base_salary: Number(formData.base_salary),
        shift_key: SHIFT_KEYS[formData.shift]?.key || formData.shift,
        shift_start: SHIFT_KEYS[formData.shift]?.start,
        shift_end: SHIFT_KEYS[formData.shift]?.end,
        avatar: avatarPreview,
      };

      if (API_BASE) {
        if (selectedEmployee) {
          await fetch(`${API_BASE}/api/employees/${selectedEmployee.id}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload),
          });
        } else {
          const newId = generateId(employees);
          await fetch(`${API_BASE}/api/employees`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ ...payload, id: newId }),
          });
        }
      } else {
        // Mock 更新
        if (selectedEmployee) {
          setEmployees((prev) => prev.map((e) =>
            e.id === selectedEmployee.id ? { ...e, ...payload } : e
          ));
        } else {
          const newId = generateId(employees);
          setEmployees((prev) => [...prev, { id: newId, ...payload }]);
        }
      }
      await loadEmployees();
      showNotif(selectedEmployee ? "✓ 員工資料已更新" : "✓ 員工已新增", "#10b981");
      setView("list");
    } catch {
      showNotif("⚠ 儲存失敗，請重試", "#ef4444");
    }
    setSaving(false);
  }

  // 停用/啟用
  async function toggleStatus(emp) {
    const newStatus = emp.status === "active" ? "inactive" : "active";
    try {
      if (API_BASE) {
        await fetch(`${API_BASE}/api/employees/${emp.id}`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ status: newStatus }),
        });
      }
      setEmployees((prev) => prev.map((e) => e.id === emp.id ? { ...e, status: newStatus } : e));
      showNotif(newStatus === "active" ? "✓ 員工已啟用" : "⚠ 員工已停用", newStatus === "active" ? "#10b981" : "#f59e0b");
    } catch {
      showNotif("⚠ 操作失敗", "#ef4444");
    }
    setConfirmDelete(null);
  }

  // 大頭照
  function handleAvatarChange(e) {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => setAvatarPreview(ev.target.result);
    reader.readAsDataURL(file);
  }

  function showNotif(msg, color) {
    setNotification({ msg, color });
    setTimeout(() => setNotification(null), 3000);
  }

  const deptStats = DEPARTMENTS.reduce((acc, d) => {
    acc[d] = employees.filter((e) => e.dept === d && e.status === "active").length;
    return acc;
  }, {});

  if (loading) return (
    <div style={s.root}>
      <div style={{ textAlign: "center", padding: "80px 0", color: "#94a3b8" }}>載入員工資料中…</div>
    </div>
  );

  return (
    <div style={s.root}>
      {notification && (
        <div style={{ ...s.notif, background: notification.color }}>{notification.msg}</div>
      )}

      {/* 確認對話框 */}
      {confirmDelete && (
        <div style={s.overlay}>
          <div style={s.dialog}>
            <div style={{ fontSize: 32, marginBottom: 12 }}>
              {confirmDelete.status === "active" ? "⚠️" : "✅"}
            </div>
            <div style={{ fontSize: 18, fontWeight: 700, color: "#e2e8f0", marginBottom: 8 }}>
              確認{confirmDelete.status === "active" ? "停用" : "啟用"}員工？
            </div>
            <div style={{ color: "#94a3b8", fontSize: 14, marginBottom: 24 }}>
              {confirmDelete.name} — {confirmDelete.dept}
            </div>
            <div style={{ display: "flex", gap: 12, justifyContent: "center" }}>
              <button style={{ ...s.btn, background: "#374151" }} onClick={() => setConfirmDelete(null)}>取消</button>
              <button
                style={{ ...s.btn, background: confirmDelete.status === "active" ? "#ef4444" : "#10b981" }}
                onClick={() => toggleStatus(confirmDelete)}
              >
                確認{confirmDelete.status === "active" ? "停用" : "啟用"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Header */}
      <div style={s.header}>
        <div>
          <div style={s.title}>👥 員工管理</div>
          <div style={s.subtitle}>共 {employees.filter(e => e.status === "active").length} 位在職員工</div>
        </div>
        {view === "list" && (
          <button style={s.addBtn} onClick={openNew}>
            ＋ 新增員工
          </button>
        )}
        {view === "form" && (
          <div style={{ display: "flex", gap: 10 }}>
            <button style={{ ...s.btn, background: "#374151" }} onClick={() => setView("list")}>← 返回</button>
            <button style={{ ...s.btn, background: "#10b981" }} onClick={handleSave} disabled={saving}>
              {saving ? "儲存中…" : (selectedEmployee ? "💾 更新員工" : "✓ 新增員工")}
            </button>
          </div>
        )}
      </div>

      {/* 部門統計 */}
      {view === "list" && (
        <div style={s.deptBar}>
          {DEPARTMENTS.map((d) => (
            <div
              key={d}
              style={{
                ...s.deptCard,
                borderColor: filterDept === d ? DEPT_COLORS[d] : "rgba(255,255,255,0.08)",
                background: filterDept === d ? `${DEPT_COLORS[d]}15` : "rgba(255,255,255,0.03)",
              }}
              onClick={() => setFilterDept(filterDept === d ? "all" : d)}
            >
              <div style={{ color: DEPT_COLORS[d], fontWeight: 800, fontSize: 22 }}>{deptStats[d]}</div>
              <div style={{ color: "#94a3b8", fontSize: 12, marginTop: 2 }}>{d}</div>
            </div>
          ))}
        </div>
      )}

      {/* 列表視圖 */}
      {view === "list" && (
        <>
          <div style={s.toolbar}>
            <input
              style={s.searchInput}
              placeholder="🔍 搜尋姓名、工號、電話…"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
            <div style={s.filterGroup}>
              {["all", ...DEPARTMENTS].map((d) => (
                <button
                  key={d}
                  style={{ ...s.filterBtn, ...(filterDept === d ? s.filterBtnActive : {}) }}
                  onClick={() => setFilterDept(d)}
                >
                  {d === "all" ? "全部部門" : d}
                </button>
              ))}
            </div>
            <div style={{ display: "flex", gap: 6, marginLeft: "auto" }}>
              {["active", "inactive", "all"].map((st) => (
                <button
                  key={st}
                  style={{
                    ...s.filterBtn,
                    ...(filterStatus === st ? {
                      background: st === "active" ? "rgba(16,185,129,0.15)" : st === "inactive" ? "rgba(239,68,68,0.15)" : "rgba(255,255,255,0.1)",
                      color: st === "active" ? "#10b981" : st === "inactive" ? "#ef4444" : "#e2e8f0",
                      borderColor: st === "active" ? "#10b981" : st === "inactive" ? "#ef4444" : "#e2e8f0",
                    } : {}),
                  }}
                  onClick={() => setFilterStatus(st)}
                >
                  {st === "active" ? "● 在職" : st === "inactive" ? "● 離職" : "全部"}
                </button>
              ))}
            </div>
          </div>

          <div style={s.empGrid}>
            {filtered.map((emp) => (
              <EmployeeCard
                key={emp.id}
                emp={emp}
                onEdit={() => openEdit(emp)}
                onToggle={() => setConfirmDelete(emp)}
                pinVisible={pinVisible[emp.id]}
                onTogglePin={() => setPinVisible((p) => ({ ...p, [emp.id]: !p[emp.id] }))}
              />
            ))}
            {filtered.length === 0 && (
              <div style={{ gridColumn: "1/-1", textAlign: "center", padding: "60px 0", color: "#64748b" }}>
                找不到符合條件的員工
              </div>
            )}
          </div>
        </>
      )}

      {/* 表單視圖 */}
      {view === "form" && (
        <EmployeeForm
          formData={formData}
          errors={formErrors}
          onChange={(key, val) => setFormData((p) => ({ ...p, [key]: val }))}
          avatarPreview={avatarPreview}
          onAvatarClick={() => fileInputRef.current?.click()}
          isEdit={!!selectedEmployee}
          employeeId={selectedEmployee?.id}
        />
      )}

      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        style={{ display: "none" }}
        onChange={handleAvatarChange}
      />
    </div>
  );
}

// ─── 員工卡片 ────────────────────────────────────────────────────────────────
function EmployeeCard({ emp, onEdit, onToggle, pinVisible, onTogglePin }) {
  const isInactive = emp.status === "inactive";
  const years = yearsSince(emp.hire_date);
  const annualLeave = calcAnnualLeave(years);

  return (
    <div style={{
      ...s.empCard,
      opacity: isInactive ? 0.5 : 1,
      borderColor: isInactive ? "rgba(239,68,68,0.3)" : "rgba(255,255,255,0.08)",
    }}>
      {/* 頂部：頭像 + 基本 */}
      <div style={{ display: "flex", gap: 14, alignItems: "flex-start" }}>
        <div style={s.avatar}>
          {emp.avatar ? (
            <img src={emp.avatar} style={{ width: "100%", height: "100%", borderRadius: "50%", objectFit: "cover" }} alt="" />
          ) : (
            <span style={{ fontSize: 20, color: DEPT_COLORS[emp.dept] || "#94a3b8" }}>
              {emp.name?.[0]}
            </span>
          )}
        </div>
        <div style={{ flex: 1 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <span style={{ fontSize: 16, fontWeight: 700, color: "#e2e8f0" }}>{emp.name}</span>
            {isInactive && (
              <span style={{ fontSize: 11, padding: "2px 8px", borderRadius: 10, background: "rgba(239,68,68,0.15)", color: "#ef4444" }}>
                已停用
              </span>
            )}
          </div>
          <div style={{ fontSize: 12, color: "#64748b", marginTop: 2 }}>{emp.id} · {emp.role}</div>
          <div style={{ display: "flex", gap: 6, marginTop: 8 }}>
            <span style={{ ...s.deptBadge, background: `${DEPT_COLORS[emp.dept] || "#94a3b8"}22`, color: DEPT_COLORS[emp.dept] || "#94a3b8" }}>
              {emp.dept}
            </span>
            <span style={s.shiftBadge}>{emp.shift?.split(" ")[0]}</span>
          </div>
        </div>
      </div>

      {/* 詳細資訊 */}
      <div style={s.empDetails}>
        <InfoRow icon="📱" text={emp.phone} />
        <InfoRow icon="📧" text={emp.email} />
        <InfoRow icon="📅" text={`到職 ${emp.hire_date || "—"} · 年資 ${years} 年`} />
        <InfoRow icon="💰" text={`底薪 NT$${Number(emp.base_salary).toLocaleString()}`} />
        <InfoRow icon="🌴" text={`年假 ${annualLeave} 天`} />
        <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
          <span style={{ fontSize: 13 }}>🔑</span>
          <span style={{ color: "#94a3b8", fontSize: 13 }}>
            PIN：{pinVisible ? emp.pin : "••••••"}
          </span>
          <button
            style={s.pinToggle}
            onClick={onTogglePin}
          >
            {pinVisible ? "隱藏" : "顯示"}
          </button>
        </div>
      </div>

      {/* 操作 */}
      <div style={s.empActions}>
        <button style={{ ...s.actionBtn, borderColor: "#3b82f6", color: "#3b82f6" }} onClick={onEdit}>
          ✏ 編輯
        </button>
        <button
          style={{
            ...s.actionBtn,
            borderColor: isInactive ? "#10b981" : "#ef4444",
            color: isInactive ? "#10b981" : "#ef4444",
          }}
          onClick={onToggle}
        >
          {isInactive ? "✓ 啟用" : "⊘ 停用"}
        </button>
      </div>
    </div>
  );
}

function InfoRow({ icon, text }) {
  if (!text) return null;
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
      <span style={{ fontSize: 13, minWidth: 20 }}>{icon}</span>
      <span style={{ color: "#94a3b8", fontSize: 13 }}>{text}</span>
    </div>
  );
}

// ─── 員工表單 ─────────────────────────────────────────────────────────────────
function EmployeeForm({ formData, errors, onChange, avatarPreview, onAvatarClick, isEdit, employeeId }) {
  const years = yearsSince(formData.hire_date);
  const annualLeave = calcAnnualLeave(years);

  return (
    <div style={s.formContainer}>
      <div style={s.formGrid}>
        {/* 左側：基本資料 */}
        <div style={s.formSection}>
          <div style={s.sectionTitle}>👤 基本資料</div>

          {/* 頭像 */}
          <div style={{ display: "flex", justifyContent: "center", marginBottom: 24 }}>
            <div style={s.avatarUpload} onClick={onAvatarClick}>
              {avatarPreview ? (
                <img src={avatarPreview} style={{ width: "100%", height: "100%", borderRadius: "50%", objectFit: "cover" }} alt="" />
              ) : (
                <div style={{ textAlign: "center" }}>
                  <div style={{ fontSize: 32 }}>📷</div>
                  <div style={{ fontSize: 11, color: "#64748b", marginTop: 4 }}>點擊上傳</div>
                </div>
              )}
            </div>
          </div>

          <FormField label="姓名 *" error={errors.name}>
            <input style={s.input} value={formData.name} onChange={(e) => onChange("name", e.target.value)} placeholder="例：陳美華" />
          </FormField>
          <FormField label="身分證字號" error={errors.id_number}>
            <input style={s.input} value={formData.id_number} onChange={(e) => onChange("id_number", e.target.value)} placeholder="例：A123456789" />
          </FormField>
          <FormField label="手機號碼 *" error={errors.phone}>
            <input style={s.input} value={formData.phone} onChange={(e) => onChange("phone", e.target.value)} placeholder="例：0912-345-678" />
          </FormField>
          <FormField label="電子郵件" error={errors.email}>
            <input style={s.input} value={formData.email} onChange={(e) => onChange("email", e.target.value)} placeholder="例：name@care.org.tw" type="email" />
          </FormField>
        </div>

        {/* 右側：工作資料 */}
        <div style={s.formSection}>
          <div style={s.sectionTitle}>💼 工作資料</div>

          {isEdit && employeeId && (
            <div style={s.idDisplay}>
              <span style={{ color: "#64748b", fontSize: 12 }}>工號</span>
              <span style={{ color: "#10b981", fontWeight: 800, fontSize: 20 }}>{employeeId}</span>
            </div>
          )}

          <FormField label="部門">
            <select style={s.input} value={formData.dept} onChange={(e) => onChange("dept", e.target.value)}>
              {DEPARTMENTS.map((d) => <option key={d} value={d}>{d}</option>)}
            </select>
          </FormField>
          <FormField label="職稱">
            <select style={s.input} value={formData.role} onChange={(e) => onChange("role", e.target.value)}>
              {ROLES.map((r) => <option key={r} value={r}>{r}</option>)}
            </select>
          </FormField>
          <FormField label="班別">
            <select style={s.input} value={formData.shift} onChange={(e) => onChange("shift", e.target.value)}>
              {SHIFTS.map((sh) => <option key={sh} value={sh}>{sh}</option>)}
            </select>
          </FormField>
          <FormField label="到職日期 *" error={errors.hire_date}>
            <input style={s.input} type="date" value={formData.hire_date} onChange={(e) => onChange("hire_date", e.target.value)} />
          </FormField>
          {formData.hire_date && (
            <div style={s.leavePreview}>
              <span style={{ color: "#94a3b8" }}>年資 {years} 年 →</span>
              <span style={{ color: "#10b981", fontWeight: 700, marginLeft: 8 }}>年假 {annualLeave} 天</span>
            </div>
          )}
        </div>

        {/* 底部：薪資與系統 */}
        <div style={{ ...s.formSection, gridColumn: "1 / 3" }}>
          <div style={s.sectionTitle}>💰 薪資與系統設定</div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 20 }}>
            <FormField label="底薪（元）*" error={errors.base_salary}>
              <input
                style={s.input} type="number"
                value={formData.base_salary}
                onChange={(e) => onChange("base_salary", e.target.value)}
                placeholder="例：32000"
              />
            </FormField>
            <FormField label="打卡 PIN（6位數）" error={errors.pin}>
              <input
                style={s.input} type="text" maxLength={6}
                value={formData.pin}
                onChange={(e) => onChange("pin", e.target.value.replace(/\D/g, ""))}
                placeholder="留空表示不更改"
              />
            </FormField>
            <FormField label="狀態">
              <select style={s.input} value={formData.status} onChange={(e) => onChange("status", e.target.value)}>
                <option value="active">● 在職</option>
                <option value="inactive">● 停用/離職</option>
              </select>
            </FormField>
          </div>
          <FormField label="備註">
            <textarea
              style={{ ...s.input, height: 80, resize: "vertical" }}
              value={formData.notes}
              onChange={(e) => onChange("notes", e.target.value)}
              placeholder="備註事項…"
            />
          </FormField>
        </div>
      </div>
    </div>
  );
}

function FormField({ label, error, children }) {
  return (
    <div style={{ marginBottom: 16 }}>
      <label style={s.label}>{label}</label>
      {children}
      {error && <div style={s.errorText}>{error}</div>}
    </div>
  );
}

// ─── 樣式 ────────────────────────────────────────────────────────────────────
const s = {
  root: {
    background: "#0a0f1e",
    minHeight: "100vh",
    fontFamily: "'Noto Sans TC', 'PingFang TC', sans-serif",
    color: "#e2e8f0",
    padding: "24px 32px",
  },
  notif: {
    position: "fixed", top: 0, left: 0, right: 0, zIndex: 9999,
    padding: "12px 24px", textAlign: "center",
    color: "#fff", fontWeight: 700, fontSize: 15,
  },
  overlay: {
    position: "fixed", inset: 0, background: "rgba(0,0,0,0.7)",
    display: "flex", alignItems: "center", justifyContent: "center", zIndex: 1000,
  },
  dialog: {
    background: "#1a2744", border: "1px solid rgba(255,255,255,0.12)",
    borderRadius: 16, padding: "32px 40px", textAlign: "center",
    boxShadow: "0 20px 60px rgba(0,0,0,0.5)",
  },
  header: {
    display: "flex", justifyContent: "space-between", alignItems: "flex-start",
    marginBottom: 24,
  },
  title: { fontSize: 24, fontWeight: 800, color: "#f0f9ff", letterSpacing: "-0.5px" },
  subtitle: { fontSize: 13, color: "#64748b", marginTop: 4 },
  addBtn: {
    padding: "12px 24px", borderRadius: 10,
    background: "linear-gradient(135deg, #10b981, #059669)",
    border: "none", color: "#fff", fontWeight: 700, fontSize: 15,
    cursor: "pointer", fontFamily: "inherit",
    boxShadow: "0 4px 16px rgba(16,185,129,0.3)",
  },
  deptBar: {
    display: "flex", gap: 12, marginBottom: 24,
  },
  deptCard: {
    flex: 1, padding: "16px 20px", borderRadius: 12,
    border: "1px solid", cursor: "pointer", textAlign: "center",
    transition: "all 0.2s",
  },
  toolbar: {
    display: "flex", gap: 10, alignItems: "center", marginBottom: 20, flexWrap: "wrap",
  },
  searchInput: {
    padding: "10px 16px", borderRadius: 10,
    background: "rgba(255,255,255,0.06)",
    border: "1px solid rgba(255,255,255,0.12)",
    color: "#e2e8f0", fontSize: 14, width: 240,
    fontFamily: "inherit",
  },
  filterGroup: { display: "flex", gap: 6 },
  filterBtn: {
    padding: "8px 14px", borderRadius: 8,
    background: "rgba(255,255,255,0.04)",
    border: "1px solid rgba(255,255,255,0.08)",
    color: "#94a3b8", fontSize: 12, cursor: "pointer", fontFamily: "inherit",
  },
  filterBtnActive: {
    background: "rgba(16,185,129,0.15)", borderColor: "#10b981", color: "#10b981",
  },
  empGrid: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))",
    gap: 18,
  },
  empCard: {
    background: "linear-gradient(135deg, #0d1b2a, #111827)",
    border: "1px solid",
    borderRadius: 14, padding: "20px",
    display: "flex", flexDirection: "column", gap: 16,
    transition: "transform 0.2s, box-shadow 0.2s",
  },
  avatar: {
    width: 52, height: 52, borderRadius: "50%",
    background: "rgba(255,255,255,0.06)",
    display: "flex", alignItems: "center", justifyContent: "center",
    fontSize: 22, flexShrink: 0, overflow: "hidden",
  },
  deptBadge: {
    padding: "3px 10px", borderRadius: 20, fontSize: 11, fontWeight: 600,
  },
  shiftBadge: {
    padding: "3px 10px", borderRadius: 20, fontSize: 11,
    background: "rgba(99,102,241,0.15)", color: "#818cf8",
  },
  empDetails: { display: "flex", flexDirection: "column", gap: 7 },
  empActions: { display: "flex", gap: 8 },
  actionBtn: {
    flex: 1, padding: "8px 0", borderRadius: 8,
    background: "transparent", border: "1px solid",
    fontSize: 13, fontWeight: 600, cursor: "pointer",
    fontFamily: "inherit",
  },
  pinToggle: {
    marginLeft: 4, padding: "2px 8px", borderRadius: 4,
    background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.12)",
    color: "#64748b", fontSize: 11, cursor: "pointer", fontFamily: "inherit",
  },
  formContainer: { paddingBottom: 40 },
  formGrid: {
    display: "grid", gridTemplateColumns: "1fr 1fr",
    gap: 24,
  },
  formSection: {
    background: "linear-gradient(135deg, #0d1b2a, #111827)",
    border: "1px solid rgba(255,255,255,0.08)",
    borderRadius: 14, padding: "24px",
  },
  sectionTitle: {
    fontSize: 15, fontWeight: 700, color: "#94a3b8",
    marginBottom: 20, paddingBottom: 12,
    borderBottom: "1px solid rgba(255,255,255,0.06)",
  },
  avatarUpload: {
    width: 80, height: 80, borderRadius: "50%",
    background: "rgba(255,255,255,0.06)",
    border: "2px dashed rgba(255,255,255,0.2)",
    display: "flex", alignItems: "center", justifyContent: "center",
    cursor: "pointer", overflow: "hidden",
  },
  input: {
    width: "100%", padding: "10px 14px",
    background: "rgba(255,255,255,0.06)",
    border: "1px solid rgba(255,255,255,0.12)",
    borderRadius: 8, color: "#e2e8f0", fontSize: 14,
    fontFamily: "inherit", boxSizing: "border-box",
  },
  label: {
    display: "block", fontSize: 12, fontWeight: 600,
    color: "#64748b", marginBottom: 6, textTransform: "uppercase",
    letterSpacing: "0.05em",
  },
  errorText: { color: "#ef4444", fontSize: 12, marginTop: 4 },
  idDisplay: {
    display: "flex", flexDirection: "column", alignItems: "center",
    padding: "16px", marginBottom: 20,
    background: "rgba(16,185,129,0.08)", borderRadius: 10,
    border: "1px solid rgba(16,185,129,0.2)",
  },
  leavePreview: {
    padding: "8px 12px", borderRadius: 8, marginTop: -8, marginBottom: 16,
    background: "rgba(16,185,129,0.08)", border: "1px solid rgba(16,185,129,0.2)",
    fontSize: 13,
  },
  btn: {
    padding: "10px 20px", borderRadius: 8, border: "none",
    color: "#fff", fontWeight: 700, fontSize: 14,
    cursor: "pointer", fontFamily: "inherit",
  },
};
