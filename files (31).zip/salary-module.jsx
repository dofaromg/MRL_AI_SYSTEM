/**
 * salary-module.jsx
 * 薪資試算模組 — 月結薪資 + 加班費 + 請假扣薪
 * 愛心教養院考勤系統 v3.3
 *
 * 計算基準：台灣《勞動基準法》
 * - 平日加班前2小時：1.34倍
 * - 平日加班3~4小時：1.67倍
 * - 假日加班：2倍
 * - 病假扣薪：1/2日薪
 * - 事假扣薪：1日薪
 * - 年假不扣薪
 */

import { useState, useEffect } from "react";

// ─── 常數 ─────────────────────────────────────────────────────────────────────
const LEAVE_PAY_RULES = {
  "年假": { deductRatio: 0,   label: "年假（不扣薪）" },
  "病假": { deductRatio: 0.5, label: "病假（扣半日）" },
  "事假": { deductRatio: 1,   label: "事假（全扣）" },
  "婚假": { deductRatio: 0,   label: "婚假（不扣薪）" },
  "喪假": { deductRatio: 0,   label: "喪假（不扣薪）" },
  "補休": { deductRatio: 0,   label: "補休（不扣薪）" },
  "公假": { deductRatio: 0,   label: "公假（不扣薪）" },
};

const DEPT_COLORS = {
  "照護組": "#0ea5e9", "教保組": "#10b981",
  "行政組": "#f59e0b", "護理組": "#ec4899",
};

// ─── Mock 資料 ─────────────────────────────────────────────────────────────────
function mockSalaryData(year, month) {
  const employees = [
    { id: "EMP001", name: "陳美華", dept: "照護組", base_salary: 38000, hire_date: "2019-03-15" },
    { id: "EMP002", name: "林志明", dept: "教保組", base_salary: 32000, hire_date: "2021-06-01" },
    { id: "EMP003", name: "王淑芬", dept: "護理組", base_salary: 35000, hire_date: "2020-09-10" },
    { id: "EMP004", name: "張建國", dept: "行政組", base_salary: 40000, hire_date: "2018-01-20" },
    { id: "EMP005", name: "李雅婷", dept: "照護組", base_salary: 33000, hire_date: "2022-03-01" },
  ];

  return employees.map((emp) => {
    const workDays = 22 - Math.floor(Math.random() * 2);
    const leaveDays = [
      ...(Math.random() > 0.6 ? [{ type: "年假", days: 1 }] : []),
      ...(Math.random() > 0.7 ? [{ type: "病假", days: 1 }] : []),
    ];
    const overtimeHours = Math.floor(Math.random() * 8) + 2;
    const holidayOvertimeHours = Math.random() > 0.6 ? Math.floor(Math.random() * 8) : 0;
    const lateTimes = Math.floor(Math.random() * 3);

    return {
      ...emp,
      workDays,
      leaveDays,
      overtimeHours,
      holidayOvertimeHours,
      lateTimes,
      lateMinutes: lateTimes * (Math.floor(Math.random() * 20) + 5),
    };
  });
}

// ─── 薪資計算函數 ─────────────────────────────────────────────────────────────
function calculateSalary(emp) {
  const base = Number(emp.base_salary) || 0;
  const workDaysInMonth = 22; // 標準工作天數
  const dailyRate = base / workDaysInMonth;
  const hourlyRate = dailyRate / 8;

  // 加班費計算（台灣勞基法）
  const normalOT = emp.overtimeHours || 0;
  let overtimePay = 0;
  if (normalOT >= 1) overtimePay += Math.min(normalOT, 2) * hourlyRate * 1.34;
  if (normalOT > 2) overtimePay += Math.min(normalOT - 2, 2) * hourlyRate * 1.67;
  if (normalOT > 4) overtimePay += (normalOT - 4) * hourlyRate * 1.67;

  // 假日加班
  const holidayOT = emp.holidayOvertimeHours || 0;
  const holidayOTPay = holidayOT * hourlyRate * 2;

  // 請假扣薪
  let leaveDeduct = 0;
  (emp.leaveDays || []).forEach((leave) => {
    const rule = LEAVE_PAY_RULES[leave.type];
    if (rule) leaveDeduct += dailyRate * rule.deductRatio * leave.days;
  });

  // 遲到扣薪（每遲到1分鐘扣1分鐘工資）
  const lateDeduct = (emp.lateMinutes || 0) * (hourlyRate / 60);

  const totalOTPay = overtimePay + holidayOTPay;
  const totalDeduct = leaveDeduct + lateDeduct;
  const gross = base + totalOTPay - totalDeduct;

  // 勞健保（簡化計算）
  const laborInsurance = Math.round(base * 0.01184); // 勞工負擔
  const healthInsurance = Math.round(base * 0.0228 * 0.3); // 健保自付30%
  const netPay = gross - laborInsurance - healthInsurance;

  return {
    base,
    dailyRate: Math.round(dailyRate),
    hourlyRate: Math.round(hourlyRate),
    overtimePay: Math.round(overtimePay),
    holidayOTPay: Math.round(holidayOTPay),
    totalOTPay: Math.round(totalOTPay),
    leaveDeduct: Math.round(leaveDeduct),
    lateDeduct: Math.round(lateDeduct),
    totalDeduct: Math.round(totalDeduct),
    gross: Math.round(gross),
    laborInsurance,
    healthInsurance,
    netPay: Math.round(netPay),
  };
}

// ─── 主元件 ──────────────────────────────────────────────────────────────────
export default function SalaryModule({ API_BASE = "" }) {
  const now = new Date();
  const [year, setYear] = useState(now.getFullYear());
  const [month, setMonth] = useState(now.getMonth() + 1);
  const [employees, setEmployees] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedEmp, setSelectedEmp] = useState(null);
  const [filterDept, setFilterDept] = useState("all");
  const [exportLoading, setExportLoading] = useState(false);
  const [notification, setNotification] = useState(null);

  useEffect(() => {
    load();
  }, [year, month]);

  async function load() {
    setLoading(true);
    try {
      const data = API_BASE
        ? await (await fetch(`${API_BASE}/api/salary?year=${year}&month=${month}`)).json()
        : mockSalaryData(year, month);
      setEmployees(Array.isArray(data) ? data : data.employees || []);
    } catch {
      setEmployees(mockSalaryData(year, month));
    }
    setLoading(false);
  }

  function prevMonth() {
    if (month === 1) { setYear(y => y - 1); setMonth(12); }
    else setMonth(m => m - 1);
  }
  function nextMonth() {
    if (month === 12) { setYear(y => y + 1); setMonth(1); }
    else setMonth(m => m + 1);
  }

  function showNotif(msg, color) {
    setNotification({ msg, color });
    setTimeout(() => setNotification(null), 3000);
  }

  // 匯出 CSV
  function exportCSV() {
    setExportLoading(true);
    const filtered = employees.filter(e => filterDept === "all" || e.dept === filterDept);
    const rows = [
      ["工號", "姓名", "部門", "底薪", "加班費", "假日加班費", "請假扣薪", "遲到扣薪", "應發薪資", "勞保自付", "健保自付", "實發薪資"],
      ...filtered.map(emp => {
        const c = calculateSalary(emp);
        return [emp.id, emp.name, emp.dept, c.base, c.overtimePay, c.holidayOTPay, c.leaveDeduct, c.lateDeduct, c.gross, c.laborInsurance, c.healthInsurance, c.netPay];
      }),
    ];
    const csv = rows.map(r => r.join(",")).join("\n");
    const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `薪資試算_${year}${String(month).padStart(2, "0")}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    showNotif("✓ CSV 已匯出", "#10b981");
    setExportLoading(false);
  }

  const filtered = employees.filter(e => filterDept === "all" || e.dept === filterDept);
  const totalNetPay = filtered.reduce((acc, emp) => acc + calculateSalary(emp).netPay, 0);
  const totalGross = filtered.reduce((acc, emp) => acc + calculateSalary(emp).gross, 0);
  const totalOT = filtered.reduce((acc, emp) => acc + calculateSalary(emp).totalOTPay, 0);

  if (loading) return (
    <div style={ss.root}>
      <div style={{ textAlign: "center", padding: "80px 0", color: "#94a3b8" }}>計算薪資中…</div>
    </div>
  );

  return (
    <div style={ss.root}>
      {notification && (
        <div style={{ ...ss.notif, background: notification.color }}>{notification.msg}</div>
      )}

      {/* Header */}
      <div style={ss.header}>
        <div>
          <div style={ss.title}>💰 薪資試算</div>
          <div style={ss.subtitle}>{year} 年 {month} 月 · 依台灣勞基法計算</div>
        </div>
        <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
          <div style={ss.monthNav}>
            <button style={ss.navBtn} onClick={prevMonth}>◀</button>
            <span style={ss.monthLabel}>{year}/{String(month).padStart(2, "0")}</span>
            <button style={ss.navBtn} onClick={nextMonth}>▶</button>
          </div>
          <button style={{ ...ss.actionBtn, background: "#1e40af" }} onClick={exportCSV} disabled={exportLoading}>
            {exportLoading ? "匯出中…" : "⬇ 匯出 CSV"}
          </button>
        </div>
      </div>

      {/* 部門篩選 */}
      <div style={ss.toolbar}>
        {["all", ...Object.keys(DEPT_COLORS)].map((d) => (
          <button
            key={d}
            style={{
              ...ss.filterBtn,
              borderColor: filterDept === d ? (DEPT_COLORS[d] || "#10b981") : "rgba(255,255,255,0.08)",
              color: filterDept === d ? (DEPT_COLORS[d] || "#10b981") : "#64748b",
              background: filterDept === d ? `${DEPT_COLORS[d] || "#10b981"}15` : "rgba(255,255,255,0.03)",
            }}
            onClick={() => setFilterDept(d)}
          >
            {d === "all" ? "全部部門" : d}
          </button>
        ))}
      </div>

      {/* 月份統計卡 */}
      <div style={ss.summaryGrid}>
        <SummaryCard icon="👥" label="計算員工" value={filtered.length} unit="人" color="#0ea5e9" />
        <SummaryCard icon="💵" label="薪資總額（應發）" value={`NT$${totalGross.toLocaleString()}`} unit="" color="#10b981" />
        <SummaryCard icon="⏱" label="加班費合計" value={`NT$${totalOT.toLocaleString()}`} unit="" color="#f59e0b" />
        <SummaryCard icon="💳" label="實發總額" value={`NT$${totalNetPay.toLocaleString()}`} unit="" color="#ec4899" />
      </div>

      {/* 薪資明細表 */}
      <div style={ss.tableCard}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
          <div style={ss.cardTitle}>📋 薪資明細一覽</div>
          <div style={{ fontSize: 12, color: "#64748b" }}>點擊員工列可查看詳細計算</div>
        </div>
        <table style={ss.table}>
          <thead>
            <tr>
              {["員工", "部門", "底薪", "加班費", "假日加班", "扣薪", "應發薪資", "勞健保", "實發薪資", ""].map(h => (
                <th key={h} style={ss.th}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filtered.map((emp) => {
              const c = calculateSalary(emp);
              const isSelected = selectedEmp?.id === emp.id;
              return (
                <>
                  <tr
                    key={emp.id}
                    style={{
                      ...ss.tr,
                      background: isSelected ? "rgba(16,185,129,0.05)" : "transparent",
                      cursor: "pointer",
                    }}
                    onClick={() => setSelectedEmp(isSelected ? null : emp)}
                  >
                    <td style={ss.td}>
                      <div style={{ fontWeight: 600, color: "#e2e8f0" }}>{emp.name}</div>
                      <div style={{ fontSize: 11, color: "#64748b" }}>{emp.id}</div>
                    </td>
                    <td style={ss.td}>
                      <span style={{ ...ss.deptBadge, background: `${DEPT_COLORS[emp.dept]}22`, color: DEPT_COLORS[emp.dept] }}>
                        {emp.dept}
                      </span>
                    </td>
                    <AmtCell value={c.base} />
                    <AmtCell value={c.overtimePay} color="#f59e0b" showZero={false} />
                    <AmtCell value={c.holidayOTPay} color="#f59e0b" showZero={false} />
                    <AmtCell value={c.totalDeduct} color={c.totalDeduct > 0 ? "#ef4444" : "#64748b"} prefix="-" showZero={false} />
                    <AmtCell value={c.gross} bold />
                    <AmtCell value={c.laborInsurance + c.healthInsurance} color="#ef4444" prefix="-" />
                    <AmtCell value={c.netPay} color="#10b981" bold large />
                    <td style={ss.td}>
                      <span style={{ color: isSelected ? "#10b981" : "#64748b", fontSize: 16 }}>
                        {isSelected ? "▲" : "▼"}
                      </span>
                    </td>
                  </tr>
                  {isSelected && (
                    <tr key={`${emp.id}-detail`}>
                      <td colSpan={10} style={{ ...ss.td, padding: 0 }}>
                        <SalaryDetail emp={emp} calc={c} />
                      </td>
                    </tr>
                  )}
                </>
              );
            })}
          </tbody>
          {/* 合計列 */}
          <tfoot>
            <tr style={{ borderTop: "2px solid rgba(255,255,255,0.12)" }}>
              <td style={{ ...ss.td, fontWeight: 700, color: "#94a3b8" }} colSpan={2}>合計</td>
              <AmtCell value={filtered.reduce((a, e) => a + calculateSalary(e).base, 0)} />
              <AmtCell value={filtered.reduce((a, e) => a + calculateSalary(e).overtimePay, 0)} color="#f59e0b" />
              <AmtCell value={filtered.reduce((a, e) => a + calculateSalary(e).holidayOTPay, 0)} color="#f59e0b" />
              <AmtCell value={filtered.reduce((a, e) => a + calculateSalary(e).totalDeduct, 0)} color="#ef4444" prefix="-" />
              <AmtCell value={totalGross} bold />
              <AmtCell value={filtered.reduce((a, e) => a + calculateSalary(e).laborInsurance + calculateSalary(e).healthInsurance, 0)} color="#ef4444" prefix="-" />
              <AmtCell value={totalNetPay} color="#10b981" bold large />
              <td style={ss.td} />
            </tr>
          </tfoot>
        </table>
      </div>

      {/* 法規說明 */}
      <div style={ss.legalNote}>
        <div style={ss.legalTitle}>📖 勞基法加班費計算說明</div>
        <div style={ss.legalGrid}>
          <LegalItem icon="⏱" title="平日加班（前2小時）" detail="時薪 × 1.34 倍" />
          <LegalItem icon="⏱" title="平日加班（第3-4小時）" detail="時薪 × 1.67 倍" />
          <LegalItem icon="📅" title="假日加班" detail="時薪 × 2 倍" />
          <LegalItem icon="🤒" title="病假扣薪" detail="日薪 × 0.5" />
          <LegalItem icon="🏖" title="事假扣薪" detail="日薪 × 1（全扣）" />
          <LegalItem icon="🌴" title="年假/婚假/喪假" detail="不扣薪" />
        </div>
        <div style={{ fontSize: 11, color: "#475569", marginTop: 12 }}>
          ⚠ 本試算僅供參考，實際薪資請依公司規定及當月出勤記錄計算。健保費以受雇者投保金額 × 4.69% × 30% 計算，勞保費以 1.184% 計算。
        </div>
      </div>
    </div>
  );
}

// ─── 薪資詳細展開 ─────────────────────────────────────────────────────────────
function SalaryDetail({ emp, calc }) {
  return (
    <div style={ss.detailPanel}>
      <div style={ss.detailGrid}>
        {/* 出勤狀況 */}
        <div>
          <div style={ss.detailSectionTitle}>📅 出勤狀況</div>
          <DetailRow label="本月出勤天數" value={`${emp.workDays} 天`} />
          <DetailRow label="平日加班" value={`${emp.overtimeHours} 小時`} />
          <DetailRow label="假日加班" value={`${emp.holidayOvertimeHours} 小時`} />
          <DetailRow label="遲到次數" value={`${emp.lateTimes} 次（共 ${emp.lateMinutes} 分鐘）`} />
          {(emp.leaveDays || []).map((l, i) => (
            <DetailRow key={i} label={LEAVE_PAY_RULES[l.type]?.label || l.type} value={`${l.days} 天`} />
          ))}
        </div>

        {/* 薪資計算 */}
        <div>
          <div style={ss.detailSectionTitle}>💵 薪資計算明細</div>
          <DetailRow label="底薪" value={`NT$${calc.base.toLocaleString()}`} />
          <DetailRow label="日薪（底薪 ÷ 22）" value={`NT$${calc.dailyRate.toLocaleString()}`} />
          <DetailRow label="時薪（日薪 ÷ 8）" value={`NT$${calc.hourlyRate.toLocaleString()}`} />
          <div style={ss.detailDivider} />
          {calc.overtimePay > 0 && (
            <DetailRow label="平日加班費" value={`+ NT$${calc.overtimePay.toLocaleString()}`} valueColor="#f59e0b" />
          )}
          {calc.holidayOTPay > 0 && (
            <DetailRow label="假日加班費" value={`+ NT$${calc.holidayOTPay.toLocaleString()}`} valueColor="#f59e0b" />
          )}
          {calc.leaveDeduct > 0 && (
            <DetailRow label="請假扣薪" value={`- NT$${calc.leaveDeduct.toLocaleString()}`} valueColor="#ef4444" />
          )}
          {calc.lateDeduct > 0 && (
            <DetailRow label="遲到扣薪" value={`- NT$${calc.lateDeduct.toLocaleString()}`} valueColor="#ef4444" />
          )}
          <div style={ss.detailDivider} />
          <DetailRow label="應發薪資" value={`NT$${calc.gross.toLocaleString()}`} bold />
        </div>

        {/* 扣除項目 */}
        <div>
          <div style={ss.detailSectionTitle}>📤 扣除項目</div>
          <DetailRow label="勞保自付額" value={`- NT$${calc.laborInsurance.toLocaleString()}`} valueColor="#ef4444" />
          <DetailRow label="健保自付額" value={`- NT$${calc.healthInsurance.toLocaleString()}`} valueColor="#ef4444" />
          <div style={ss.detailDivider} />
          <div style={ss.netPayDisplay}>
            <span>💳 實發薪資</span>
            <span style={{ color: "#10b981", fontSize: 28, fontWeight: 800 }}>
              NT${calc.netPay.toLocaleString()}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── 子元件 ──────────────────────────────────────────────────────────────────
function SummaryCard({ icon, label, value, unit, color }) {
  return (
    <div style={{ ...ss.summaryCard, borderColor: `${color}30` }}>
      <div style={{ fontSize: 28, marginBottom: 8 }}>{icon}</div>
      <div style={{ fontSize: 22, fontWeight: 800, color }}>{value}{unit}</div>
      <div style={{ fontSize: 12, color: "#64748b", marginTop: 4 }}>{label}</div>
    </div>
  );
}

function AmtCell({ value, color, prefix = "", bold, large, showZero = true }) {
  if (!showZero && value === 0) return <td style={ss.td}><span style={{ color: "#475569" }}>—</span></td>;
  return (
    <td style={ss.td}>
      <span style={{
        color: color || "#94a3b8",
        fontWeight: bold ? 700 : 500,
        fontSize: large ? 15 : 13,
      }}>
        {prefix}NT${value.toLocaleString()}
      </span>
    </td>
  );
}

function DetailRow({ label, value, valueColor, bold }) {
  return (
    <div style={{ display: "flex", justifyContent: "space-between", padding: "5px 0", borderBottom: "1px solid rgba(255,255,255,0.04)" }}>
      <span style={{ color: "#94a3b8", fontSize: 13 }}>{label}</span>
      <span style={{ color: valueColor || "#e2e8f0", fontSize: 13, fontWeight: bold ? 700 : 500 }}>{value}</span>
    </div>
  );
}

function LegalItem({ icon, title, detail }) {
  return (
    <div style={ss.legalItem}>
      <span style={{ fontSize: 18 }}>{icon}</span>
      <div>
        <div style={{ color: "#94a3b8", fontSize: 12, fontWeight: 600 }}>{title}</div>
        <div style={{ color: "#e2e8f0", fontSize: 13, marginTop: 2 }}>{detail}</div>
      </div>
    </div>
  );
}

// ─── 樣式 ────────────────────────────────────────────────────────────────────
const ss = {
  root: {
    background: "#0a0f1e",
    minHeight: "100vh",
    fontFamily: "'Noto Sans TC', 'PingFang TC', sans-serif",
    color: "#e2e8f0",
    padding: "24px 32px",
  },
  notif: {
    position: "fixed", top: 0, left: 0, right: 0, zIndex: 9999,
    padding: "12px 24px", textAlign: "center",
    color: "#fff", fontWeight: 700, fontSize: 15,
  },
  header: {
    display: "flex", justifyContent: "space-between", alignItems: "flex-start",
    marginBottom: 20,
  },
  title: { fontSize: 24, fontWeight: 800, color: "#f0f9ff", letterSpacing: "-0.5px" },
  subtitle: { fontSize: 13, color: "#64748b", marginTop: 4 },
  monthNav: {
    display: "flex", alignItems: "center", gap: 10,
    background: "rgba(255,255,255,0.06)",
    border: "1px solid rgba(255,255,255,0.12)",
    borderRadius: 10, padding: "6px 12px",
  },
  navBtn: {
    background: "none", border: "none", color: "#94a3b8",
    cursor: "pointer", fontSize: 14, padding: "2px 6px",
  },
  monthLabel: { color: "#e2e8f0", fontWeight: 700, minWidth: 70, textAlign: "center" },
  actionBtn: {
    padding: "10px 20px", borderRadius: 8, border: "none",
    color: "#fff", fontWeight: 700, fontSize: 13, cursor: "pointer", fontFamily: "inherit",
  },
  toolbar: { display: "flex", gap: 8, marginBottom: 20, flexWrap: "wrap" },
  filterBtn: {
    padding: "8px 14px", borderRadius: 8,
    border: "1px solid", fontSize: 12, cursor: "pointer", fontFamily: "inherit",
    transition: "all 0.2s",
  },
  summaryGrid: {
    display: "grid", gridTemplateColumns: "repeat(4, 1fr)",
    gap: 16, marginBottom: 24,
  },
  summaryCard: {
    background: "linear-gradient(135deg, #0d1b2a, #111827)",
    border: "1px solid", borderRadius: 14, padding: "20px",
    textAlign: "center",
  },
  tableCard: {
    background: "linear-gradient(135deg, #0d1b2a, #111827)",
    border: "1px solid rgba(255,255,255,0.08)",
    borderRadius: 14, padding: "24px",
    marginBottom: 24, overflowX: "auto",
  },
  cardTitle: {
    fontSize: 15, fontWeight: 700, color: "#94a3b8",
  },
  table: { width: "100%", borderCollapse: "collapse" },
  th: {
    padding: "10px 12px",
    color: "#64748b", fontSize: 11, fontWeight: 700,
    borderBottom: "1px solid rgba(255,255,255,0.08)",
    textAlign: "left", letterSpacing: "0.05em", textTransform: "uppercase",
  },
  tr: { borderBottom: "1px solid rgba(255,255,255,0.04)", transition: "background 0.2s" },
  td: { padding: "12px 12px", fontSize: 13 },
  deptBadge: {
    padding: "3px 10px", borderRadius: 20, fontSize: 11, fontWeight: 600,
  },
  detailPanel: {
    background: "rgba(16,185,129,0.04)",
    border: "1px solid rgba(16,185,129,0.15)",
    margin: "0 0 4px 0", padding: "20px 24px",
  },
  detailGrid: {
    display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 32,
  },
  detailSectionTitle: {
    fontSize: 13, fontWeight: 700, color: "#64748b",
    marginBottom: 12, paddingBottom: 8,
    borderBottom: "1px solid rgba(255,255,255,0.06)",
  },
  detailDivider: {
    height: 1, background: "rgba(255,255,255,0.08)", margin: "8px 0",
  },
  netPayDisplay: {
    display: "flex", justifyContent: "space-between", alignItems: "center",
    padding: "12px 0", marginTop: 8,
  },
  legalNote: {
    background: "linear-gradient(135deg, #0d1b2a, #111827)",
    border: "1px solid rgba(255,255,255,0.08)",
    borderRadius: 14, padding: "20px 24px",
  },
  legalTitle: {
    fontSize: 14, fontWeight: 700, color: "#94a3b8",
    marginBottom: 16,
  },
  legalGrid: {
    display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 12,
  },
  legalItem: {
    display: "flex", gap: 10, alignItems: "flex-start",
    padding: "10px 12px", borderRadius: 8,
    background: "rgba(255,255,255,0.03)",
    border: "1px solid rgba(255,255,255,0.06)",
  },
};
