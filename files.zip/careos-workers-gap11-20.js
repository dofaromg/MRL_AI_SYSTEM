/**
 * CareOS Workers 骨架 — 缺口 #11-20
 * 護理委派 / BI / 服務時數 / EVV / T-Log / 護理日誌 / 品質稽核 / 就醫紀錄 / 排班完整版 / 健保申報
 * origin_signature: MrLiouWord
 */
const CORS={'Access-Control-Allow-Origin':'*','Access-Control-Allow-Methods':'GET,POST,PUT,DELETE,OPTIONS','Access-Control-Allow-Headers':'Content-Type,Authorization,X-User-Id'};
const j=(d,s=200)=>new Response(JSON.stringify(d),{status:s,headers:{...CORS,'Content-Type':'application/json'}});
const er=(m,s=400)=>j({ok:false,error:m},s);
const ts=()=>new Date().toISOString();

async function initDB(db){
  await db.exec(`
    CREATE TABLE IF NOT EXISTS care_tasks(id TEXT PRIMARY KEY,title TEXT,category TEXT,status TEXT,priority TEXT,assignee TEXT,resident TEXT,due TEXT,created_at TEXT);
    CREATE TABLE IF NOT EXISTS time_logs(id TEXT PRIMARY KEY,staff_id TEXT,clock_in TEXT,clock_out TEXT,break_min INTEGER DEFAULT 0,notes TEXT);
    CREATE TABLE IF NOT EXISTS nursing_journals(id TEXT PRIMARY KEY,resident_id TEXT,nurse_id TEXT,vitals TEXT,diet TEXT,elimination TEXT,notes TEXT,problems TEXT,created_at TEXT);
    CREATE TABLE IF NOT EXISTS medical_visits(id TEXT PRIMARY KEY,resident_id TEXT,hospital TEXT,department TEXT,visit_date TEXT,diagnosis TEXT,notes TEXT,created_at TEXT);
    CREATE TABLE IF NOT EXISTS insurance_claims(id TEXT PRIMARY KEY,type TEXT,period TEXT,amount REAL,items TEXT,status TEXT,created_at TEXT);
    CREATE TABLE IF NOT EXISTS audit_logs(id TEXT PRIMARY KEY,category TEXT,result TEXT,score INTEGER,notes TEXT,auditor TEXT,created_at TEXT);
    CREATE INDEX IF NOT EXISTS idx_tasks_status ON care_tasks(status);
    CREATE INDEX IF NOT EXISTS idx_timelogs_staff ON time_logs(staff_id);
    CREATE INDEX IF NOT EXISTS idx_journals_resident ON nursing_journals(resident_id);
  `);
}

export default {
  async fetch(req,env){
    if(req.method==='OPTIONS')return new Response(null,{status:204,headers:CORS});
    const db=env.DB; await initDB(db);
    const url=new URL(req.url);const p=url.pathname;const m=req.method;
    try{
      // #11 護理委派
      if(p==='/api/tasks'){
        if(m==='GET'){const r=await db.prepare('SELECT * FROM care_tasks ORDER BY created_at DESC').all();return j({ok:true,tasks:r.results});}
        if(m==='POST'){const b=await req.json();const id='tsk'+Date.now().toString(36);await db.prepare('INSERT INTO care_tasks(id,title,category,status,priority,assignee,resident,due,created_at)VALUES(?,?,?,?,?,?,?,?,?)').bind(id,b.title,b.category||'',b.status||'pending',b.priority||'mid',b.assignee||'',b.resident||'',b.due||'',ts()).run();return j({ok:true,id},201);}
      }
      if(p.match(/^\/api\/tasks\/(.+)$/)&&m==='PUT'){const tid=p.split('/').pop();const b=await req.json();await db.prepare('UPDATE care_tasks SET status=? WHERE id=?').bind(b.status,tid).run();return j({ok:true});}

      // #13 服務時數
      if(p==='/api/timelogs'&&m==='GET'){const r=await db.prepare('SELECT * FROM time_logs ORDER BY clock_in DESC LIMIT 100').all();return j({ok:true,logs:r.results});}
      if(p==='/api/timelogs/clockin'&&m==='POST'){const b=await req.json();const id='tl'+Date.now().toString(36);await db.prepare('INSERT INTO time_logs(id,staff_id,clock_in)VALUES(?,?,?)').bind(id,b.staff_id,ts()).run();return j({ok:true,id},201);}
      if(p.match(/^\/api\/timelogs\/(.+)\/clockout$/)&&m==='POST'){const tid=p.split('/')[3];const b=await req.json().catch(()=>({}));await db.prepare('UPDATE time_logs SET clock_out=?,break_min=?,notes=? WHERE id=?').bind(ts(),b.break_min||0,b.notes||'',tid).run();return j({ok:true});}

      // #16 護理日誌
      if(p==='/api/journals'){
        if(m==='GET'){const rid=url.searchParams.get('resident_id');const r=rid?await db.prepare('SELECT * FROM nursing_journals WHERE resident_id=? ORDER BY created_at DESC').bind(rid).all():await db.prepare('SELECT * FROM nursing_journals ORDER BY created_at DESC LIMIT 50').all();return j({ok:true,journals:r.results});}
        if(m==='POST'){const b=await req.json();const id='nj'+Date.now().toString(36);await db.prepare('INSERT INTO nursing_journals(id,resident_id,nurse_id,vitals,diet,elimination,notes,problems,created_at)VALUES(?,?,?,?,?,?,?,?,?)').bind(id,b.resident_id,b.nurse_id||'',JSON.stringify(b.vitals||{}),b.diet||'',b.elimination||'',b.notes||'',b.problems||'',ts()).run();return j({ok:true,id},201);}
      }

      // #18 就醫紀錄
      if(p==='/api/medical-visits'){
        if(m==='GET'){const r=await db.prepare('SELECT * FROM medical_visits ORDER BY visit_date DESC LIMIT 100').all();return j({ok:true,visits:r.results});}
        if(m==='POST'){const b=await req.json();const id='mv'+Date.now().toString(36);await db.prepare('INSERT INTO medical_visits(id,resident_id,hospital,department,visit_date,diagnosis,notes,created_at)VALUES(?,?,?,?,?,?,?,?)').bind(id,b.resident_id,b.hospital||'',b.department||'',b.visit_date||'',b.diagnosis||'',b.notes||'',ts()).run();return j({ok:true,id},201);}
      }

      // #20 健保申報
      if(p==='/api/insurance'){
        if(m==='GET'){const r=await db.prepare('SELECT * FROM insurance_claims ORDER BY created_at DESC').all();return j({ok:true,claims:r.results});}
        if(m==='POST'){const b=await req.json();const id='ins'+Date.now().toString(36);await db.prepare('INSERT INTO insurance_claims(id,type,period,amount,items,status,created_at)VALUES(?,?,?,?,?,?,?)').bind(id,b.type||'長照',b.period||'',b.amount||0,JSON.stringify(b.items||[]),'pending',ts()).run();return j({ok:true,id},201);}
      }

      // #17 品質稽核
      if(p==='/api/audits'){
        if(m==='GET'){const r=await db.prepare('SELECT * FROM audit_logs ORDER BY created_at DESC LIMIT 50').all();return j({ok:true,audits:r.results});}
        if(m==='POST'){const b=await req.json();const id='aud'+Date.now().toString(36);await db.prepare('INSERT INTO audit_logs(id,category,result,score,notes,auditor,created_at)VALUES(?,?,?,?,?,?,?)').bind(id,b.category||'',b.result||'pass',b.score||100,b.notes||'',b.auditor||'',ts()).run();return j({ok:true,id},201);}
      }

      return er('找不到路由',404);
    }catch(e){return er('伺服器錯誤:'+e.message,500);}
  }
};
