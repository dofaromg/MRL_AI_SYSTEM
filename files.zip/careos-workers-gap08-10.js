/**
 * CareOS Workers 骨架 — 缺口 #8 排班 / #9 通知 / #10 視訊
 * origin_signature: MrLiouWord
 */
const CORS={'Access-Control-Allow-Origin':'*','Access-Control-Allow-Methods':'GET,POST,PUT,DELETE,OPTIONS','Access-Control-Allow-Headers':'Content-Type,Authorization,X-User-Id'};
const j=(d,s=200)=>new Response(JSON.stringify(d),{status:s,headers:{...CORS,'Content-Type':'application/json'}});
const er=(m,s=400)=>j({ok:false,error:m},s);
const ts=()=>new Date().toISOString();

async function initDB(db){
  await db.exec(`
    CREATE TABLE IF NOT EXISTS schedules(id TEXT PRIMARY KEY,staff_id TEXT,date TEXT,shift TEXT,created_at TEXT);
    CREATE TABLE IF NOT EXISTS notifications(id TEXT PRIMARY KEY,title TEXT,body TEXT,channels TEXT,recipients TEXT,status TEXT,sent_at TEXT,created_at TEXT);
    CREATE TABLE IF NOT EXISTS video_sessions(id TEXT PRIMARY KEY,resident_id TEXT,family_name TEXT,scheduled_at TEXT,status TEXT,duration_sec INTEGER DEFAULT 0,created_at TEXT);
    CREATE INDEX IF NOT EXISTS idx_sch_date ON schedules(date);
    CREATE INDEX IF NOT EXISTS idx_notif_status ON notifications(status);
  `);
}

export default {
  async fetch(req,env){
    if(req.method==='OPTIONS')return new Response(null,{status:204,headers:CORS});
    const db=env.DB; await initDB(db);
    const url=new URL(req.url);const p=url.pathname;const m=req.method;
    try{
      // ── #8 排班 ──────────────────────────────────
      if(p==='/api/schedules'&&m==='GET'){
        const week=url.searchParams.get('week');
        const rows=week
          ?await db.prepare('SELECT * FROM schedules WHERE date LIKE ? ORDER BY date').bind(week+'%').all()
          :await db.prepare('SELECT * FROM schedules ORDER BY date DESC LIMIT 200').all();
        return j({ok:true,schedules:rows.results});
      }
      if(p==='/api/schedules'&&m==='POST'){
        const b=await req.json();
        const{staff_id,date,shift}=b;
        if(!staff_id||!date||!shift)return er('必填欄位缺失');
        const id='sch'+Date.now().toString(36);
        await db.prepare('INSERT OR REPLACE INTO schedules(id,staff_id,date,shift,created_at)VALUES(?,?,?,?,?)')
          .bind(id,staff_id,date,shift,ts()).run();
        return j({ok:true,id},201);
      }
      if(p.match(/^\/api\/schedules\/(.+)$/)&&m==='DELETE'){
        const sid=p.split('/').pop();
        await db.prepare('DELETE FROM schedules WHERE id=?').bind(sid).run();
        return j({ok:true});
      }

      // ── #9 通知 ──────────────────────────────────
      if(p==='/api/notifications'&&m==='GET'){
        const rows=await db.prepare('SELECT * FROM notifications ORDER BY created_at DESC LIMIT 50').all();
        return j({ok:true,notifications:rows.results});
      }
      if(p==='/api/notifications'&&m==='POST'){
        const b=await req.json();
        const{title,body,channels=[],recipients=[]}=b;
        if(!title||!body)return er('title body 必填');
        const id='ntf'+Date.now().toString(36);
        await db.prepare('INSERT INTO notifications(id,title,body,channels,recipients,status,sent_at,created_at)VALUES(?,?,?,?,?,?,?,?)')
          .bind(id,title,body,JSON.stringify(channels),JSON.stringify(recipients),'sent',ts(),ts()).run();
        // 實際整合: LINE Notify / SMS / Email / Push
        return j({ok:true,id,delivered:recipients.length},201);
      }

      // ── #10 視訊 ─────────────────────────────────
      if(p==='/api/video/sessions'&&m==='GET'){
        const rows=await db.prepare('SELECT * FROM video_sessions ORDER BY scheduled_at DESC LIMIT 50').all();
        return j({ok:true,sessions:rows.results});
      }
      if(p==='/api/video/sessions'&&m==='POST'){
        const b=await req.json();
        const{resident_id,family_name,scheduled_at}=b;
        if(!resident_id||!family_name)return er('必填欄位缺失');
        const id='vid'+Date.now().toString(36);
        // 產生 WebRTC room token（實際用 Cloudflare Calls API）
        const room_token='room_'+Math.random().toString(36).slice(2,10);
        await db.prepare('INSERT INTO video_sessions(id,resident_id,family_name,scheduled_at,status,created_at)VALUES(?,?,?,?,?,?)')
          .bind(id,resident_id,family_name,scheduled_at||ts(),'scheduled',ts()).run();
        return j({ok:true,id,room_token,join_url:`https://careos.pages.dev/video/${id}`},201);
      }
      if(p.match(/^\/api\/video\/sessions\/(.+)\/end$/)&&m==='POST'){
        const vid=p.split('/')[4];
        const b=await req.json().catch(()=>({}));
        await db.prepare('UPDATE video_sessions SET status=?,duration_sec=? WHERE id=?')
          .bind('done',b.duration_sec||0,vid).run();
        return j({ok:true});
      }

      return er('找不到路由',404);
    }catch(e){return er('伺服器錯誤:'+e.message,500);}
  }
};
