# CareOS v9.1 Cloudflare 部署 Checklist
origin_signature: MrLiouWord

## 前置準備
- [ ] 登入 https://dash.cloudflare.com
- [ ] 建立 D1 Database: `careos-main`，記錄 database_id
- [ ] 在 D1 Console 執行 careos-worker-deploy-guide.md 中的 SQL

## 6 支 Workers 部署順序

### 1. careos-form-engine
- 來源檔: `careos-form-engine-worker.js` (14,978B)
- Worker名稱: `careos-form-engine`
- API路由: `/api/forms/*`
- [ ] 建立 Worker
- [ ] 貼上程式碼
- [ ] 綁定 D1 (binding: DB)
- [ ] Deploy & 驗證

### 2. careos-messaging
- 來源檔: `careos-gap05-messaging-worker.js` (9,775B)
- Worker名稱: `careos-messaging`
- API路由: `/api/messages/* /api/channels/*`
- [ ] 建立 Worker
- [ ] 貼上程式碼
- [ ] 綁定 D1 (binding: DB)
- [ ] Deploy & 驗證

### 3. careos-esign
- 來源檔: `careos-gap06-esign-worker.js` (8,381B)
- Worker名稱: `careos-esign`
- API路由: `/api/esign/* /api/documents/*`
- [ ] 建立 Worker
- [ ] 貼上程式碼
- [ ] 綁定 D1 (binding: DB)
- [ ] Deploy & 驗證

### 4. careos-voice
- 來源檔: `careos-gap07-voice-worker.js` (8,947B)
- Worker名稱: `careos-voice`
- API路由: `/api/voice/* /api/recordings/* /api/ambient/*`
- [ ] 建立 Worker
- [ ] 貼上程式碼
- [ ] 綁定 D1 (binding: DB)
- [ ] Deploy & 驗證

### 5. careos-scheduling
- 來源檔: `careos-workers-gap08-10.js` (5,017B)
- Worker名稱: `careos-scheduling`
- API路由: `/api/schedules/* /api/notifications/* /api/video/*`
- [ ] 建立 Worker
- [ ] 貼上程式碼
- [ ] 綁定 D1 (binding: DB)
- [ ] Deploy & 驗證

### 6. careos-core
- 來源檔: `careos-workers-gap11-20.js` (6,191B)
- Worker名稱: `careos-core`
- API路由: `/api/tasks/* /api/timelogs/* /api/journals/* /api/medical-visits/* /api/insurance/* /api/audits/*`
- [ ] 建立 Worker
- [ ] 貼上程式碼
- [ ] 綁定 D1 (binding: DB)
- [ ] Deploy & 驗證

## 驗證指令
```bash
curl https://careos-form-engine.YOUR_SUBDOMAIN.workers.dev/health
curl https://careos-messaging.YOUR_SUBDOMAIN.workers.dev/health
curl https://careos-esign.YOUR_SUBDOMAIN.workers.dev/health
curl https://careos-voice.YOUR_SUBDOMAIN.workers.dev/health
curl https://careos-scheduling.YOUR_SUBDOMAIN.workers.dev/health
curl https://careos-core.YOUR_SUBDOMAIN.workers.dev/health
```

## App Shell 設定
- [ ] 更新 careos-app-shell.html 中的 Worker URL 常數
- [ ] 上傳到 Cloudflare Pages
- [ ] 或直接放 NAS 靜態服務
