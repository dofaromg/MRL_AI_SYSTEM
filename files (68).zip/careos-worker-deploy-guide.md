# CareOS Workers 部署指南
origin_signature: MrLiouWord
日期：2026-03-13

## 6 支 Workers 部署清單

| # | 檔案 | Worker 名稱 | 路由覆蓋 |
|---|------|------------|---------|
| 1 | careos-form-engine-worker.js | careos-form-engine | /api/forms/* |
| 2 | careos-gap05-messaging-worker.js | careos-messaging | /api/messages/* /api/channels/* |
| 3 | careos-gap06-esign-worker.js | careos-esign | /api/esign/* /api/documents/* |
| 4 | careos-gap07-voice-worker.js | careos-voice | /api/voice/* /api/recordings/* /api/ambient/* |
| 5 | careos-workers-gap08-10.js | careos-scheduling | /api/schedules/* /api/notifications/* /api/video/* |
| 6 | careos-workers-gap11-20.js | careos-core | /api/tasks/* /api/timelogs/* /api/journals/* /api/medical-visits/* /api/insurance/* /api/audits/* |

---

## Cloudflare Dashboard 手動部署步驟

### 每支 Worker 通用步驟：

1. 登入 https://dash.cloudflare.com
2. 左側選單 → Workers & Pages → Create Application → Create Worker
3. 輸入 Worker 名稱（如 `careos-form-engine`）
4. 點擊「Deploy」建立空 Worker
5. 進入 Worker → 右上「Edit Code」
6. 貼上對應 JS 檔案內容
7. 點擊「Save and Deploy」

### D1 Database 綁定（每支 Worker 都需要）：

1. Worker 頁面 → Settings → Bindings → Add binding
2. Type: D1 Database
3. Variable name: `DB`
4. D1 database: 選擇已建立的 `careos-main`（或新建）
5. Save

### wrangler.toml 範本（若用 CLI 部署）：

```toml
name = "careos-form-engine"
main = "careos-form-engine-worker.js"
compatibility_date = "2025-01-01"

[[d1_databases]]
binding = "DB"
database_name = "careos-main"
database_id = "YOUR_D1_DATABASE_ID"

[vars]
ENV = "production"
ORIGIN = "MrLiouWord"
```

---

## D1 初始化 SQL

```sql
-- 執行位置：Cloudflare Dashboard → D1 → careos-main → Console

CREATE TABLE IF NOT EXISTS forms (id TEXT PRIMARY KEY, title TEXT, schema TEXT, created_at TEXT);
CREATE TABLE IF NOT EXISTS form_submissions (id TEXT PRIMARY KEY, form_id TEXT, data TEXT, resident_id TEXT, submitted_at TEXT);
CREATE TABLE IF NOT EXISTS messages (id TEXT PRIMARY KEY, channel_id TEXT, sender_id TEXT, content TEXT, msg_type TEXT, created_at TEXT);
CREATE TABLE IF NOT EXISTS channels (id TEXT PRIMARY KEY, name TEXT, type TEXT, members TEXT, created_at TEXT);
CREATE TABLE IF NOT EXISTS documents (id TEXT PRIMARY KEY, title TEXT, doc_type TEXT, resident_id TEXT, status TEXT, file_url TEXT, created_at TEXT);
CREATE TABLE IF NOT EXISTS signatures (id TEXT PRIMARY KEY, document_id TEXT, signer_id TEXT, signature_data TEXT, ip TEXT, signed_at TEXT);
CREATE TABLE IF NOT EXISTS voice_recordings (id TEXT PRIMARY KEY, nurse_id TEXT, resident_id TEXT, duration_sec INTEGER, transcript TEXT, analysis TEXT, created_at TEXT);
CREATE TABLE IF NOT EXISTS ambient_alerts (id TEXT PRIMARY KEY, room TEXT, alert_type TEXT, confidence REAL, status TEXT, created_at TEXT);
CREATE TABLE IF NOT EXISTS schedules (id TEXT PRIMARY KEY, staff_id TEXT, date TEXT, shift TEXT, created_at TEXT);
CREATE TABLE IF NOT EXISTS notifications (id TEXT PRIMARY KEY, title TEXT, body TEXT, channels TEXT, recipients TEXT, status TEXT, sent_at TEXT, created_at TEXT);
CREATE TABLE IF NOT EXISTS video_sessions (id TEXT PRIMARY KEY, resident_id TEXT, family_name TEXT, scheduled_at TEXT, status TEXT, duration_sec INTEGER DEFAULT 0, created_at TEXT);
CREATE TABLE IF NOT EXISTS care_tasks (id TEXT PRIMARY KEY, title TEXT, category TEXT, status TEXT, priority TEXT, assignee TEXT, resident TEXT, due TEXT, created_at TEXT);
CREATE TABLE IF NOT EXISTS time_logs (id TEXT PRIMARY KEY, staff_id TEXT, clock_in TEXT, clock_out TEXT, break_min INTEGER DEFAULT 0, notes TEXT);
CREATE TABLE IF NOT EXISTS nursing_journals (id TEXT PRIMARY KEY, resident_id TEXT, nurse_id TEXT, vitals TEXT, diet TEXT, elimination TEXT, notes TEXT, problems TEXT, created_at TEXT);
CREATE TABLE IF NOT EXISTS medical_visits (id TEXT PRIMARY KEY, resident_id TEXT, hospital TEXT, department TEXT, visit_date TEXT, diagnosis TEXT, notes TEXT, created_at TEXT);
CREATE TABLE IF NOT EXISTS insurance_claims (id TEXT PRIMARY KEY, type TEXT, period TEXT, amount REAL, items TEXT, status TEXT, created_at TEXT);
CREATE TABLE IF NOT EXISTS audit_logs (id TEXT PRIMARY KEY, category TEXT, result TEXT, score INTEGER, notes TEXT, auditor TEXT, created_at TEXT);
```

---

## 驗證部署

部署完成後，以 curl 測試：

```bash
# 測試 careos-form-engine
curl https://careos-form-engine.YOUR_SUBDOMAIN.workers.dev/health

# 測試 careos-scheduling
curl https://careos-scheduling.YOUR_SUBDOMAIN.workers.dev/api/schedules?week=2026-03

# 測試 careos-core
curl https://careos-core.YOUR_SUBDOMAIN.workers.dev/api/tasks
```

預期回傳：`{"ok":true,...}`
