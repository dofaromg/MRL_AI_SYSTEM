// ══════════════════════════════════════════════════════════════
// 愛心教養院 · 真實人臉辨識模組 v1.0
// 使用 face-api.js (SSD MobileNet v1 + FaceRecognitionNet)
// 128 維特徵向量，前端比對，不上傳臉部照片
//
// 使用前準備：
// 1. 下載模型檔案到 /public/models/
//    https://github.com/justadudewhohacks/face-api.js/tree/master/weights
//    需要: ssd_mobilenetv1_model-* + face_recognition_model-*
// 2. 安裝: npm install face-api.js
// ══════════════════════════════════════════════════════════════

import * as faceapi from "face-api.js";
import { useState, useEffect, useRef, useCallback } from "react";

// ── 設定 ──────────────────────────────────────────────────────
const MODELS_URL     = "/models";          // 模型檔案位置
const MATCH_THRESHOLD = 0.5;               // 歐式距離門檻（越小越嚴）
const SAMPLE_COUNT   = 5;                  // 登記時採樣次數
const DETECT_INTERVAL = 600;              // 辨識掃描間隔 ms

// ── 模型載入狀態 ──────────────────────────────────────────────
let modelsLoaded = false;
let modelsLoading = false;

export async function loadFaceModels(onProgress) {
  if (modelsLoaded) return true;
  if (modelsLoading) {
    // 等待載入完成
    while (modelsLoading) await new Promise(r => setTimeout(r, 100));
    return modelsLoaded;
  }
  modelsLoading = true;
  try {
    onProgress?.("載入 SSD MobileNet...", 20);
    await faceapi.nets.ssdMobilenetv1.loadFromUri(MODELS_URL);

    onProgress?.("載入人臉特徵網路...", 60);
    await faceapi.nets.faceRecognitionNet.loadFromUri(MODELS_URL);

    onProgress?.("載入特徵點偵測器...", 80);
    await faceapi.nets.faceLandmark68Net.loadFromUri(MODELS_URL);

    modelsLoaded = true;
    onProgress?.("就緒", 100);
    return true;
  } catch (e) {
    console.error("模型載入失敗:", e);
    return false;
  } finally {
    modelsLoading = false;
  }
}

// ── 從 video 元素擷取人臉描述子 ──────────────────────────────
export async function detectFace(videoEl) {
  if (!modelsLoaded) throw new Error("模型尚未載入");
  const detection = await faceapi
    .detectSingleFace(videoEl, new faceapi.SsdMobilenetv1Options({ minConfidence: 0.5 }))
    .withFaceLandmarks()
    .withFaceDescriptor();
  return detection || null;
}

// ── 比對描述子（歐式距離）────────────────────────────────────
export function matchDescriptor(queryDescriptor, labeledDescriptors) {
  if (!labeledDescriptors?.length) return null;
  const matcher = new faceapi.FaceMatcher(
    labeledDescriptors.map(ld =>
      new faceapi.LabeledFaceDescriptors(ld.employee_id, [
        new Float32Array(ld.descriptor)
      ])
    ),
    MATCH_THRESHOLD
  );
  const result = matcher.findBestMatch(queryDescriptor);
  if (result.label === "unknown") return null;
  return {
    employee_id: result.label,
    distance: result.distance,
    confidence: Math.round((1 - result.distance / MATCH_THRESHOLD) * 100),
  };
}

// ═════════════════════════════════════════════════════════════
// Hook: useFaceEnroll — 人臉登記流程
// ═════════════════════════════════════════════════════════════
export function useFaceEnroll(videoRef) {
  const [step, setStep]       = useState("idle");  // idle|detecting|sampling|done|error
  const [samples, setSamples] = useState([]);
  const [progress, setProgress] = useState(0);
  const [error, setError]     = useState(null);
  const frameRef = useRef(null);

  const SAMPLE_LABELS = ["正面", "向左轉", "向右轉", "微微仰頭", "微微低頭"];

  const startEnroll = useCallback(async () => {
    setStep("detecting");
    setSamples([]);
    setProgress(0);
    setError(null);

    if (!modelsLoaded) {
      const ok = await loadFaceModels();
      if (!ok) { setStep("error"); setError("模型載入失敗"); return; }
    }
  }, []);

  const captureSample = useCallback(async () => {
    if (!videoRef.current) return;
    try {
      const detection = await detectFace(videoRef.current);
      if (!detection) {
        setError("未偵測到人臉，請確認臉部清晰可見");
        return;
      }
      setError(null);
      const newSamples = [...samples, Array.from(detection.descriptor)];
      setSamples(newSamples);
      setProgress(Math.round(newSamples.length / SAMPLE_COUNT * 100));
      if (newSamples.length >= SAMPLE_COUNT) {
        // 平均所有採樣作為最終描述子
        const avgDescriptor = averageDescriptors(newSamples);
        setStep("done");
        return avgDescriptor;
      } else {
        setStep("detecting");
      }
    } catch (e) {
      setError(e.message);
    }
  }, [samples, videoRef]);

  const reset = useCallback(() => {
    setStep("idle");
    setSamples([]);
    setProgress(0);
    setError(null);
  }, []);

  return {
    step, samples, progress, error,
    sampleCount: samples.length,
    totalSamples: SAMPLE_COUNT,
    sampleLabel: SAMPLE_LABELS[samples.length] || "完成",
    startEnroll, captureSample, reset,
  };
}

// ═════════════════════════════════════════════════════════════
// Hook: useFaceRecognition — 即時辨識流程
// ═════════════════════════════════════════════════════════════
export function useFaceRecognition(videoRef, labeledDescriptors) {
  const [status, setStatus]   = useState("idle");  // idle|scanning|matched|nomatch
  const [result, setResult]   = useState(null);
  const [fps, setFps]         = useState(0);
  const scanRef = useRef(null);
  const fpsRef  = useRef({ count: 0, last: Date.now() });

  const startScan = useCallback(async () => {
    if (!modelsLoaded) {
      const ok = await loadFaceModels();
      if (!ok) return;
    }
    setStatus("scanning");
    setResult(null);

    const scan = async () => {
      if (!videoRef.current) return;
      try {
        const detection = await detectFace(videoRef.current);

        // FPS 計算
        fpsRef.current.count++;
        const now = Date.now();
        if (now - fpsRef.current.last > 1000) {
          setFps(fpsRef.current.count);
          fpsRef.current = { count: 0, last: now };
        }

        if (detection) {
          const match = matchDescriptor(detection.descriptor, labeledDescriptors);
          if (match) {
            setResult(match);
            setStatus("matched");
            return; // 停止掃描
          }
        }
        scanRef.current = setTimeout(scan, DETECT_INTERVAL);
      } catch (e) {
        console.error("辨識錯誤:", e);
        scanRef.current = setTimeout(scan, DETECT_INTERVAL * 2);
      }
    };
    scan();
  }, [videoRef, labeledDescriptors]);

  const stopScan = useCallback(() => {
    clearTimeout(scanRef.current);
    setStatus("idle");
  }, []);

  const reset = useCallback(() => {
    clearTimeout(scanRef.current);
    setStatus("idle");
    setResult(null);
  }, []);

  useEffect(() => () => clearTimeout(scanRef.current), []);

  return { status, result, fps, startScan, stopScan, reset };
}

// ── 輔助函式 ──────────────────────────────────────────────────
function averageDescriptors(descriptors) {
  const len = descriptors[0].length;
  const avg = new Array(len).fill(0);
  for (const d of descriptors) for (let i = 0; i < len; i++) avg[i] += d[i];
  for (let i = 0; i < len; i++) avg[i] /= descriptors.length;
  return avg;
}

// ═════════════════════════════════════════════════════════════
// FaceEnrollUI — 登記介面元件
// ═════════════════════════════════════════════════════════════
const T = {
  teal: "#0D9488", teal2: "#0F766E",
  tealBg: "rgba(13,148,136,0.08)",
  red: "#FF3B30", redBg: "rgba(255,59,48,0.08)",
  green: "#34C759", greenBg: "rgba(52,199,89,0.08)",
  amber: "#FF9500",
  bg: "#F2F2F7", label: "#000", label2: "rgba(60,60,67,0.6)", label3: "rgba(60,60,67,0.3)",
  separator: "rgba(60,60,67,0.12)",
  shadowTeal: "0 4px 20px rgba(13,148,136,0.3)",
};
const SP = "cubic-bezier(0.34,1.56,0.64,1)";

export function FaceEnrollUI({ employee, onComplete, onCancel, apiBase }) {
  const videoRef  = useRef(null);
  const streamRef = useRef(null);
  const enroll    = useFaceEnroll(videoRef);
  const [modelProgress, setModelProgress] = useState(0);
  const [modelStatus, setModelStatus]     = useState("idle"); // idle|loading|ready

  // 啟動相機
  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "user", width: { ideal: 640 }, height: { ideal: 480 } }
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
      }
    } catch (e) {
      console.error("相機啟動失敗:", e);
    }
  };

  const stopCamera = () => {
    streamRef.current?.getTracks().forEach(t => t.stop());
  };

  useEffect(() => {
    // 載入模型
    setModelStatus("loading");
    loadFaceModels((msg, pct) => setModelProgress(pct)).then(ok => {
      setModelStatus(ok ? "ready" : "error");
      if (ok) startCamera();
    });
    return () => stopCamera();
  }, []);

  // 採樣並儲存
  const handleCapture = async () => {
    const descriptor = await enroll.captureSample();
    if (descriptor && enroll.sampleCount + 1 >= enroll.totalSamples) {
      // 儲存到 API
      try {
        await fetch(`${apiBase}/api/face/enroll`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ employee_id: employee.id, descriptor }),
        });
        onComplete?.(employee, descriptor);
      } catch (e) {
        console.error("儲存失敗:", e);
      }
    }
  };

  const isDone = enroll.step === "done";

  return (
    <div style={{ padding: 16 }}>
      {/* 員工資訊 */}
      <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 14 }}>
        <div style={{ width: 42, height: 42, borderRadius: "50%", background: `linear-gradient(135deg,${T.teal},${T.teal2})`, display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontWeight: 700, fontSize: 18 }}>{employee.name[0]}</div>
        <div><div style={{ fontWeight: 700, fontSize: 16 }}>{employee.name}</div><div style={{ fontSize: 12, color: T.label2 }}>{employee.dept} · {employee.id}</div></div>
      </div>

      {/* 模型載入進度 */}
      {modelStatus === "loading" && (
        <div style={{ marginBottom: 12, padding: 12, background: T.tealBg, borderRadius: 12 }}>
          <div style={{ fontSize: 13, fontWeight: 600, color: T.teal, marginBottom: 6 }}>載入人臉辨識模型... {modelProgress}%</div>
          <div style={{ height: 4, background: "rgba(13,148,136,.2)", borderRadius: 2 }}>
            <div style={{ height: "100%", width: `${modelProgress}%`, background: T.teal, borderRadius: 2, transition: "width .3s ease" }} />
          </div>
        </div>
      )}

      {/* 相機視窗 */}
      <div style={{ position: "relative", borderRadius: 16, overflow: "hidden", background: "#111", aspectRatio: "4/3", marginBottom: 14 }}>
        <video ref={videoRef} autoPlay playsInline muted style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }} />
        {/* 角落定位框 */}
        {["tl","tr","bl","br"].map(pos => (
          <div key={pos} style={{
            position: "absolute",
            top: pos.startsWith("t") ? 12 : undefined,
            bottom: pos.startsWith("b") ? 12 : undefined,
            left: pos.endsWith("l") ? 12 : undefined,
            right: pos.endsWith("r") ? 12 : undefined,
            width: 28, height: 28,
            borderTop: pos.startsWith("t") ? `3px solid ${T.teal}` : undefined,
            borderBottom: pos.startsWith("b") ? `3px solid ${T.teal}` : undefined,
            borderLeft: pos.endsWith("l") ? `3px solid ${T.teal}` : undefined,
            borderRight: pos.endsWith("r") ? `3px solid ${T.teal}` : undefined,
            borderRadius: pos === "tl" ? "8px 0 0 0" : pos === "tr" ? "0 8px 0 0" : pos === "bl" ? "0 0 0 8px" : "0 0 8px 0",
          }} />
        ))}
        {/* 採樣計數 */}
        <div style={{ position: "absolute", top: 10, left: "50%", transform: "translateX(-50%)", background: "rgba(0,0,0,.65)", backdropFilter: "blur(4px)", color: "#fff", padding: "4px 14px", borderRadius: 100, fontSize: 11, fontFamily: "JetBrains Mono", whiteSpace: "nowrap" }}>
          {isDone ? "✅ 登記完成" : modelStatus !== "ready" ? "⏳ 載入中..." : `📸 採樣 ${enroll.sampleCount}/${enroll.totalSamples} · ${enroll.sampleLabel}`}
        </div>
      </div>

      {/* 進度條 */}
      <div style={{ height: 6, background: T.separator, borderRadius: 3, marginBottom: 14, overflow: "hidden" }}>
        <div style={{ height: "100%", width: `${enroll.progress}%`, background: isDone ? T.green : T.teal, borderRadius: 3, transition: `width .4s cubic-bezier(0.4,0,0.2,1)` }} />
      </div>

      {/* 採樣點指示 */}
      <div style={{ display: "flex", gap: 8, justifyContent: "center", marginBottom: 16 }}>
        {Array.from({ length: enroll.totalSamples }).map((_, i) => (
          <div key={i} style={{
            width: 32, height: 32, borderRadius: "50%",
            background: i < enroll.sampleCount ? T.tealBg : T.bg,
            border: `2px solid ${i < enroll.sampleCount ? T.teal : T.separator}`,
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 11, fontWeight: 700,
            color: i < enroll.sampleCount ? T.teal : T.label3,
            transition: `all .3s ${SP}`,
            transform: i === enroll.sampleCount ? "scale(1.15)" : "scale(1)",
          }}>
            {i < enroll.sampleCount ? "✓" : i + 1}
          </div>
        ))}
      </div>

      {/* 錯誤訊息 */}
      {enroll.error && (
        <div style={{ padding: "10px 14px", background: T.redBg, borderRadius: 12, fontSize: 13, color: T.red, marginBottom: 12, textAlign: "center" }}>
          ⚠️ {enroll.error}
        </div>
      )}

      {/* 按鈕 */}
      {isDone ? (
        <div style={{ textAlign: "center" }}>
          <div style={{ fontSize: 48, marginBottom: 8, animation: `spring .5s both` }}>✅</div>
          <div style={{ fontWeight: 700, fontSize: 17, marginBottom: 4 }}>人臉登記成功！</div>
          <div style={{ fontSize: 13, color: T.label2, marginBottom: 16 }}>已採樣 {enroll.totalSamples} 個角度</div>
          <button onClick={onComplete} style={{ padding: "14px 32px", borderRadius: 14, background: `linear-gradient(135deg,${T.teal},${T.teal2})`, color: "#fff", fontSize: 15, fontWeight: 700, cursor: "pointer", border: "none", boxShadow: T.shadowTeal }}>
            登記下一位 →
          </button>
        </div>
      ) : (
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
          <button
            onClick={handleCapture}
            disabled={modelStatus !== "ready"}
            style={{ padding: 16, borderRadius: 14, background: modelStatus !== "ready" ? T.separator : `linear-gradient(135deg,${T.teal},${T.teal2})`, color: "#fff", fontSize: 15, fontWeight: 700, cursor: modelStatus !== "ready" ? "not-allowed" : "pointer", border: "none", opacity: modelStatus !== "ready" ? 0.5 : 1 }}>
            📸 拍照採樣
          </button>
          <button onClick={() => { enroll.reset(); onCancel?.(); }} style={{ padding: 16, borderRadius: 14, background: T.bg, color: T.label2, fontSize: 15, fontWeight: 600, cursor: "pointer", border: "none" }}>
            取消
          </button>
        </div>
      )}
    </div>
  );
}

// ═════════════════════════════════════════════════════════════
// FaceRecognitionUI — 即時辨識介面元件
// ═════════════════════════════════════════════════════════════
export function FaceRecognitionUI({ punchType = "in", labeledDescriptors = [], employees = [], onPunch, onCancel }) {
  const videoRef  = useRef(null);
  const streamRef = useRef(null);
  const recog     = useFaceRecognition(videoRef, labeledDescriptors);
  const [cameraReady, setCameraReady] = useState(false);
  const [modelReady, setModelReady]   = useState(false);

  const matchedEmp = recog.result
    ? employees.find(e => e.id === recog.result.employee_id)
    : null;

  useEffect(() => {
    const init = async () => {
      // 載入模型
      const ok = await loadFaceModels();
      setModelReady(ok);
      // 啟動相機
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "user" } });
        streamRef.current = stream;
        if (videoRef.current) { videoRef.current.srcObject = stream; await videoRef.current.play(); }
        setCameraReady(true);
        if (ok) recog.startScan();
      } catch (e) { console.error("相機失敗:", e); }
    };
    init();
    return () => {
      recog.stopScan();
      streamRef.current?.getTracks().forEach(t => t.stop());
    };
  }, []);

  const confirmPunch = () => {
    if (!matchedEmp || !recog.result) return;
    onPunch?.({
      employee: matchedEmp,
      type: punchType,
      method: "face",
      confidence: recog.result.confidence,
      distance: recog.result.distance,
    });
  };

  const colorMap = { in: T.teal, out: "#FF3B30" };
  const color = colorMap[punchType] || T.teal;

  return (
    <div style={{ padding: 16 }}>
      <div style={{ textAlign: "center", marginBottom: 12 }}>
        <span style={{ fontSize: 13, fontWeight: 700, color, letterSpacing: 1, textTransform: "uppercase" }}>
          {punchType === "in" ? "🟢 上班打卡" : "🔴 下班打卡"} · 人臉辨識
        </span>
      </div>

      {/* 相機 */}
      <div style={{ position: "relative", borderRadius: 16, overflow: "hidden", background: "#000", aspectRatio: "4/3", marginBottom: 14 }}>
        <video ref={videoRef} autoPlay playsInline muted style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }} />

        {/* 辨識動畫 */}
        {recog.status === "scanning" && (
          <div style={{ position: "absolute", left: 0, right: 0, height: 2, background: `linear-gradient(90deg,transparent,${color},transparent)`, animation: "scanLine 1.2s ease-in-out infinite" }} />
        )}

        {/* 辨識成功疊加 */}
        {recog.status === "matched" && matchedEmp && (
          <div style={{ position: "absolute", inset: 0, background: "rgba(0,0,0,.55)", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 8, animation: "fadeIn .3s" }}>
            <div style={{ width: 70, height: 70, borderRadius: "50%", background: `linear-gradient(135deg,${T.teal},${T.teal2})`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 30, fontWeight: 700, color: "#fff", border: "3px solid rgba(255,255,255,.8)" }}>{matchedEmp.name[0]}</div>
            <div style={{ color: "#fff", fontWeight: 800, fontSize: 22 }}>{matchedEmp.name}</div>
            <div style={{ color: "rgba(255,255,255,.7)", fontSize: 13 }}>{matchedEmp.dept}</div>
            <div style={{ background: "rgba(13,148,136,.3)", color: "#5EEAD4", padding: "3px 12px", borderRadius: 100, fontSize: 12, fontFamily: "JetBrains Mono" }}>
              信心度 {recog.result.confidence}%
            </div>
          </div>
        )}

        {/* 狀態標籤 */}
        <div style={{ position: "absolute", top: 10, left: "50%", transform: "translateX(-50%)", background: "rgba(0,0,0,.65)", backdropFilter: "blur(4px)", color: recog.status === "scanning" ? color : "#fff", padding: "4px 14px", borderRadius: 100, fontSize: 11, fontFamily: "JetBrains Mono", whiteSpace: "nowrap" }}>
          {!modelReady ? "⏳ 載入模型..." : !cameraReady ? "📷 啟動相機..." : recog.status === "scanning" ? `🔍 辨識中... ${recog.fps}fps` : recog.status === "matched" ? "✅ 辨識成功" : "📷 就緒"}
        </div>
        {/* FPS 角落顯示 */}
        {recog.status === "scanning" && (
          <div style={{ position: "absolute", bottom: 10, right: 10, background: "rgba(0,0,0,.5)", color: "rgba(255,255,255,.5)", padding: "2px 8px", borderRadius: 6, fontSize: 10, fontFamily: "JetBrains Mono" }}>
            {recog.fps} fps
          </div>
        )}
      </div>

      {/* 按鈕 */}
      {recog.status === "matched" && matchedEmp ? (
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
          <button onClick={confirmPunch} style={{ padding: 16, borderRadius: 14, background: `linear-gradient(135deg,${color},${color}cc)`, color: "#fff", fontSize: 15, fontWeight: 700, cursor: "pointer", border: "none" }}>
            ✅ 確認打卡
          </button>
          <button onClick={recog.reset} style={{ padding: 16, borderRadius: 14, background: T.bg, color: T.label2, fontSize: 15, fontWeight: 600, cursor: "pointer", border: "none" }}>
            🔄 重新辨識
          </button>
        </div>
      ) : (
        <button onClick={onCancel} style={{ width: "100%", padding: 14, borderRadius: 14, background: T.bg, color: T.label2, fontSize: 14, fontWeight: 600, cursor: "pointer", border: "none" }}>
          取消
        </button>
      )}

      {/* 未登記提示 */}
      {recog.status === "scanning" && labeledDescriptors.length === 0 && (
        <div style={{ marginTop: 10, padding: "10px 14px", background: T.tealBg, borderRadius: 12, fontSize: 13, color: T.teal, textAlign: "center" }}>
          ⚠️ 尚無員工登記人臉資料，請先至「登記」頁面完成登記
        </div>
      )}
    </div>
  );
}
