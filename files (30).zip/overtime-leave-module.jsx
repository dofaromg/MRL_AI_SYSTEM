// ══════════════════════════════════════════════════════════════
// 愛心教養院 · 加班記錄 + 年假餘額模組 v1.0
// ══════════════════════════════════════════════════════════════

// ── D1 Schema 補充（加進 schema.sql）────────────────────────
/*
-- 加班申請表
CREATE TABLE IF NOT EXISTS overtime_records (
  id          TEXT PRIMARY KEY,
  employee_id TEXT NOT NULL REFERENCES employees(id),
  date        TEXT NOT NULL,
  start_time  TEXT NOT NULL,   -- 下班時間（正常班）
  end_time    TEXT NOT NULL,   -- 實際結束時間
  hours       REAL NOT NULL,   -- 加班時數
  reason      TEXT,
  comp_type   TEXT DEFAULT 'overtime_pay',  -- overtime_pay / comp_leave
  status      TEXT DEFAULT 'pending',       -- pending/approved/rejected
  approved_by TEXT REFERENCES employees(id),
  created_at  TEXT DEFAULT (datetime('now'))
);

-- 年假餘額表（每年初重置）
CREATE TABLE IF NOT EXISTS leave_balance (
  employee_id TEXT NOT NULL REFERENCES employees(id),
  year        INTEGER NOT NULL,
  leave_type  TEXT NOT NULL,   -- 年假/補休
  total       REAL NOT NULL,   -- 總天數
  used        REAL DEFAULT 0,  -- 已用天數
  remaining   REAL GENERATED ALWAYS AS (total - used) VIRTUAL,
  PRIMARY KEY (employee_id, year, leave_type)
);

CREATE INDEX IF NOT EXISTS idx_overtime_emp ON overtime_records(employee_id);
CREATE INDEX IF NOT EXISTS idx_overtime_date ON overtime_records(date);
CREATE INDEX IF NOT EXISTS idx_balance_emp ON leave_balance(employee_id, year);
*/

import { useState, useMemo } from "react";

const T = {
  teal: "#0D9488", teal2: "#0F766E",
  tealBg: "rgba(13,148,136,0.08)",
  red: "#FF3B30", redBg: "rgba(255,59,48,0.08)",
  amber: "#FF9500", amberBg: "rgba(255,149,0,0.08)",
  green: "#34C759", greenBg: "rgba(52,199,89,0.08)",
  blue: "#007AFF", blueBg: "rgba(0,122,255,0.08)",
  purple: "#5856D6",
  bg: "#F2F2F7", card: "#fff",
  label: "#000", label2: "rgba(60,60,67,0.6)", label3: "rgba(60,60,67,0.3)",
  separator: "rgba(60,60,67,0.12)",
  shadow2: "0 4px 12px rgba(0,0,0,0.08)",
};
const SP = "cubic-bezier(0.34,1.56,0.64,1)";

// ── 加班時數計算 ──────────────────────────────────────────────
export function calcOvertimeHours(startTime, endTime) {
  const [sh, sm] = startTime.split(":").map(Number);
  const [eh, em] = endTime.split(":").map(Number);
  let mins = (eh * 60 + em) - (sh * 60 + sm);
  if (mins < 0) mins += 24 * 60; // 跨午夜
  return Math.max(0, (mins / 60)).toFixed(1);
}

// ── 年假天數計算（依年資）────────────────────────────────────
export function calcAnnualLeave(yearsOfService) {
  // 依勞基法
  if (yearsOfService < 1) return 0;
  if (yearsOfService < 2) return 3;
  if (yearsOfService < 3) return 7;
  if (yearsOfService < 5) return 10;
  if (yearsOfService < 10) return 14;
  return Math.min(14 + (yearsOfService - 10), 30); // 每年+1，最多30
}

// ── Mock 資料 ─────────────────────────────────────────────────
const MOCK_OVERTIME = [
  { id: "OT001", employee_id: "E001", name: "王小明", date: "03/04", start_time: "17:00", end_time: "20:30", hours: 3.5, reason: "月底結算", comp_type: "overtime_pay", status: "approved" },
  { id: "OT002", employee_id: "E002", name: "林淑芬", date: "03/05", start_time: "17:00", end_time: "19:00", hours: 2.0, reason: "照護緊急狀況", comp_type: "comp_leave", status: "pending" },
  { id: "OT003", employee_id: "E003", name: "陳志偉", date: "03/06", start_time: "23:00", end_time: "01:00", hours: 2.0, reason: "大夜代班", comp_type: "overtime_pay", status: "pending" },
];

const MOCK_BALANCE = [
  { employee_id: "E001", name: "王小明", dept: "照護一組", years: 5, annual_total: 14, annual_used: 3, sick_total: 30, sick_used: 1, comp_total: 3.5, comp_used: 0 },
  { employee_id: "E002", name: "林淑芬", dept: "照護二組", years: 3, annual_total: 10, annual_used: 5, sick_total: 30, sick_used: 4, comp_total: 2.0, comp_used: 1 },
  { employee_id: "E003", name: "陳志偉", dept: "護理組",   years: 1, annual_total: 7,  annual_used: 2, sick_total: 30, sick_used: 0, comp_total: 0,   comp_used: 0 },
  { employee_id: "E004", name: "張雅婷", dept: "行政組",   years: 7, annual_total: 14, annual_used: 8, sick_total: 30, sick_used: 2, comp_total: 0,   comp_used: 0 },
];

// ═════════════════════════════════════════════════════════════
// OvertimeModule — 加班管理介面
// ═════════════════════════════════════════════════════════════
export function OvertimeModule({ isAdmin, currentEmpId }) {
  const [sub, setSub] = useState("list");
  const [records, setRecords] = useState(MOCK_OVERTIME);
  const [form, setForm] = useState({ date: "", start: "17:00", end: "", reason: "", compType: "overtime_pay" });
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState(false);

  const myRecords = isAdmin ? records : records.filter(r => r.employee_id === currentEmpId);
  const pendingCount = records.filter(r => r.status === "pending").length;

  const submitOvertime = async () => {
    if (!form.date || !form.end) return;
    setSubmitting(true);
    await new Promise(r => setTimeout(r, 600));
    const hours = parseFloat(calcOvertimeHours(form.start, form.end));
    setRecords(prev => [{
      id: `OT${Date.now()}`, employee_id: currentEmpId || "E002", name: "林淑芬",
      date: form.date, start_time: form.start, end_time: form.end,
      hours, reason: form.reason, comp_type: form.compType, status: "pending",
    }, ...prev]);
    setSubmitting(false);
    setDone(true);
    setTimeout(() => { setDone(false); setSub("list"); }, 2000);
  };

  const approve = (id) => setRecords(prev => prev.map(r => r.id === id ? { ...r, status: "approved" } : r));
  const reject  = (id) => setRecords(prev => prev.map(r => r.id === id ? { ...r, status: "rejected" } : r));

  const statusColor = { pending: T.amber, approved: T.green, rejected: T.red };
  const statusLabel = { pending: "待審", approved: "核准", rejected: "拒絕" };
  const typeLabel   = { overtime_pay: "加班費", comp_leave: "補休" };
  const typeColor   = { overtime_pay: T.amber, comp_leave: T.blue };

  return (
    <div style={{ flex: 1, display: "flex", flexDirection: "column" }}>
      {/* Sub nav */}
      <div style={{ background: "rgba(255,255,255,.72)", backdropFilter: "blur(20px)", borderBottom: `1px solid ${T.separator}`, display: "flex", padding: "10px 12px 0", gap: 4, flexShrink: 0 }}>
        {[
          { id: "list", i: "📋", l: "記錄" },
          { id: "apply", i: "➕", l: "申請" },
          ...(isAdmin ? [{ id: "review", i: "✅", l: `審核${pendingCount > 0 ? ` (${pendingCount})` : ""}` }] : []),
        ].map(t => (
          <button key={t.id} onClick={() => setSub(t.id)} style={{ flex: 1, padding: "8px 4px", borderRadius: "10px 10px 0 0", fontSize: 11, fontWeight: 700, background: sub === t.id ? "#fff" : "transparent", color: sub === t.id ? T.teal : T.label2, border: "none", cursor: "pointer", boxShadow: sub === t.id ? T.shadow2 : "none", display: "flex", flexDirection: "column", alignItems: "center", gap: 3 }}>
            <span style={{ fontSize: 18 }}>{t.i}</span>{t.l}
          </button>
        ))}
      </div>

      <div style={{ flex: 1, overflow: "auto", padding: "16px 16px 80px" }}>
        {/* ── 記錄列表 ── */}
        {sub === "list" && (
          <>
            <div style={{ fontSize: 20, fontWeight: 700, marginBottom: 14 }}>加班記錄</div>
            {/* 統計 */}
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 8, marginBottom: 14 }}>
              {[
                { l: "本月加班", v: `${myRecords.filter(r => r.status === "approved").reduce((s, r) => s + r.hours, 0).toFixed(1)}h`, c: T.amber },
                { l: "待審核", v: myRecords.filter(r => r.status === "pending").length, c: T.blue },
                { l: "補休剩餘", v: "3.5h", c: T.green },
              ].map(s => (
                <div key={s.l} style={{ background: T.card, borderRadius: 14, padding: "12px 8px", textAlign: "center", boxShadow: T.shadow2 }}>
                  <div style={{ fontSize: 20, fontWeight: 800, color: s.c, fontFamily: "JetBrains Mono" }}>{s.v}</div>
                  <div style={{ fontSize: 10, color: T.label3, marginTop: 2 }}>{s.l}</div>
                </div>
              ))}
            </div>
            <div style={{ background: T.card, borderRadius: 16, padding: "0 16px", boxShadow: T.shadow2 }}>
              {myRecords.length === 0 && <div style={{ padding: "24px 0", textAlign: "center", color: T.label3, fontSize: 14 }}>尚無加班記錄</div>}
              {myRecords.map((r, i) => (
                <div key={r.id} style={{ display: "flex", alignItems: "center", gap: 12, padding: "13px 0", borderBottom: i < myRecords.length - 1 ? `1px solid ${T.separator}` : "none" }}>
                  <div style={{ width: 40, height: 40, borderRadius: 12, background: T.amberBg, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 20, flexShrink: 0 }}>⏱</div>
                  <div style={{ flex: 1 }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 2 }}>
                      {isAdmin && <span style={{ fontWeight: 600, fontSize: 14 }}>{r.name}</span>}
                      <span style={{ fontSize: 12, color: T.label3 }}>{r.date}</span>
                      <span style={{ fontSize: 11, padding: "1px 7px", borderRadius: 100, background: `${typeColor[r.comp_type]}18`, color: typeColor[r.comp_type], fontWeight: 700 }}>{typeLabel[r.comp_type]}</span>
                    </div>
                    <div style={{ fontSize: 13, color: T.label2 }}>{r.start_time} – {r.end_time} · <span style={{ color: T.amber, fontFamily: "JetBrains Mono", fontWeight: 700 }}>{r.hours}h</span></div>
                    {r.reason && <div style={{ fontSize: 11, color: T.label3, marginTop: 1 }}>{r.reason}</div>}
                  </div>
                  <span style={{ fontSize: 11, padding: "3px 10px", borderRadius: 100, background: `${statusColor[r.status]}18`, color: statusColor[r.status], fontWeight: 700, flexShrink: 0 }}>{statusLabel[r.status]}</span>
                </div>
              ))}
            </div>
          </>
        )}

        {/* ── 申請加班 ── */}
        {sub === "apply" && (
          <div>
            <div style={{ fontSize: 20, fontWeight: 700, marginBottom: 16 }}>申請加班</div>
            {done ? (
              <div style={{ textAlign: "center", padding: "30px 0" }}>
                <div style={{ fontSize: 56, marginBottom: 12 }}>✅</div>
                <div style={{ fontWeight: 700, fontSize: 18 }}>申請已送出</div>
              </div>
            ) : (
              <div style={{ background: T.card, borderRadius: 16, padding: 20, boxShadow: T.shadow2 }}>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 12 }}>
                  <div>
                    <label style={{ fontSize: 12, fontWeight: 700, color: T.label2, display: "block", marginBottom: 5 }}>加班日期</label>
                    <input type="date" value={form.date} onChange={e => setForm(f => ({ ...f, date: e.target.value }))} style={{ width: "100%", padding: "11px 12px", borderRadius: 11, fontSize: 14, background: T.bg, border: `1.5px solid ${T.separator}`, color: T.label, outline: "none" }} />
                  </div>
                  <div>
                    <label style={{ fontSize: 12, fontWeight: 700, color: T.label2, display: "block", marginBottom: 5 }}>補休方式</label>
                    <select value={form.compType} onChange={e => setForm(f => ({ ...f, compType: e.target.value }))} style={{ width: "100%", padding: "11px 12px", borderRadius: 11, fontSize: 14, background: T.bg, border: `1.5px solid ${T.separator}`, color: T.label, outline: "none" }}>
                      <option value="overtime_pay">💰 加班費</option>
                      <option value="comp_leave">🔄 補休假</option>
                    </select>
                  </div>
                </div>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 12 }}>
                  <div>
                    <label style={{ fontSize: 12, fontWeight: 700, color: T.label2, display: "block", marginBottom: 5 }}>開始時間</label>
                    <input type="time" value={form.start} onChange={e => setForm(f => ({ ...f, start: e.target.value }))} style={{ width: "100%", padding: "11px 12px", borderRadius: 11, fontSize: 14, background: T.bg, border: `1.5px solid ${T.separator}`, color: T.label, outline: "none", fontFamily: "JetBrains Mono" }} />
                  </div>
                  <div>
                    <label style={{ fontSize: 12, fontWeight: 700, color: T.label2, display: "block", marginBottom: 5 }}>結束時間</label>
                    <input type="time" value={form.end} onChange={e => setForm(f => ({ ...f, end: e.target.value }))} style={{ width: "100%", padding: "11px 12px", borderRadius: 11, fontSize: 14, background: T.bg, border: `1.5px solid ${T.separator}`, color: T.label, outline: "none", fontFamily: "JetBrains Mono" }} />
                  </div>
                </div>
                {/* 預算時數 */}
                {form.start && form.end && (
                  <div style={{ marginBottom: 12, padding: "10px 14px", background: T.amberBg, borderRadius: 12, display: "flex", justifyContent: "space-between" }}>
                    <span style={{ fontSize: 13, color: T.amber }}>預計加班時數</span>
                    <span style={{ fontFamily: "JetBrains Mono", fontWeight: 800, color: T.amber }}>{calcOvertimeHours(form.start, form.end)} 小時</span>
                  </div>
                )}
                <div style={{ marginBottom: 16 }}>
                  <label style={{ fontSize: 12, fontWeight: 700, color: T.label2, display: "block", marginBottom: 5 }}>加班原因</label>
                  <textarea value={form.reason} onChange={e => setForm(f => ({ ...f, reason: e.target.value }))} rows={2} placeholder="請填寫加班原因..." style={{ width: "100%", padding: "11px 12px", borderRadius: 11, fontSize: 14, background: T.bg, border: `1.5px solid ${T.separator}`, color: T.label, outline: "none", resize: "none", fontFamily: "inherit" }} />
                </div>
                <button onClick={submitOvertime} disabled={submitting || !form.date || !form.end} style={{ width: "100%", padding: 16, borderRadius: 14, background: !form.date || !form.end ? T.separator : `linear-gradient(135deg,${T.amber},#E08500)`, color: "#fff", fontSize: 16, fontWeight: 700, border: "none", cursor: !form.date || !form.end ? "not-allowed" : "pointer", opacity: !form.date || !form.end ? 0.5 : 1 }}>
                  {submitting ? "送出中..." : "📤 送出申請"}
                </button>
              </div>
            )}
          </div>
        )}

        {/* ── 管理員審核 ── */}
        {sub === "review" && isAdmin && (
          <>
            <div style={{ fontSize: 20, fontWeight: 700, marginBottom: 14 }}>加班審核</div>
            <div style={{ background: T.card, borderRadius: 16, padding: "0 16px", boxShadow: T.shadow2 }}>
              {records.filter(r => r.status === "pending").length === 0 && (
                <div style={{ padding: "24px 0", textAlign: "center", color: T.label3 }}>無待審核申請</div>
              )}
              {records.filter(r => r.status === "pending").map((r, i, arr) => (
                <div key={r.id} style={{ padding: "14px 0", borderBottom: i < arr.length - 1 ? `1px solid ${T.separator}` : "none" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 8 }}>
                    <div>
                      <span style={{ fontWeight: 700 }}>{r.name}</span>
                      <span style={{ fontSize: 12, color: T.label3, marginLeft: 8 }}>{r.date} · {r.start_time}–{r.end_time}</span>
                    </div>
                    <span style={{ fontFamily: "JetBrains Mono", fontWeight: 800, color: T.amber }}>{r.hours}h</span>
                  </div>
                  <div style={{ fontSize: 13, color: T.label2, marginBottom: 10 }}>{r.reason || "無備註"} · <span style={{ color: typeColor[r.comp_type] }}>{typeLabel[r.comp_type]}</span></div>
                  <div style={{ display: "flex", gap: 8 }}>
                    <button onClick={() => approve(r.id)} style={{ flex: 1, padding: "10px 0", borderRadius: 12, background: T.greenBg, color: T.green, fontSize: 13, fontWeight: 700, border: "none", cursor: "pointer" }}>✓ 核准</button>
                    <button onClick={() => reject(r.id)}  style={{ flex: 1, padding: "10px 0", borderRadius: 12, background: T.redBg,   color: T.red,   fontSize: 13, fontWeight: 700, border: "none", cursor: "pointer" }}>✗ 拒絕</button>
                  </div>
                </div>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}

// ═════════════════════════════════════════════════════════════
// LeaveBalanceModule — 假別餘額管理
// ═════════════════════════════════════════════════════════════
export function LeaveBalanceModule({ isAdmin, currentEmpId }) {
  const [selected, setSelected] = useState(null);
  const data = isAdmin ? MOCK_BALANCE : MOCK_BALANCE.filter(e => e.employee_id === currentEmpId);

  const BalanceBar = ({ label, total, used, color }) => {
    const pct = total > 0 ? Math.round((used / total) * 100) : 0;
    const remaining = total - used;
    return (
      <div style={{ marginBottom: 12 }}>
        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
          <span style={{ fontSize: 12, fontWeight: 600, color: T.label2 }}>{label}</span>
          <span style={{ fontSize: 12, fontFamily: "JetBrains Mono", color: remaining <= 3 ? T.red : color, fontWeight: 700 }}>
            剩 {remaining} 天 / {total} 天
          </span>
        </div>
        <div style={{ height: 6, background: T.separator, borderRadius: 3, overflow: "hidden" }}>
          <div style={{ height: "100%", width: `${pct}%`, background: pct > 80 ? T.red : pct > 60 ? T.amber : color, borderRadius: 3, transition: `width .5s cubic-bezier(0.4,0,0.2,1)` }} />
        </div>
      </div>
    );
  };

  return (
    <div style={{ flex: 1, overflow: "auto", padding: "16px 16px 80px" }}>
      <div style={{ fontSize: 20, fontWeight: 700, marginBottom: 14 }}>假別餘額 · {new Date().getFullYear()}</div>

      {/* 警告：年假快用完 */}
      {data.some(e => (e.annual_total - e.annual_used) <= 3) && (
        <div style={{ padding: "12px 14px", background: T.amberBg, borderRadius: 14, marginBottom: 14, display: "flex", gap: 10, alignItems: "center" }}>
          <span style={{ fontSize: 20 }}>⚠️</span>
          <div>
            <div style={{ fontWeight: 700, fontSize: 13, color: T.amber }}>年假即將用完</div>
            <div style={{ fontSize: 12, color: T.label2 }}>部分員工年假剩餘 ≤3 天，請注意排班</div>
          </div>
        </div>
      )}

      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        {data.map((e, i) => (
          <div key={e.employee_id} onClick={() => setSelected(selected === e.employee_id ? null : e.employee_id)} style={{ background: T.card, borderRadius: 16, padding: 16, boxShadow: T.shadow2, cursor: "pointer", transition: `transform .15s ${SP}`, animation: `fadeUp .3s both`, animationDelay: `${i * .06}s` }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: selected === e.employee_id ? 12 : 0 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                <div style={{ width: 36, height: 36, borderRadius: "50%", background: `linear-gradient(135deg,${T.teal},${T.teal2})`, display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontWeight: 700 }}>{e.name[0]}</div>
                <div>
                  <div style={{ fontWeight: 700 }}>{e.name}</div>
                  <div style={{ fontSize: 11, color: T.label3 }}>{e.dept} · 年資 {e.years} 年</div>
                </div>
              </div>
              <div style={{ textAlign: "right" }}>
                <div style={{ fontSize: 18, fontWeight: 800, color: (e.annual_total - e.annual_used) <= 3 ? T.red : T.green, fontFamily: "JetBrains Mono" }}>{e.annual_total - e.annual_used}</div>
                <div style={{ fontSize: 10, color: T.label3 }}>年假剩餘</div>
              </div>
            </div>
            {selected === e.employee_id && (
              <div style={{ animation: "fadeUp .2s both" }}>
                <BalanceBar label="年假" total={e.annual_total} used={e.annual_used} color={T.green} />
                <BalanceBar label="病假" total={e.sick_total} used={e.sick_used} color={T.blue} />
                <BalanceBar label="補休" total={e.comp_total || 0} used={e.comp_used} color={T.amber} />
                <div style={{ fontSize: 11, color: T.label3, marginTop: 8, textAlign: "right" }}>
                  年假依年資自動計算 · 每年 1/1 重置
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

// ── Worker 端：請假核准時自動扣抵餘額 ──────────────────────────
/*
// 在 PUT /api/leaves/:id 核准後加上：

if (status === "approved") {
  const leave = await env.DB.prepare("SELECT * FROM leaves WHERE id=?").bind(id).first();
  const year  = new Date(leave.start_date).getFullYear();

  // 扣抵對應假別餘額
  const result = await env.DB.prepare(`
    UPDATE leave_balance
    SET used = MIN(total, used + ?)
    WHERE employee_id=? AND year=? AND leave_type=?
  `).bind(leave.days, leave.employee_id, year, leave.type).run();

  if (result.changes === 0) {
    // 如果沒有餘額記錄，建立預設值
    const emp = await env.DB.prepare("SELECT * FROM employees WHERE id=?").bind(leave.employee_id).first();
    const yearsOfService = /* 計算年資 */ 1;
    const defaultDays = leave.type === "年假" ? calcAnnualLeave(yearsOfService) : leave.type === "病假" ? 30 : 0;
    await env.DB.prepare(`
      INSERT OR IGNORE INTO leave_balance (employee_id, year, leave_type, total, used)
      VALUES (?, ?, ?, ?, ?)
    `).bind(leave.employee_id, year, leave.type, defaultDays, leave.days).run();
  }

  // 發 LINE 通知
  if (env.LINE_NOTIFY_TOKEN) {
    const emp = await env.DB.prepare("SELECT name FROM employees WHERE id=?").bind(leave.employee_id).first();
    const balance = await env.DB.prepare(
      "SELECT (total-used) as remaining FROM leave_balance WHERE employee_id=? AND year=? AND leave_type=?"
    ).bind(leave.employee_id, year, leave.type).first();
    await sendLine(env.LINE_NOTIFY_TOKEN,
      `✅ 請假核准\n${emp.name} 的 ${leave.type}（${leave.days}天）已核准\n剩餘 ${balance?.remaining ?? "?"} 天`
    );
  }
}
*/
