// ══════════════════════════════════════════════════════════════
// 愛心教養院 · 假單附件模組 v1.0
// 支援：相機拍照 / 相簿上傳 / 壓縮預覽 / R2 儲存
// 病假必須附診斷書，其他假別選填
// ══════════════════════════════════════════════════════════════

import { useState, useRef, useCallback } from "react";

const T = {
  teal: "#0D9488", teal2: "#0F766E",
  tealBg: "rgba(13,148,136,0.08)",
  red: "#FF3B30", redBg: "rgba(255,59,48,0.08)",
  amber: "#FF9500", amberBg: "rgba(255,149,0,0.08)",
  green: "#34C759",
  bg: "#F2F2F7", label: "#000", label2: "rgba(60,60,67,0.6)", label3: "rgba(60,60,67,0.3)",
  separator: "rgba(60,60,67,0.12)",
  shadow2: "0 4px 12px rgba(0,0,0,0.08)",
};
const SP = "cubic-bezier(0.34,1.56,0.64,1)";

// 哪些假別需要附件
const REQUIRED_ATTACHMENT = ["病假", "婚假", "喪假"];
const OPTIONAL_ATTACHMENT = ["年假", "事假", "補休"];

// ── 圖片壓縮 ─────────────────────────────────────────────────
function compressImage(file, maxWidth = 1200, quality = 0.75) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = e => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement("canvas");
        const ratio = Math.min(maxWidth / img.width, maxWidth / img.height, 1);
        canvas.width  = img.width  * ratio;
        canvas.height = img.height * ratio;
        const ctx = canvas.getContext("2d");
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        canvas.toBlob(blob => {
          if (!blob) { reject(new Error("壓縮失敗")); return; }
          const compressed = new File([blob], file.name, { type: "image/jpeg" });
          resolve({
            file: compressed,
            url: URL.createObjectURL(compressed),
            originalSize: file.size,
            compressedSize: compressed.size,
          });
        }, "image/jpeg", quality);
      };
      img.onerror = reject;
      img.src = e.target.result;
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

// ── 上傳到 R2 (via Worker) ────────────────────────────────────
async function uploadToR2(file, leaveId, apiBase) {
  const formData = new FormData();
  formData.append("file", file);
  formData.append("leave_id", leaveId);
  formData.append("type", "leave_attachment");

  const res = await fetch(`${apiBase}/api/upload`, {
    method: "POST",
    body: formData,
  });
  if (!res.ok) throw new Error(await res.text());
  return await res.json(); // { url, key }
}

// ═════════════════════════════════════════════════════════════
// Hook: useLeaveAttachment
// ═════════════════════════════════════════════════════════════
export function useLeaveAttachment(leaveType, apiBase, demoMode) {
  const [files, setFiles]     = useState([]);       // { id, file, url, status, uploadUrl }
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef(null);

  const isRequired = REQUIRED_ATTACHMENT.includes(leaveType);
  const maxFiles = leaveType === "婚假" ? 1 : leaveType === "喪假" ? 2 : 3;

  const addFile = useCallback(async (rawFile) => {
    if (files.length >= maxFiles) return;
    if (!rawFile.type.startsWith("image/") && rawFile.type !== "application/pdf") {
      alert("只支援圖片或 PDF 格式");
      return;
    }

    const id = `file_${Date.now()}`;
    // 加入待處理
    setFiles(prev => [...prev, { id, file: rawFile, url: URL.createObjectURL(rawFile), status: "compressing" }]);

    try {
      let result;
      if (rawFile.type.startsWith("image/")) {
        result = await compressImage(rawFile);
      } else {
        result = { file: rawFile, url: URL.createObjectURL(rawFile), originalSize: rawFile.size, compressedSize: rawFile.size };
      }

      setFiles(prev => prev.map(f => f.id === id ? {
        ...f, file: result.file, url: result.url, status: "ready",
        originalSize: result.originalSize, compressedSize: result.compressedSize,
      } : f));
    } catch (e) {
      setFiles(prev => prev.map(f => f.id === id ? { ...f, status: "error", error: e.message } : f));
    }
  }, [files, maxFiles]);

  const removeFile = useCallback((id) => {
    setFiles(prev => {
      const f = prev.find(f => f.id === id);
      if (f?.url) URL.revokeObjectURL(f.url);
      return prev.filter(f => f.id !== id);
    });
  }, []);

  const uploadAll = useCallback(async (leaveId) => {
    if (demoMode) {
      // Demo 模式：模擬上傳
      setFiles(prev => prev.map(f => ({ ...f, status: "uploaded", uploadUrl: `https://demo.r2.dev/${leaveId}/${f.file.name}` })));
      return files.map(f => ({ url: `https://demo.r2.dev/${leaveId}/${f.file.name}` }));
    }
    setUploading(true);
    const results = [];
    for (const f of files) {
      if (f.status !== "ready") continue;
      setFiles(prev => prev.map(x => x.id === f.id ? { ...x, status: "uploading" } : x));
      try {
        const res = await uploadToR2(f.file, leaveId, apiBase);
        setFiles(prev => prev.map(x => x.id === f.id ? { ...x, status: "uploaded", uploadUrl: res.url } : x));
        results.push(res);
      } catch (e) {
        setFiles(prev => prev.map(x => x.id === f.id ? { ...x, status: "error", error: e.message } : x));
      }
    }
    setUploading(false);
    return results;
  }, [files, apiBase, demoMode]);

  const isValid = isRequired ? files.filter(f => f.status === "ready" || f.status === "uploaded").length > 0 : true;

  return {
    files, uploading, isRequired, isValid,
    maxFiles, fileInputRef,
    addFile, removeFile, uploadAll,
    openPicker: () => fileInputRef.current?.click(),
  };
}

// ═════════════════════════════════════════════════════════════
// LeaveAttachmentUI — 附件上傳元件
// ═════════════════════════════════════════════════════════════
export function LeaveAttachmentUI({ leaveType, apiBase, demoMode, onChange }) {
  const attach = useLeaveAttachment(leaveType, apiBase, demoMode);

  // 通知父元件
  const handleFileInput = async (e) => {
    const f = e.target.files?.[0];
    if (f) { await attach.addFile(f); onChange?.(attach); }
    e.target.value = "";
  };

  const sizeStr = bytes => bytes > 1024 * 1024
    ? `${(bytes / 1024 / 1024).toFixed(1)} MB`
    : `${Math.round(bytes / 1024)} KB`;

  const statusLabel = { compressing: "壓縮中...", ready: "就緒", uploading: "上傳中...", uploaded: "已上傳", error: "失敗" };
  const statusColor = { compressing: T.amber, ready: T.teal, uploading: T.amber, uploaded: T.green, error: T.red };

  return (
    <div>
      <input ref={attach.fileInputRef} type="file" accept="image/*,application/pdf" capture="environment" style={{ display: "none" }} onChange={handleFileInput} />

      {/* 標題 */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
        <div>
          <span style={{ fontSize: 13, fontWeight: 700, color: T.label2 }}>
            附件 {attach.isRequired ? <span style={{ color: T.red }}>*必填</span> : "(選填)"}
          </span>
          <div style={{ fontSize: 11, color: T.label3, marginTop: 2 }}>
            {leaveType === "病假" ? "請附醫院診斷書 / 掛號記錄" : leaveType === "婚假" ? "請附結婚證書" : leaveType === "喪假" ? "請附死亡證明或訃聞" : "支援圖片或 PDF，最多 3 張"}
          </div>
        </div>
        <span style={{ fontSize: 11, color: T.label3 }}>{attach.files.length}/{attach.maxFiles}</span>
      </div>

      {/* 已選圖片 */}
      {attach.files.length > 0 && (
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 10 }}>
          {attach.files.map(f => (
            <div key={f.id} style={{ position: "relative", width: 80, height: 80, borderRadius: 12, overflow: "hidden", background: T.bg, border: `2px solid ${statusColor[f.status] || T.separator}`, flexShrink: 0 }}>
              {f.file?.type?.startsWith("image/") ? (
                <img src={f.url} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
              ) : (
                <div style={{ width: "100%", height: "100%", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 2 }}>
                  <span style={{ fontSize: 28 }}>📄</span>
                  <span style={{ fontSize: 9, color: T.label3 }}>PDF</span>
                </div>
              )}
              {/* 狀態 overlay */}
              {f.status !== "ready" && (
                <div style={{ position: "absolute", inset: 0, background: "rgba(0,0,0,.4)", display: "flex", alignItems: "center", justifyContent: "center" }}>
                  <span style={{ fontSize: 10, color: "#fff", fontWeight: 700, background: statusColor[f.status], padding: "2px 6px", borderRadius: 6 }}>{statusLabel[f.status]}</span>
                </div>
              )}
              {/* 壓縮比 */}
              {f.status === "ready" && f.originalSize && f.compressedSize && f.originalSize !== f.compressedSize && (
                <div style={{ position: "absolute", bottom: 2, left: 0, right: 0, textAlign: "center" }}>
                  <span style={{ fontSize: 8, background: "rgba(0,0,0,.6)", color: "#fff", padding: "1px 4px", borderRadius: 4 }}>
                    {sizeStr(f.compressedSize)}
                  </span>
                </div>
              )}
              {/* 刪除按鈕 */}
              <button onClick={() => attach.removeFile(f.id)} style={{ position: "absolute", top: 3, right: 3, width: 18, height: 18, borderRadius: "50%", background: "rgba(0,0,0,.6)", color: "#fff", border: "none", fontSize: 10, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", lineHeight: 1 }}>
                ✕
              </button>
            </div>
          ))}
        </div>
      )}

      {/* 上傳按鈕 */}
      {attach.files.length < attach.maxFiles && (
        <button onClick={attach.openPicker} style={{ display: "flex", alignItems: "center", gap: 8, padding: "10px 16px", borderRadius: 12, background: attach.isRequired && attach.files.length === 0 ? T.amberBg : T.tealBg, border: `1.5px dashed ${attach.isRequired && attach.files.length === 0 ? T.amber : T.teal}`, color: attach.isRequired && attach.files.length === 0 ? T.amber : T.teal, fontSize: 13, fontWeight: 600, cursor: "pointer", width: "100%" }}>
          <span style={{ fontSize: 18 }}>📷</span>
          <div style={{ textAlign: "left" }}>
            <div>{attach.files.length === 0 ? "拍照或從相簿選取" : "繼續新增"}</div>
            {attach.isRequired && attach.files.length === 0 && <div style={{ fontSize: 11, opacity: 0.8 }}>此假別必須附上證明文件</div>}
          </div>
        </button>
      )}

      {/* 驗證訊息 */}
      {attach.isRequired && attach.files.length === 0 && (
        <div style={{ marginTop: 6, fontSize: 12, color: T.red }}>⚠️ {leaveType}需要附上相關文件才能送出申請</div>
      )}
    </div>
  );
}

// Worker 端處理 /api/upload 的程式碼：
/*
// 在 attendance-worker.js 加上：
// wrangler.toml: [[r2_buckets]] binding = "R2" bucket_name = "attendance-files"

if (path === "/api/upload" && method === "POST") {
  const formData = await request.formData();
  const file     = formData.get("file");
  const leaveId  = formData.get("leave_id");

  if (!file || !leaveId) return err("缺少必要欄位");

  const ext  = file.name.split(".").pop() || "jpg";
  const key  = `leaves/${leaveId}/${Date.now()}.${ext}`;
  const buf  = await file.arrayBuffer();

  await env.R2.put(key, buf, {
    httpMetadata: { contentType: file.type },
    customMetadata: { leave_id: leaveId, original_name: file.name },
  });

  // 記錄到 D1
  await env.DB.prepare(
    "INSERT INTO leave_attachments (leave_id, r2_key, filename, size, created_at) VALUES (?, ?, ?, ?, datetime('now'))"
  ).bind(leaveId, key, file.name, buf.byteLength).run();

  const url = `https://pub.r2.dev/${key}`; // 替換為你的 R2 公開網域
  return json({ ok: true, url, key });
}
*/
