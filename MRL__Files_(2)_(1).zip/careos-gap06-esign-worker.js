/**
 * CareOS E-Sign Worker v1.0
 * origin_signature: MrLiouWord
 *
 * GET    /api/documents          文件列表（?mine=1 待我簽）
 * POST   /api/documents          建立文件
 * GET    /api/documents/:id      單一文件+稽核
 * POST   /api/documents/:id/sign 送出簽名
 * PUT    /api/documents/:id/reject 拒絕
 * GET    /api/audit              全域稽核日誌
 * POST   /api/documents/:id/remind 發送提醒
 */
const CORS={'Access-Control-Allow-Origin':'*','Access-Control-Allow-Methods':'GET,POST,PUT,DELETE,OPTIONS','Access-Control-Allow-Headers':'Content-Type,Authorization,X-User-Id'};
const J=(d,s=200)=>new Response(JSON.stringify(d),{status:s,headers:{...CORS,'Content-Type':'application/json'}});
const E=(m,s=400)=>J({ok:false,error:m},s);
const now=()=>new Date().toISOString();
const uid=(p='')=>p+Date.now().toString(36)+Math.random().toString(36).slice(2,6);
async function sha256(str){const b=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(str));return Array.from(new Uint8Array(b)).map(x=>x.toString(16).padStart(2,'0')).join('');}

async function initDB(db){
  await db.exec(`
    CREATE TABLE IF NOT EXISTS esign_documents (
      id TEXT PRIMARY KEY, title TEXT NOT NULL, type TEXT NOT NULL DEFAULT 'custom',
      resident_id TEXT, content TEXT NOT NULL DEFAULT '', status TEXT NOT NULL DEFAULT 'draft',
      priority TEXT NOT NULL DEFAULT 'normal', created_by TEXT NOT NULL,
      expire_at TEXT NOT NULL, created_at TEXT NOT NULL, updated_at TEXT NOT NULL, hash TEXT
    );
    CREATE TABLE IF NOT EXISTS esign_signers (
      id TEXT PRIMARY KEY, doc_id TEXT NOT NULL, user_id TEXT NOT NULL,
      role_label TEXT NOT NULL DEFAULT '', order_num INTEGER NOT NULL DEFAULT 0,
      status TEXT NOT NULL DEFAULT 'pending', sig_data TEXT, signed_at TEXT,
      rejected_at TEXT, reject_note TEXT, ip_addr TEXT,
      FOREIGN KEY(doc_id) REFERENCES esign_documents(id)
    );
    CREATE TABLE IF NOT EXISTS esign_audit (
      id TEXT PRIMARY KEY, doc_id TEXT NOT NULL, user_id TEXT NOT NULL,
      action TEXT NOT NULL, note TEXT, ip_addr TEXT, ts TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_ds ON esign_documents(status,created_by);
    CREATE INDEX IF NOT EXISTS idx_sg ON esign_signers(doc_id,order_num);
    CREATE INDEX IF NOT EXISTS idx_au ON esign_audit(doc_id,ts DESC);
  `);
}

export default {
  async fetch(req,env){
    if(req.method==='OPTIONS')return new Response(null,{status:204,headers:CORS});
    const db=env.DB; await initDB(db);
    const url=new URL(req.url),path=url.pathname,method=req.method;
    const userId=req.headers.get('X-User-Id')||'anonymous';
    const ip=req.headers.get('CF-Connecting-IP')||null;
    try{
      if(method==='GET'&&path==='/api/documents'){
        const mine=url.searchParams.get('mine'),status=url.searchParams.get('status');
        let q='SELECT d.* FROM esign_documents d',p=[];
        if(mine==='1'){q+=' JOIN esign_signers s ON s.doc_id=d.id AND s.user_id=? AND s.status=?';p.push(userId,'current');}
        if(status){q+=p.length?' WHERE d.status=?':' WHERE d.status=?';p.push(status);}
        q+=' ORDER BY d.updated_at DESC LIMIT 100';
        const rows=await db.prepare(q).bind(...p).all();
        const result=[];
        for(const doc of rows.results){const sigs=await db.prepare('SELECT * FROM esign_signers WHERE doc_id=? ORDER BY order_num').bind(doc.id).all();result.push({...doc,signers:sigs.results});}
        return J({ok:true,documents:result});
      }

      if(method==='POST'&&path==='/api/documents'){
        const {title,type='custom',content='',resident_id=null,priority='normal',expire_at,signers=[]}=await req.json();
        if(!title?.trim())return E('title必填');if(!expire_at)return E('expire_at必填');if(!signers.length)return E('至少一位簽署人');
        const docId=uid('doc'),ts=now(),hash=await sha256(content);
        await db.prepare('INSERT INTO esign_documents (id,title,type,resident_id,content,status,priority,created_by,expire_at,created_at,updated_at,hash) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)').bind(docId,title,type,resident_id,content,'pending',priority,userId,expire_at,ts,ts,hash).run();
        for(let i=0;i<signers.length;i++){const s=signers[i];await db.prepare('INSERT INTO esign_signers (id,doc_id,user_id,role_label,order_num,status) VALUES (?,?,?,?,?,?)').bind(uid('sig'),docId,s.user_id,s.role_label||'',i,i===0?'current':'pending').run();}
        await db.prepare('INSERT INTO esign_audit (id,doc_id,user_id,action,ts) VALUES (?,?,?,?,?)').bind(uid('aud'),docId,userId,'created',ts).run();
        return J({ok:true,document_id:docId},201);
      }

      const mD=path.match(/^\/api\/documents\/([^/]+)$/);
      if(mD&&method==='GET'){
        const docId=mD[1];
        const doc=await db.prepare('SELECT * FROM esign_documents WHERE id=?').bind(docId).first();
        if(!doc)return E('找不到文件',404);
        const sigs=await db.prepare('SELECT * FROM esign_signers WHERE doc_id=? ORDER BY order_num').bind(docId).all();
        const auds=await db.prepare('SELECT * FROM esign_audit WHERE doc_id=? ORDER BY ts DESC LIMIT 50').bind(docId).all();
        await db.prepare('INSERT INTO esign_audit (id,doc_id,user_id,action,ip_addr,ts) VALUES (?,?,?,?,?,?)').bind(uid('aud'),docId,userId,'viewed',ip,now()).run();
        return J({ok:true,document:{...doc,signers:sigs.results},audit:auds.results});
      }

      const mSign=path.match(/^\/api\/documents\/([^/]+)\/sign$/);
      if(mSign&&method==='POST'){
        const docId=mSign[1];
        const {sig_data,confirm_code}=await req.json();
        if(!confirm_code?.trim())return E('confirm_code必填');
        const doc=await db.prepare('SELECT * FROM esign_documents WHERE id=?').bind(docId).first();
        if(!doc)return E('找不到文件',404);
        if(doc.status!=='pending')return E('文件已不在待簽署狀態');
        const cur=await db.prepare('SELECT * FROM esign_signers WHERE doc_id=? AND user_id=? AND status=?').bind(docId,userId,'current').first();
        if(!cur)return E('你目前不是待簽署人',403);
        const ts=now();
        await db.prepare('UPDATE esign_signers SET status=?,sig_data=?,signed_at=?,ip_addr=? WHERE id=?').bind('done',sig_data||null,ts,ip,cur.id).run();
        const next=await db.prepare('SELECT * FROM esign_signers WHERE doc_id=? AND status=? ORDER BY order_num LIMIT 1').bind(docId,'pending').first();
        if(next)await db.prepare('UPDATE esign_signers SET status=? WHERE id=?').bind('current',next.id).run();
        else await db.prepare('UPDATE esign_documents SET status=?,updated_at=? WHERE id=?').bind('signed',ts,docId).run();
        await db.prepare('UPDATE esign_documents SET updated_at=? WHERE id=?').bind(ts,docId).run();
        await db.prepare('INSERT INTO esign_audit (id,doc_id,user_id,action,ip_addr,ts) VALUES (?,?,?,?,?,?)').bind(uid('aud'),docId,userId,'signed',ip,ts).run();
        return J({ok:true,all_signed:!next,signed_at:ts});
      }

      const mRej=path.match(/^\/api\/documents\/([^/]+)\/reject$/);
      if(mRej&&method==='PUT'){
        const docId=mRej[1];
        const {note=''}=await req.json().catch(()=>({}));
        const ts=now();
        await db.prepare('UPDATE esign_signers SET status=?,rejected_at=?,reject_note=? WHERE doc_id=? AND user_id=? AND status=?').bind('rejected',ts,note,docId,userId,'current').run();
        await db.prepare('UPDATE esign_documents SET status=?,updated_at=? WHERE id=?').bind('rejected',ts,docId).run();
        await db.prepare('INSERT INTO esign_audit (id,doc_id,user_id,action,note,ip_addr,ts) VALUES (?,?,?,?,?,?,?)').bind(uid('aud'),docId,userId,'rejected',note,ip,ts).run();
        return J({ok:true});
      }

      if(method==='GET'&&path==='/api/audit'){
        const rows=await db.prepare('SELECT * FROM esign_audit ORDER BY ts DESC LIMIT 200').all();
        return J({ok:true,audit:rows.results});
      }

      const mRem=path.match(/^\/api\/documents\/([^/]+)\/remind$/);
      if(mRem&&method==='POST'){
        const ts=now();
        await db.prepare('INSERT INTO esign_audit (id,doc_id,user_id,action,ts) VALUES (?,?,?,?,?)').bind(uid('aud'),mRem[1],userId,'reminded',ts).run();
        return J({ok:true,reminded_at:ts});
      }

      return E('找不到路由',404);
    }catch(e){return E('伺服器錯誤: '+e.message,500);}
  }
};
