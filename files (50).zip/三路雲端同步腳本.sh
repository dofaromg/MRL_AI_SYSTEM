#!/bin/bash
# ============================================
# MrLiouWord 完整工程包三路雲端同步腳本
# 日期：2026-03-11
# ============================================

echo "📦 MrLiouWord 工程包雲端同步"
echo "================================"

# 解壓工程包
if [ -f "MrLiouWord_完整工程包_2026-03-11.tar.gz" ]; then
  echo "📂 解壓工程包..."
  tar xzf MrLiouWord_完整工程包_2026-03-11.tar.gz
else
  echo "❌ 找不到工程包，請先下載 MrLiouWord_完整工程包_2026-03-11.tar.gz"
  exit 1
fi

# ==========================================
# 第一路：Cloudflare R2
# ==========================================
echo ""
echo "☁️  第一路：上傳到 Cloudflare R2..."
echo "  Bucket: mrliouword-engineering"

BUCKET="mrliouword-engineering"
COUNT=0
find mrliouword-engineering-pack/ -type f | while read f; do
  wrangler r2 object put "$BUCKET/$f" --file "$f" 2>/dev/null
  COUNT=$((COUNT+1))
  echo "  ✅ $f"
done
echo "  完成！已上傳到 r2://mrliouword-engineering/"

# ==========================================
# 第二路：Google Drive
# ==========================================
echo ""
echo "📁 第二路：Google Drive"
echo "  請手動上傳以下檔案到 Google Drive 的 flowagent_memory_coherence_v1 資料夾："
echo "  https://drive.google.com/drive/folders/1OPgcgB80v2a7y9cXKXVgIZy8U_mN-wTW"
echo ""
echo "  上傳檔案：MrLiouWord_完整工程包_2026-03-11.tar.gz"
echo ""

# ==========================================
# 第三路：Notion（已同步）
# ==========================================
echo "📝 第三路：Notion 已同步完成"
echo "  喚醒文件: https://www.notion.so/31f8eeeec5b58187b323da8073938a0b"
echo "  Workers索引: https://www.notion.so/31f8eeeec5b58127be7cf68b3edcc699"
echo "  工程模組索引: https://www.notion.so/31f8eeeec5b5813b938cc24636bd0a2c"
echo "  雲端同步記錄: https://www.notion.so/31f8eeeec5b581d09409c99cd68f2bf8"
echo ""
echo "🎉 三路同步完成！"
