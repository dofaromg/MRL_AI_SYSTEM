/**
 * CareOS AI Voice Worker v1.0
 * origin_signature: MrLiouWord
 *
 * Endpoints:
 *  POST   /api/voice/transcribe        上傳音頻 → 轉文字（STT）
 *  POST   /api/voice/analyze           分析轉錄文字（AI摘要/任務提取/醫療術語）
 *  POST   /api/voice/tts               文字 → 語音（TTS，回傳 Base64 MP3）
 *  GET    /api/recordings              取得錄音記錄列表
 *  POST   /api/recordings              儲存錄音記錄
 *  GET    /api/recordings/:id          取得單筆記錄
 *  PUT    /api/recordings/:id          更新記錄（標題/文字/任務）
 *  DELETE /api/recordings/:id          刪除記錄
 *  POST   /api/recordings/:id/tasks/:i 更新任務狀態
 *  POST   /api/ambient/alert           環境監聽異常通報
 */

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type,Authorization,X-User-Id',
};
const j  = (d,s=200)=>new Response(JSON.stringify(d),{status:s,headers:{...CORS,'Content-Type':'application/json'}});
const er = (m,s=400)=>j({ok:false,error:m},s);
const ts = ()=>new Date().toISOString();
const uid= (p='')=>p+Date.now().toString(36)+Math.random().toString(36).slice(2,6);

async function initDB(db){
  await db.exec(`
    CREATE TABLE IF NOT EXISTS voice_recordings (
      id           TEXT PRIMARY KEY,
      user_id      TEXT NOT NULL,
      title        TEXT NOT NULL,
      transcript   TEXT NOT NULL,
      duration_sec INTEGER DEFAULT 0,
      language     TEXT DEFAULT 'zh-TW',
      type         TEXT DEFAULT 'note',
      confidence   INTEGER DEFAULT 90,
      ai_summary   TEXT DEFAULT NULL,
      med_terms    TEXT DEFAULT NULL,   -- JSON array
      tasks_json   TEXT DEFAULT NULL,  -- JSON array
      speakers_json TEXT DEFAULT NULL, -- JSON array
      audio_key    TEXT DEFAULT NULL,  -- R2 object key
      created_at   TEXT NOT NULL,
      updated_at   TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS ambient_alerts (
      id          TEXT PRIMARY KEY,
      room        TEXT,
      alert_type  TEXT NOT NULL,   -- fall | call | noise | smoke
      confidence  REAL DEFAULT 0,
      resolved    INTEGER DEFAULT 0,
      resolved_by TEXT DEFAULT NULL,
      created_at  TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_rec_user ON voice_recordings(user_id,created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_amb_room ON ambient_alerts(room,created_at DESC);
  `);
}

// ── 模擬 AI 分析（實際串接 Workers AI whisper / llm）─────
function mockAnalyze(text, type){
  const medTermMap = {
    handover: ['血壓','降血糖藥物','心跳'],
    nursing:  ['褥瘡','被動關節運動','定向感','疼痛評估'],
    vital:    ['體溫','血壓','血氧','心跳','呼吸'],
    incident: ['X光','意識清醒','急救'],
    rehab:    ['肌力','步態','關節活動度'],
    family:   [],
  };
  const terms = (medTermMap[type]||[]).filter(t=>text.includes(t));
  const sumMap = {
    handover:'血壓異常需追蹤、交班事項已交辦',
    nursing: '護理評估完成，褥瘡前期需加強翻身',
    vital:   '生命徵象記錄完成，數值穩定',
    incident:'異常事件已通報，持續追蹤中',
    rehab:   '復健進度良好，繼續目標訓練',
    family:  '家屬說明完成，知情同意確認',
  };

  // 簡單任務提取：搜尋「請」「注意」「確認」「安排」
  const taskKeywords=[{kw:'請接班',t:'接班注意事項確認',pri:'high'},{kw:'注意',t:'重點關注事項',pri:'mid'},{kw:'確認',t:'確認相關事項',pri:'mid'},{kw:'安排',t:'安排後續處置',pri:'mid'}];
  const tasks=[];
  taskKeywords.forEach(({kw,t,pri})=>{if(text.includes(kw))tasks.push({text:t,assignee:'當班護理師',pri,done:false});});

  return {
    ai_summary: sumMap[type]||'記錄已完成',
    med_terms:  terms,
    tasks,
    confidence: 88+Math.floor(Math.random()*10),
  };
}

export default {
  async fetch(req, env){
    if(req.method==='OPTIONS') return new Response(null,{status:204,headers:CORS});
    const db   = env.DB;
    await initDB(db);
    const url  = new URL(req.url);
    const path = url.pathname;
    const meth = req.method;
    const user = req.headers.get('X-User-Id')||'anon';

    try {
      // POST /api/voice/transcribe — 模擬 STT（實際用 Whisper）
      if(meth==='POST'&&path==='/api/voice/transcribe'){
        const form = await req.formData().catch(()=>null);
        // 實際: audio blob → Whisper API → transcript
        // 此處模擬回傳
        const lang = form?.get('language')||'zh-TW';
        return j({ok:true, transcript:'（語音辨識結果將顯示於此）', language:lang, confidence:94, duration_sec:30});
      }

      // POST /api/voice/analyze
      if(meth==='POST'&&path==='/api/voice/analyze'){
        const b=await req.json();
        const {text='', type='note'} = b;
        if(!text.trim()) return er('text 必填');
        const result = mockAnalyze(text, type);
        return j({ok:true, ...result});
      }

      // POST /api/voice/tts
      if(meth==='POST'&&path==='/api/voice/tts'){
        const b=await req.json();
        const {text='', voice='zh-TW-HsiaoChenNeural'} = b;
        if(!text.trim()) return er('text 必填');
        // 實際: Azure/ElevenLabs TTS → MP3 → Base64
        return j({ok:true, audio_base64:'(simulated-mp3-data)', voice, duration_sec:Math.floor(text.length/12)});
      }

      // GET /api/recordings
      if(meth==='GET'&&path==='/api/recordings'){
        const type = url.searchParams.get('type');
        const q = type
          ? 'SELECT * FROM voice_recordings WHERE user_id=? AND type=? ORDER BY created_at DESC'
          : 'SELECT * FROM voice_recordings WHERE user_id=? ORDER BY created_at DESC';
        const rows = type
          ? await db.prepare(q).bind(user,type).all()
          : await db.prepare(q).bind(user).all();
        return j({ok:true, recordings:rows.results});
      }

      // POST /api/recordings
      if(meth==='POST'&&path==='/api/recordings'){
        const b=await req.json();
        const {title,transcript,duration_sec=0,language='zh-TW',type='note',confidence=90,ai_summary,med_terms=[],tasks=[],speakers=[]} = b;
        if(!title||!transcript) return er('title 和 transcript 必填');
        const now=ts();
        const rid=uid('rec');
        await db.prepare(`INSERT INTO voice_recordings(id,user_id,title,transcript,duration_sec,language,type,confidence,ai_summary,med_terms,tasks_json,speakers_json,created_at,updated_at)
          VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)`)
          .bind(rid,user,title,transcript,duration_sec,language,type,confidence,
            ai_summary||null,JSON.stringify(med_terms),JSON.stringify(tasks),JSON.stringify(speakers),now,now).run();
        return j({ok:true,recording_id:rid},201);
      }

      // GET /api/recordings/:id
      const mRec=path.match(/^\/api\/recordings\/([^/]+)$/);
      if(mRec&&meth==='GET'){
        const r=await db.prepare('SELECT * FROM voice_recordings WHERE id=? AND user_id=?').bind(mRec[1],user).first();
        if(!r) return er('找不到記錄',404);
        return j({ok:true,recording:{...r,med_terms:JSON.parse(r.med_terms||'[]'),tasks_json:JSON.parse(r.tasks_json||'[]'),speakers_json:JSON.parse(r.speakers_json||'[]')}});
      }

      // PUT /api/recordings/:id
      if(mRec&&meth==='PUT'){
        const b=await req.json();
        const fields=[]; const vals=[];
        if(b.title!==undefined){fields.push('title=?');vals.push(b.title);}
        if(b.transcript!==undefined){fields.push('transcript=?');vals.push(b.transcript);}
        if(b.tasks!==undefined){fields.push('tasks_json=?');vals.push(JSON.stringify(b.tasks));}
        if(!fields.length) return er('無更新欄位');
        fields.push('updated_at=?'); vals.push(ts());
        vals.push(mRec[1],user);
        await db.prepare(`UPDATE voice_recordings SET ${fields.join(',')} WHERE id=? AND user_id=?`).bind(...vals).run();
        return j({ok:true});
      }

      // DELETE /api/recordings/:id
      if(mRec&&meth==='DELETE'){
        await db.prepare('DELETE FROM voice_recordings WHERE id=? AND user_id=?').bind(mRec[1],user).run();
        return j({ok:true});
      }

      // POST /api/ambient/alert
      if(meth==='POST'&&path==='/api/ambient/alert'){
        const b=await req.json();
        const {room,alert_type,confidence=0.8} = b;
        if(!alert_type) return er('alert_type 必填');
        const aid=uid('amb');
        await db.prepare('INSERT INTO ambient_alerts(id,room,alert_type,confidence,created_at) VALUES(?,?,?,?,?)')
          .bind(aid,room||'未知',alert_type,confidence,ts()).run();
        return j({ok:true,alert_id:aid},201);
      }

      return er('找不到路由',404);
    } catch(e){
      return er('伺服器錯誤:'+e.message,500);
    }
  }
};
