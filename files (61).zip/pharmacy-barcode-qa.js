/**
 * ============================================================
 *  聖愛教養院 · 第5波三合一模組 v1.0
 *  N2 藥局整合 / N3 條碼給藥 / X1 AI QA Assistant
 *  origin_signature: MrLiouWord
 * ============================================================
 */

// ========== N2：藥局整合介面 ==========
// 業界對標：ECP 800+藥局連線 / PointClickCare / eVero

const PHARMACY_SYNC_STATUS = {
  synced: '已同步', pending: '待同步', error: '同步失敗', manual: '手動輸入',
};

const ORDER_STATUS = {
  pending: '待處理', sent: '已送藥局', confirmed: '藥局確認',
  dispensed: '已調配', delivered: '已送達', cancelled: '已取消',
};

function createPrescriptionOrder(db, data) {
  const id = `rx_${Date.now()}`;
  db.prepare(`
    INSERT INTO pharmacy_orders
    (id, resident_id, drug_name, drug_code, dose, route, frequency,
     start_date, end_date, prescriber, prescriber_license,
     pharmacy_id, order_status, sync_status, notes, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', 'pending', ?, datetime('now'))
  `).bind(id, data.resident_id, data.drug_name, data.drug_code || null,
    data.dose, data.route || 'oral', data.frequency,
    data.start_date, data.end_date || null,
    data.prescriber, data.prescriber_license || null,
    data.pharmacy_id || 'default', data.notes || null).run();

  return { id, status: 'pending' };
}

function updateOrderStatus(db, orderId, newStatus, updatedBy) {
  if (!ORDER_STATUS[newStatus]) throw new Error(`無效狀態: ${newStatus}`);
  db.prepare(`
    UPDATE pharmacy_orders SET order_status = ?, updated_by = ?, updated_at = datetime('now') WHERE id = ?
  `).bind(newStatus, updatedBy, orderId).run();
  return { id: orderId, status: newStatus };
}

function getRefillAlerts(db, daysAhead = 7) {
  const futureDate = new Date(Date.now() + daysAhead * 86400000).toISOString().slice(0, 10);
  return db.prepare(`
    SELECT po.*, c.name as resident_name FROM pharmacy_orders po
    JOIN clients c ON po.resident_id = c.id
    WHERE po.end_date <= ? AND po.end_date >= date('now')
    AND po.order_status NOT IN ('cancelled') ORDER BY po.end_date ASC
  `).bind(futureDate).all().results || [];
}

function getInventoryStatus(db) {
  return db.prepare(`
    SELECT drug_name, drug_code, SUM(quantity_on_hand) as total,
      SUM(CASE WHEN quantity_on_hand <= reorder_level THEN 1 ELSE 0 END) as low_stock_flag
    FROM drug_inventory WHERE status = 'active'
    GROUP BY drug_code ORDER BY low_stock_flag DESC, drug_name ASC
  `).all().results || [];
}

const PHARMACY_SCHEMA = `
CREATE TABLE IF NOT EXISTS pharmacy_orders (
  id TEXT PRIMARY KEY,
  resident_id TEXT NOT NULL,
  drug_name TEXT NOT NULL,
  drug_code TEXT,
  dose TEXT,
  route TEXT,
  frequency TEXT,
  start_date TEXT,
  end_date TEXT,
  prescriber TEXT,
  prescriber_license TEXT,
  pharmacy_id TEXT,
  order_status TEXT DEFAULT 'pending',
  sync_status TEXT DEFAULT 'pending',
  updated_by TEXT,
  notes TEXT,
  created_at TEXT DEFAULT (datetime('now')),
  updated_at TEXT,
  FOREIGN KEY (resident_id) REFERENCES clients(id)
);

CREATE TABLE IF NOT EXISTS drug_inventory (
  id TEXT PRIMARY KEY,
  drug_name TEXT NOT NULL,
  drug_code TEXT,
  lot_number TEXT,
  expiry_date TEXT,
  quantity_on_hand INTEGER DEFAULT 0,
  reorder_level INTEGER DEFAULT 10,
  storage_location TEXT,
  status TEXT DEFAULT 'active',
  last_count_date TEXT,
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_rx_resident ON pharmacy_orders(resident_id);
CREATE INDEX IF NOT EXISTS idx_rx_status ON pharmacy_orders(order_status);
CREATE INDEX IF NOT EXISTS idx_inv_drug ON drug_inventory(drug_code, status);
`;

// ========== N3：條碼掃描給藥 ==========
// 業界對標：iCareManager barcode / ECP barcode scanning

const FIVE_RIGHTS = ['right_patient', 'right_drug', 'right_dose', 'right_route', 'right_time'];

function validateBarcodeScan(db, scanData) {
  const checks = {
    right_patient: false, right_drug: false, right_dose: false,
    right_route: false, right_time: false,
  };
  const errors = [];

  // 1. Right Patient：掃描院生手環
  const resident = db.prepare('SELECT id, name FROM clients WHERE barcode_id = ?')
    .bind(scanData.resident_barcode).first();
  if (resident && resident.id === scanData.expected_resident_id) {
    checks.right_patient = true;
  } else {
    errors.push({ right: 'right_patient', message: resident ? `院生不符：掃到${resident.name}` : '手環無法辨識' });
  }

  // 2. Right Drug：掃描藥袋條碼
  const drug = db.prepare('SELECT * FROM pharmacy_orders WHERE drug_code = ? AND resident_id = ? AND order_status = \'dispensed\'')
    .bind(scanData.drug_barcode, scanData.expected_resident_id).first();
  if (drug) {
    checks.right_drug = true;
    // 3. Right Dose
    if (drug.dose === scanData.expected_dose) checks.right_dose = true;
    else errors.push({ right: 'right_dose', message: `劑量不符：藥袋${drug.dose} vs 醫囑${scanData.expected_dose}` });
    // 4. Right Route
    if (drug.route === scanData.expected_route) checks.right_route = true;
    else errors.push({ right: 'right_route', message: `途徑不符：${drug.route} vs ${scanData.expected_route}` });
  } else {
    errors.push({ right: 'right_drug', message: '藥袋條碼無法辨識或非本院生處方' });
  }

  // 5. Right Time：檢查給藥時間是否在允許範圍（±60分鐘）
  const now = new Date();
  const scheduledTime = new Date(scanData.scheduled_datetime);
  const diffMin = Math.abs((now - scheduledTime) / 60000);
  if (diffMin <= 60) checks.right_time = true;
  else errors.push({ right: 'right_time', message: `給藥時間偏差${Math.round(diffMin)}分鐘` });

  const allPassed = Object.values(checks).every(v => v);

  return {
    all_passed: allPassed,
    checks,
    errors,
    can_proceed: allPassed || (errors.length === 1 && errors[0].right === 'right_time' && diffMin <= 120),
    scan_time: now.toISOString(),
  };
}

// ========== X1：AI QA Assistant ==========
// 業界對標：Therap 2026 AI QA Assistant（業界最新）

const QA_RULES = [
  // 完整性規則
  { id: 'R01', category: 'completeness', label: '評估分數完整',
    check: (doc) => {
      const scores = ['eating_score','bathing_score','dressing_score','toileting_score','interaction_score','emotion_score','rules_score'];
      const missing = scores.filter(s => doc[s] === null || doc[s] === undefined);
      return { pass: missing.length === 0, missing, message: missing.length > 0 ? `缺少${missing.length}項評分：${missing.join(',')}` : null };
    }
  },
  { id: 'R02', category: 'completeness', label: '目標欄位填寫',
    check: (doc) => {
      const pass = doc.short_term_goals && doc.short_term_goals.length >= 10;
      return { pass, message: pass ? null : '短期目標未填寫或過短（<10字）' };
    }
  },
  { id: 'R03', category: 'completeness', label: '觀察紀錄填寫',
    check: (doc) => {
      const pass = doc.observations && doc.observations.length >= 20;
      return { pass, message: pass ? null : '觀察紀錄未填寫或過短（<20字）' };
    }
  },

  // 一致性規則
  { id: 'R04', category: 'consistency', label: '評分與上期差異合理',
    check: (doc, prev) => {
      if (!prev) return { pass: true, message: null };
      const scores = ['eating_score','bathing_score','dressing_score','toileting_score'];
      const bigChanges = scores.filter(s => doc[s] && prev[s] && Math.abs(doc[s] - prev[s]) >= 3);
      return { pass: bigChanges.length === 0, big_changes: bigChanges,
        message: bigChanges.length > 0 ? `${bigChanges.join(',')} 分數變化≥3分，請確認是否正確` : null };
    }
  },
  { id: 'R05', category: 'consistency', label: '評分與觀察紀錄一致',
    check: (doc) => {
      if (!doc.observations) return { pass: true, message: null };
      const lowScores = [];
      if (doc.eating_score <= 2) lowScores.push('飲食');
      if (doc.toileting_score <= 2) lowScores.push('如廁');
      const obsLower = (doc.observations || '').toLowerCase();
      const mentioned = lowScores.filter(s => obsLower.includes(s));
      const notMentioned = lowScores.filter(s => !obsLower.includes(s));
      return { pass: notMentioned.length === 0,
        message: notMentioned.length > 0 ? `${notMentioned.join(',')} 評分偏低但觀察紀錄未提及` : null };
    }
  },

  // 時效性規則
  { id: 'R06', category: 'timeliness', label: '評估期間正確',
    check: (doc) => {
      if (!doc.period) return { pass: false, message: '缺少評估期間' };
      const periodDate = new Date(doc.period + '-01');
      const now = new Date();
      const diffMonths = (now.getFullYear() - periodDate.getFullYear()) * 12 + now.getMonth() - periodDate.getMonth();
      return { pass: diffMonths <= 2, message: diffMonths > 2 ? `評估期間距今${diffMonths}個月，可能過舊` : null };
    }
  },

  // 安全性規則
  { id: 'R07', category: 'safety', label: '高危險行為標記',
    check: (doc) => {
      const keywords = ['自傷', '攻擊', '逃離', '吞食異物', '跌倒', '噎到', '癲癇'];
      const obs = (doc.observations || '') + (doc.special_notes || '');
      const found = keywords.filter(k => obs.includes(k));
      return { pass: found.length === 0 || doc.special_notes,
        safety_flags: found,
        message: found.length > 0 && !doc.special_notes ? `觀察到安全關鍵字「${found.join(',')}」但特殊備註未填` : null };
    }
  },
];

function runQACheck(document, previousDocument) {
  const results = [];
  let passCount = 0;
  let failCount = 0;

  for (const rule of QA_RULES) {
    const result = rule.check(document, previousDocument);
    results.push({
      rule_id: rule.id,
      category: rule.category,
      label: rule.label,
      ...result,
    });
    if (result.pass) passCount++;
    else failCount++;
  }

  const score = Math.round((passCount / QA_RULES.length) * 100);

  return {
    total_rules: QA_RULES.length,
    passed: passCount,
    failed: failCount,
    score,
    grade: score >= 90 ? 'A' : score >= 75 ? 'B' : score >= 60 ? 'C' : 'D',
    results,
    summary: failCount === 0 ? '文件品質優良，無需修改' :
      `發現${failCount}項問題需要關注`,
    action_required: results.filter(r => !r.pass).map(r => ({
      rule: r.label, message: r.message, category: r.category,
    })),
  };
}

function batchQACheck(db, period) {
  const assessments = db.prepare(`
    SELECT a.*, c.name as client_name FROM assessments a
    JOIN clients c ON a.client_id = c.id WHERE a.period = ?
  `).bind(period).all().results || [];

  const batchResults = [];
  let totalScore = 0;

  for (const a of assessments) {
    const prev = db.prepare(`
      SELECT * FROM assessments WHERE client_id = ? AND period < ? ORDER BY period DESC LIMIT 1
    `).bind(a.client_id, period).first();

    const qa = runQACheck(a, prev);
    batchResults.push({ client_name: a.client_name, client_id: a.client_id, ...qa });
    totalScore += qa.score;
  }

  const avgScore = assessments.length > 0 ? Math.round(totalScore / assessments.length) : 0;

  return {
    period,
    total_assessments: assessments.length,
    average_score: avgScore,
    grade_distribution: {
      A: batchResults.filter(r => r.grade === 'A').length,
      B: batchResults.filter(r => r.grade === 'B').length,
      C: batchResults.filter(r => r.grade === 'C').length,
      D: batchResults.filter(r => r.grade === 'D').length,
    },
    needs_attention: batchResults.filter(r => r.grade === 'C' || r.grade === 'D'),
    all_results: batchResults,
  };
}

const QA_SCHEMA = `
CREATE TABLE IF NOT EXISTS qa_check_log (
  id TEXT PRIMARY KEY,
  document_type TEXT NOT NULL,
  document_id TEXT NOT NULL,
  period TEXT,
  score INTEGER,
  grade TEXT,
  passed INTEGER,
  failed INTEGER,
  results_json TEXT,
  checked_at TEXT DEFAULT (datetime('now')),
  checked_by TEXT DEFAULT 'system'
);

CREATE INDEX IF NOT EXISTS idx_qa_period ON qa_check_log(period);
CREATE INDEX IF NOT EXISTS idx_qa_grade ON qa_check_log(grade);
`;

// ===== 匯出 =====
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    // N2
    PHARMACY_SYNC_STATUS, ORDER_STATUS, PHARMACY_SCHEMA,
    createPrescriptionOrder, updateOrderStatus, getRefillAlerts, getInventoryStatus,
    // N3
    FIVE_RIGHTS, validateBarcodeScan,
    // X1
    QA_RULES, QA_SCHEMA,
    runQACheck, batchQACheck,
  };
}
