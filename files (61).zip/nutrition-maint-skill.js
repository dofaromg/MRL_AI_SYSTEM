/**
 * ============================================================
 *  聖愛教養院 · 第4波三合一模組 v1.0
 *  F1 營養過敏原 / G1 預防維護 / T2 技能追蹤
 *  origin_signature: MrLiouWord
 * ============================================================
 */

// ========== F1：營養過敏原交叉比對 ==========
// 業界對標：Computrition / MealSuite / DietMaster

const COMMON_ALLERGENS = {
  milk:     { label: '牛奶/乳製品', severity_default: 'moderate' },
  egg:      { label: '蛋', severity_default: 'moderate' },
  peanut:   { label: '花生', severity_default: 'severe' },
  tree_nut: { label: '堅果（核桃/腰果/杏仁）', severity_default: 'severe' },
  wheat:    { label: '小麥/麩質', severity_default: 'moderate' },
  soy:      { label: '大豆', severity_default: 'mild' },
  fish:     { label: '魚類', severity_default: 'moderate' },
  shellfish:{ label: '甲殼類（蝦蟹）', severity_default: 'severe' },
  sesame:   { label: '芝麻', severity_default: 'moderate' },
  sulfite:  { label: '亞硫酸鹽', severity_default: 'mild' },
};

// 菜單食材→過敏原映射（精選高頻）
const INGREDIENT_ALLERGEN_MAP = {
  '牛奶': ['milk'], '鮮奶': ['milk'], '起司': ['milk'], '奶油': ['milk'], '優格': ['milk'],
  '雞蛋': ['egg'], '蛋': ['egg'], '蛋黃': ['egg'], '蛋白': ['egg'], '美乃滋': ['egg'],
  '花生': ['peanut'], '花生醬': ['peanut'],
  '核桃': ['tree_nut'], '杏仁': ['tree_nut'], '腰果': ['tree_nut'],
  '麵粉': ['wheat'], '麵包': ['wheat', 'egg', 'milk'], '餅乾': ['wheat', 'egg', 'milk'],
  '豆腐': ['soy'], '醬油': ['wheat', 'soy'], '味噌': ['soy'],
  '蝦': ['shellfish'], '蟹': ['shellfish'], '龍蝦': ['shellfish'],
  '鮭魚': ['fish'], '鱈魚': ['fish'], '秋刀魚': ['fish'],
  '芝麻': ['sesame'], '芝麻醬': ['sesame'],
};

function checkMenuAllergens(menuIngredients, residentAllergies) {
  const alerts = [];
  for (const ingredient of menuIngredients) {
    const allergenCodes = INGREDIENT_ALLERGEN_MAP[ingredient] || [];
    for (const code of allergenCodes) {
      const match = residentAllergies.find(a => a.allergen_code === code);
      if (match) {
        alerts.push({
          ingredient,
          allergen_code: code,
          allergen_label: COMMON_ALLERGENS[code]?.label || code,
          resident_severity: match.severity || COMMON_ALLERGENS[code]?.severity_default,
          action: match.severity === 'severe' ? '禁止供餐，需替代餐' : '標記提醒，供餐前確認',
        });
      }
    }
  }
  return {
    safe: alerts.length === 0,
    alert_count: alerts.length,
    has_severe: alerts.some(a => a.resident_severity === 'severe'),
    alerts: alerts.sort((a, b) => {
      const order = { severe: 0, moderate: 1, mild: 2 };
      return (order[a.resident_severity] || 3) - (order[b.resident_severity] || 3);
    }),
  };
}

function batchCheckMealPlan(db, mealDate) {
  const menu = db.prepare(`
    SELECT meal_type, ingredients_json FROM meal_plans WHERE date = ?
  `).bind(mealDate).all().results || [];

  const residents = db.prepare(`
    SELECT ra.resident_id, c.name, ra.allergen_code, ra.severity
    FROM resident_food_allergies ra JOIN clients c ON ra.resident_id = c.id
    WHERE ra.status = 'active'
  `).all().results || [];

  const allergyMap = {};
  for (const r of residents) {
    if (!allergyMap[r.resident_id]) allergyMap[r.resident_id] = { name: r.name, allergies: [] };
    allergyMap[r.resident_id].allergies.push({ allergen_code: r.allergen_code, severity: r.severity });
  }

  const results = [];
  for (const meal of menu) {
    const ingredients = JSON.parse(meal.ingredients_json || '[]');
    for (const [resId, info] of Object.entries(allergyMap)) {
      const check = checkMenuAllergens(ingredients, info.allergies);
      if (!check.safe) {
        results.push({
          meal_type: meal.meal_type, date: mealDate,
          resident_id: resId, resident_name: info.name,
          ...check,
        });
      }
    }
  }
  return { date: mealDate, total_alerts: results.length, affected_residents: [...new Set(results.map(r => r.resident_id))].length, details: results };
}

const NUTRITION_ALLERGEN_SCHEMA = `
CREATE TABLE IF NOT EXISTS resident_food_allergies (
  id TEXT PRIMARY KEY,
  resident_id TEXT NOT NULL,
  allergen_code TEXT NOT NULL,
  allergen_label TEXT,
  severity TEXT DEFAULT 'moderate' CHECK(severity IN ('mild','moderate','severe')),
  discovered_date TEXT,
  verified_by TEXT,
  status TEXT DEFAULT 'active',
  created_at TEXT DEFAULT (datetime('now')),
  FOREIGN KEY (resident_id) REFERENCES clients(id)
);

CREATE TABLE IF NOT EXISTS meal_plans (
  id TEXT PRIMARY KEY,
  date TEXT NOT NULL,
  meal_type TEXT CHECK(meal_type IN ('breakfast','lunch','dinner','snack')),
  menu_name TEXT,
  ingredients_json TEXT,
  calories REAL,
  protein_g REAL,
  sodium_mg REAL,
  fiber_g REAL,
  created_by TEXT,
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_food_allergy_resident ON resident_food_allergies(resident_id);
CREATE INDEX IF NOT EXISTS idx_meal_date ON meal_plans(date);
`;

// ========== G1：預防性維護排程 ==========
// 業界對標：CMMS / FMX / UpKeep

const EQUIPMENT_TYPES = {
  elevator:     { label: '電梯', cycle_days: 30, regulation: '建築法' },
  fire_system:  { label: '消防設備', cycle_days: 180, regulation: '消防法' },
  generator:    { label: '發電機', cycle_days: 90, regulation: '電業法' },
  water_heater: { label: '熱水器', cycle_days: 180, regulation: '瓦斯安全' },
  ac_system:    { label: '空調系統', cycle_days: 90, regulation: '' },
  wheelchair:   { label: '輪椅', cycle_days: 30, regulation: '' },
  bed_electric: { label: '電動床', cycle_days: 90, regulation: '' },
  kitchen_equip:{ label: '廚房設備', cycle_days: 60, regulation: '食安法' },
  vehicle:      { label: '交通車', cycle_days: 30, regulation: '道安條例' },
  water_quality:{ label: '飲水設備', cycle_days: 30, regulation: '飲用水管理' },
};

function createMaintenanceSchedule(db, data) {
  const id = `maint_${Date.now()}`;
  const equip = EQUIPMENT_TYPES[data.equipment_type] || {};
  const cycleDays = data.cycle_days || equip.cycle_days || 90;
  const nextDate = new Date();
  nextDate.setDate(nextDate.getDate() + cycleDays);

  db.prepare(`
    INSERT INTO maintenance_schedules
    (id, equipment_id, equipment_type, equipment_name, location,
     cycle_days, last_maintained, next_due, regulation, status, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', datetime('now'))
  `).bind(id, data.equipment_id, data.equipment_type,
    data.equipment_name || equip.label, data.location || '',
    cycleDays, data.last_maintained || new Date().toISOString().slice(0, 10),
    nextDate.toISOString().slice(0, 10),
    equip.regulation || '').run();

  return { id, next_due: nextDate.toISOString().slice(0, 10) };
}

function getOverdueMaintenance(db) {
  const today = new Date().toISOString().slice(0, 10);
  return db.prepare(`
    SELECT * FROM maintenance_schedules
    WHERE next_due <= ? AND status = 'active' ORDER BY next_due ASC
  `).bind(today).all().results || [];
}

function completeMaintenance(db, scheduleId, data) {
  const sched = db.prepare('SELECT * FROM maintenance_schedules WHERE id = ?').bind(scheduleId).first();
  if (!sched) throw new Error('排程不存在');

  const today = new Date().toISOString().slice(0, 10);
  const nextDate = new Date();
  nextDate.setDate(nextDate.getDate() + sched.cycle_days);

  db.prepare(`
    UPDATE maintenance_schedules SET last_maintained = ?, next_due = ?, updated_at = datetime('now')
    WHERE id = ?
  `).bind(today, nextDate.toISOString().slice(0, 10), scheduleId).run();

  db.prepare(`
    INSERT INTO maintenance_log (id, schedule_id, performed_by, performed_date, result, notes, cost, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'))
  `).bind(`mlog_${Date.now()}`, scheduleId, data.performed_by,
    today, data.result || 'pass', data.notes || null, data.cost || 0).run();

  return { schedule_id: scheduleId, next_due: nextDate.toISOString().slice(0, 10) };
}

const MAINTENANCE_SCHEMA = `
CREATE TABLE IF NOT EXISTS maintenance_schedules (
  id TEXT PRIMARY KEY,
  equipment_id TEXT,
  equipment_type TEXT NOT NULL,
  equipment_name TEXT,
  location TEXT,
  cycle_days INTEGER DEFAULT 90,
  last_maintained TEXT,
  next_due TEXT NOT NULL,
  regulation TEXT,
  status TEXT DEFAULT 'active',
  created_at TEXT DEFAULT (datetime('now')),
  updated_at TEXT
);

CREATE TABLE IF NOT EXISTS maintenance_log (
  id TEXT PRIMARY KEY,
  schedule_id TEXT NOT NULL,
  performed_by TEXT NOT NULL,
  performed_date TEXT,
  result TEXT CHECK(result IN ('pass','fail','needs_followup')),
  notes TEXT,
  cost REAL DEFAULT 0,
  created_at TEXT DEFAULT (datetime('now')),
  FOREIGN KEY (schedule_id) REFERENCES maintenance_schedules(id)
);

CREATE INDEX IF NOT EXISTS idx_maint_due ON maintenance_schedules(next_due, status);
CREATE INDEX IF NOT EXISTS idx_mlog_schedule ON maintenance_log(schedule_id);
`;

// ========== T2：技能獲得追蹤 ==========
// 業界對標：AxisCare person-centered / SETWorks

const ADL_SKILL_DOMAINS = {
  eating:       { label: '飲食', levels: ['完全協助','部分協助','口頭提示','監督','獨立'] },
  dressing:     { label: '穿衣', levels: ['完全協助','部分協助','口頭提示','監督','獨立'] },
  bathing:      { label: '盥洗', levels: ['完全協助','部分協助','口頭提示','監督','獨立'] },
  toileting:    { label: '如廁', levels: ['完全協助','部分協助','口頭提示','監督','獨立'] },
  mobility:     { label: '行動', levels: ['輪椅完全協助','輪椅半獨立','助行器','扶持','獨立行走'] },
  communication:{ label: '溝通', levels: ['無口語','手勢/圖卡','單詞','短句','對話'] },
  social:       { label: '社交', levels: ['無互動','被動回應','主動接觸','維持互動','社區參與'] },
  money:        { label: '金錢管理', levels: ['無概念','辨認硬幣','簡單購物','找零','預算管理'] },
  safety:       { label: '安全意識', levels: ['無意識','認識危險','避免危險','求助','獨立判斷'] },
  time_mgmt:    { label: '時間管理', levels: ['無概念','認識日夜','看鐘報時','按時行動','自主安排'] },
};

function recordSkillAssessment(db, data) {
  const id = `skilla_${Date.now()}`;
  const domain = ADL_SKILL_DOMAINS[data.domain];
  if (!domain) throw new Error(`無效領域: ${data.domain}`);
  if (data.level < 1 || data.level > 5) throw new Error('等級須為1-5');

  db.prepare(`
    INSERT INTO skill_assessments
    (id, resident_id, domain, domain_label, level, level_label,
     assessed_by, assessed_date, notes, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
  `).bind(id, data.resident_id, data.domain, domain.label,
    data.level, domain.levels[data.level - 1],
    data.assessed_by, data.assessed_date || new Date().toISOString().slice(0, 10),
    data.notes || null).run();

  return { id, domain: domain.label, level: data.level, label: domain.levels[data.level - 1] };
}

function getSkillProgress(db, residentId, domain, months = 12) {
  const since = new Date();
  since.setMonth(since.getMonth() - months);

  return db.prepare(`
    SELECT assessed_date, level, level_label, assessed_by
    FROM skill_assessments
    WHERE resident_id = ? AND domain = ? AND assessed_date >= ?
    ORDER BY assessed_date ASC
  `).bind(residentId, domain, since.toISOString().slice(0, 10)).all().results || [];
}

function getSkillRadar(db, residentId) {
  const domains = Object.keys(ADL_SKILL_DOMAINS);
  const radar = {};
  for (const d of domains) {
    const latest = db.prepare(`
      SELECT level, level_label FROM skill_assessments
      WHERE resident_id = ? AND domain = ? ORDER BY assessed_date DESC LIMIT 1
    `).bind(residentId, d).first();
    radar[d] = { label: ADL_SKILL_DOMAINS[d].label, level: latest?.level || 0, label_text: latest?.level_label || '未評估' };
  }
  return radar;
}

function getSkillMilestones(db, residentId) {
  return db.prepare(`
    SELECT sa.domain, sa.domain_label,
      MIN(sa.level) as first_level, MAX(sa.level) as current_level,
      MAX(sa.level) - MIN(sa.level) as improvement
    FROM skill_assessments sa
    WHERE sa.resident_id = ?
    GROUP BY sa.domain HAVING improvement > 0
    ORDER BY improvement DESC
  `).bind(residentId).all().results || [];
}

const SKILL_TRACKING_SCHEMA = `
CREATE TABLE IF NOT EXISTS skill_assessments (
  id TEXT PRIMARY KEY,
  resident_id TEXT NOT NULL,
  domain TEXT NOT NULL,
  domain_label TEXT,
  level INTEGER CHECK(level BETWEEN 1 AND 5),
  level_label TEXT,
  assessed_by TEXT NOT NULL,
  assessed_date TEXT NOT NULL,
  notes TEXT,
  created_at TEXT DEFAULT (datetime('now')),
  FOREIGN KEY (resident_id) REFERENCES clients(id)
);

CREATE INDEX IF NOT EXISTS idx_skill_resident ON skill_assessments(resident_id, domain);
CREATE INDEX IF NOT EXISTS idx_skill_date ON skill_assessments(assessed_date);
`;

// ===== 匯出 =====
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    // F1
    COMMON_ALLERGENS, INGREDIENT_ALLERGEN_MAP, NUTRITION_ALLERGEN_SCHEMA,
    checkMenuAllergens, batchCheckMealPlan,
    // G1
    EQUIPMENT_TYPES, MAINTENANCE_SCHEMA,
    createMaintenanceSchedule, getOverdueMaintenance, completeMaintenance,
    // T2
    ADL_SKILL_DOMAINS, SKILL_TRACKING_SCHEMA,
    recordSkillAssessment, getSkillProgress, getSkillRadar, getSkillMilestones,
  };
}
