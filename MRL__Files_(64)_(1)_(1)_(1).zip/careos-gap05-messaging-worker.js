/**
 * CareOS Secure Messaging Worker v1.0
 * origin_signature: MrLiouWord
 *
 * Endpoints:
 *  GET    /api/conversations           取得我的對話列表
 *  POST   /api/conversations           建立對話（私訊/群組）
 *  GET    /api/conversations/:id       取得單一對話 + 訊息（分頁）
 *  POST   /api/conversations/:id/messages  送出訊息
 *  PUT    /api/messages/:mid/read      標記已讀
 *  PUT    /api/conversations/:id/pin   置頂訊息
 *  POST   /api/broadcast               全院公告
 *  GET    /api/conversations/:id/media 取得媒體清單
 *  DELETE /api/messages/:mid           撤回訊息（2分鐘內）
 */

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type,Authorization,X-User-Id',
};

function json(data, status=200){
  return new Response(JSON.stringify(data),{status,headers:{...CORS,'Content-Type':'application/json'}});
}
function err(msg,status=400){return json({ok:false,error:msg},status);}
function now(){return new Date().toISOString();}
function uid(p=''){return p+Date.now().toString(36)+Math.random().toString(36).slice(2,6);}

// ── D1 初始化 ─────────────────────────────────
async function initDB(db){
  await db.exec(`
    CREATE TABLE IF NOT EXISTS care_conversations (
      id            TEXT PRIMARY KEY,
      type          TEXT NOT NULL DEFAULT 'direct',  -- direct | group | announce
      name          TEXT NOT NULL,
      created_by    TEXT NOT NULL,
      pinned_msg_id TEXT DEFAULT NULL,
      created_at    TEXT NOT NULL,
      updated_at    TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS care_conv_members (
      conv_id    TEXT NOT NULL,
      user_id    TEXT NOT NULL,
      joined_at  TEXT NOT NULL,
      role       TEXT DEFAULT 'member',  -- member | admin
      muted      INTEGER DEFAULT 0,
      PRIMARY KEY (conv_id, user_id)
    );

    CREATE TABLE IF NOT EXISTS care_messages (
      id          TEXT PRIMARY KEY,
      conv_id     TEXT NOT NULL,
      sender_id   TEXT NOT NULL,
      text        TEXT NOT NULL,
      urgent      INTEGER DEFAULT 0,
      is_retracted INTEGER DEFAULT 0,
      attachment_json TEXT DEFAULT NULL,
      sent_at     TEXT NOT NULL,
      edited_at   TEXT DEFAULT NULL,
      FOREIGN KEY (conv_id) REFERENCES care_conversations(id)
    );

    CREATE TABLE IF NOT EXISTS care_message_reads (
      msg_id  TEXT NOT NULL,
      user_id TEXT NOT NULL,
      read_at TEXT NOT NULL,
      PRIMARY KEY (msg_id, user_id)
    );

    CREATE INDEX IF NOT EXISTS idx_msgs_conv ON care_messages(conv_id, sent_at DESC);
    CREATE INDEX IF NOT EXISTS idx_members_user ON care_conv_members(user_id);
    CREATE INDEX IF NOT EXISTS idx_reads_msg ON care_message_reads(msg_id);
  `);
}

export default {
  async fetch(request, env){
    if(request.method==='OPTIONS') return new Response(null,{status:204,headers:CORS});

    const db = env.DB;
    await initDB(db);

    const url    = new URL(request.url);
    const path   = url.pathname;
    const method = request.method;
    const userId = request.headers.get('X-User-Id') || 'anonymous';

    try {
      // ── GET /api/conversations ─────────────────────
      if(method==='GET' && path==='/api/conversations'){
        const rows = await db.prepare(`
          SELECT c.*, cm.muted,
            (SELECT COUNT(*) FROM care_messages m
              LEFT JOIN care_message_reads r ON r.msg_id=m.id AND r.user_id=?
              WHERE m.conv_id=c.id AND r.msg_id IS NULL AND m.sender_id != ?) as unread
          FROM care_conversations c
          JOIN care_conv_members cm ON cm.conv_id=c.id AND cm.user_id=?
          ORDER BY c.updated_at DESC
        `).bind(userId,userId,userId).all();
        return json({ok:true, conversations: rows.results});
      }

      // ── POST /api/conversations ────────────────────
      if(method==='POST' && path==='/api/conversations'){
        const body = await request.json();
        const {type='direct', name, members=[]} = body;
        if(!name) return err('name 必填');
        if(!members.length) return err('至少要有一位成員');
        if(type==='direct' && members.length>1) return err('私訊只能有兩人');

        const cid = uid('conv');
        const ts  = now();
        await db.prepare(`INSERT INTO care_conversations (id,type,name,created_by,created_at,updated_at)
          VALUES (?,?,?,?,?,?)`).bind(cid,type,name,userId,ts,ts).run();

        const allMembers = [...new Set([userId, ...members])];
        for(const mid of allMembers){
          await db.prepare(`INSERT OR IGNORE INTO care_conv_members (conv_id,user_id,joined_at,role)
            VALUES (?,?,?,?)`).bind(cid,mid,ts,mid===userId?'admin':'member').run();
        }
        return json({ok:true, conversation_id:cid},201);
      }

      // ── GET /api/conversations/:id ─────────────────
      const mConv = path.match(/^\/api\/conversations\/([^/]+)$/);
      if(mConv && method==='GET'){
        const cid = mConv[1];
        const page = parseInt(url.searchParams.get('page')||'1');
        const size = Math.min(parseInt(url.searchParams.get('size')||'50'),100);
        const offset = (page-1)*size;

        const conv = await db.prepare('SELECT * FROM care_conversations WHERE id=?').bind(cid).first();
        if(!conv) return err('找不到對話',404);

        const members = await db.prepare(
          'SELECT * FROM care_conv_members WHERE conv_id=?').bind(cid).all();
        const total = await db.prepare(
          'SELECT COUNT(*) as c FROM care_messages WHERE conv_id=? AND is_retracted=0').bind(cid).first();
        const msgs = await db.prepare(
          'SELECT * FROM care_messages WHERE conv_id=? AND is_retracted=0 ORDER BY sent_at DESC LIMIT ? OFFSET ?'
        ).bind(cid,size,offset).all();

        return json({ok:true, conversation:conv, members:members.results,
          total:total.c, messages:msgs.results.reverse()});
      }

      // ── POST /api/conversations/:id/messages ───────
      const mMsgs = path.match(/^\/api\/conversations\/([^/]+)\/messages$/);
      if(mMsgs && method==='POST'){
        const cid = mMsgs[1];
        const body = await request.json();
        const {text, urgent=false, attachment=null} = body;
        if(!text?.trim()) return err('text 必填');

        const mid = uid('msg');
        const ts  = now();
        await db.prepare(`INSERT INTO care_messages (id,conv_id,sender_id,text,urgent,attachment_json,sent_at)
          VALUES (?,?,?,?,?,?,?)`).bind(mid,cid,userId,text.trim(),urgent?1:0,
          attachment?JSON.stringify(attachment):null,ts).run();
        await db.prepare('UPDATE care_conversations SET updated_at=? WHERE id=?').bind(ts,cid).run();
        await db.prepare('INSERT OR IGNORE INTO care_message_reads (msg_id,user_id,read_at) VALUES (?,?,?)')
          .bind(mid,userId,ts).run();

        return json({ok:true, message_id:mid, sent_at:ts},201);
      }

      // ── PUT /api/messages/:mid/read ────────────────
      const mRead = path.match(/^\/api\/messages\/([^/]+)\/read$/);
      if(mRead && method==='PUT'){
        const mid = mRead[1];
        const ts  = now();
        await db.prepare('INSERT OR IGNORE INTO care_message_reads (msg_id,user_id,read_at) VALUES (?,?,?)')
          .bind(mid,userId,ts).run();
        return json({ok:true});
      }

      // ── PUT /api/conversations/:id/pin ────────────
      const mPin = path.match(/^\/api\/conversations\/([^/]+)\/pin$/);
      if(mPin && method==='PUT'){
        const cid = mPin[1];
        const body = await request.json();
        const {message_id} = body;
        await db.prepare('UPDATE care_conversations SET pinned_msg_id=? WHERE id=?').bind(message_id,cid).run();
        return json({ok:true});
      }

      // ── POST /api/broadcast ────────────────────────
      if(method==='POST' && path==='/api/broadcast'){
        const body = await request.json();
        const {text, urgent=true} = body;
        if(!text?.trim()) return err('text 必填');
        const convs = await db.prepare('SELECT id FROM care_conversations').all();
        const ts  = now();
        const ids = [];
        for(const c of convs.results){
          const mid=uid('ann');
          await db.prepare(`INSERT INTO care_messages (id,conv_id,sender_id,text,urgent,sent_at)
            VALUES (?,?,?,?,?,?)`).bind(mid,c.id,userId,'📢 全院公告：'+text,urgent?1:0,ts).run();
          ids.push(mid);
        }
        return json({ok:true, sent_to:convs.results.length, message_ids:ids});
      }

      // ── DELETE /api/messages/:mid ──────────────────
      const mDel = path.match(/^\/api\/messages\/([^/]+)$/);
      if(mDel && method==='DELETE'){
        const mid = mDel[1];
        const msg = await db.prepare('SELECT * FROM care_messages WHERE id=? AND sender_id=?').bind(mid,userId).first();
        if(!msg) return err('找不到訊息或無權限',404);
        const sentMs = Date.now() - new Date(msg.sent_at).getTime();
        if(sentMs > 120000) return err('只能撤回2分鐘內的訊息');
        await db.prepare('UPDATE care_messages SET is_retracted=1,text="[訊息已撤回]" WHERE id=?').bind(mid).run();
        return json({ok:true});
      }

      return err('找不到路由',404);
    } catch(e){
      return err('伺服器錯誤: '+e.message,500);
    }
  }
};
